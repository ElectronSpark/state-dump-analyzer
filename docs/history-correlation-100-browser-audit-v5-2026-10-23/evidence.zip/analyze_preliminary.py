from pathlib import Path
from datetime import datetime
from bisect import bisect_left, bisect_right
import json

root = Path(__file__).resolve().parent
moves = json.loads((root/'moves.json').read_text(encoding='utf-8-sig'))
records = [json.loads(line) for line in (root/'process-samples.jsonl').read_text().splitlines() if line.strip()]
samples = [r for r in records if r['kind'] == 'sample']
times = [s['epoch_ns']/1e9 for s in samples]
def epoch(s): return datetime.fromisoformat(s.replace('Z','+00:00')).timestamp()
def bracket(start, end):
    lo=max(0,bisect_right(times,start)-1)
    hi=min(len(samples)-1,bisect_left(times,end))
    if hi<lo: hi=lo
    chosen=samples[lo:hi+1]
    busy=[]
    for a,b in zip(chosen,chosen[1:]):
        dt=(b['epoch_ns']-a['epoch_ns'])/1e9
        dc=b['cpu_s']-a['cpu_s']
        if dc/dt>=0.1: busy.append({'start':a['utc'],'end':b['utc'],'cpu_s':dc,'wall_s':dt})
    return {'start':chosen[0]['utc'],'end':chosen[-1]['utc'],'wall_s':(chosen[-1]['epoch_ns']-chosen[0]['epoch_ns'])/1e9,
            'cpu_s':chosen[-1]['cpu_s']-chosen[0]['cpu_s'],'rss_start_gib':chosen[0]['rss_bytes']/2**30,
            'rss_end_gib':chosen[-1]['rss_bytes']/2**30,'sampled_rss_peak_gib':max(s['rss_bytes'] for s in chosen)/2**30,
            'private_start_gib':chosen[0]['private_bytes']/2**30,'private_end_gib':chosen[-1]['private_bytes']/2**30,
            'busy_intervals':busy}
result=[]
for m in moves:
    if not 35<=m['id']<=57: continue
    start=epoch(m['started_at'])
    end=epoch(m.get('settled_at') or m.get('action_finished_at') or samples[-1]['utc'])
    result.append({'id':m['id'],'name':m['name'],'start':m['started_at'],'action_end':m.get('action_finished_at'),
                   'settled':m.get('settled_at'),'outcome':m.get('outcome'),'observation':m.get('observation'),
                   'measured_outer_bracket':bracket(start,end)})
payload={'generated_from_last_sample':samples[-1]['utc'],'moves':result}
(root/'preliminary-performance.json').write_text(json.dumps(payload,indent=2)+'\n',encoding='utf-8')
for m in result:
    b=m['measured_outer_bracket']
    print(m['id'],m['name'],round(b['wall_s'],3),round(b['cpu_s'],3),round(b['rss_start_gib'],3),round(b['rss_end_gib'],3),m['outcome'])
