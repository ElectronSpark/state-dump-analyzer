"""Join saved browser workflow observations with one-Hz process samples only."""
from pathlib import Path
from datetime import datetime, timezone
from bisect import bisect_left, bisect_right
from collections import Counter
import json

root = Path(__file__).resolve().parent
records = [json.loads(line) for line in (root/'process-samples.jsonl').read_text(encoding='utf-8').splitlines() if line.strip()]
samples = [r for r in records if r['kind'] == 'sample']
moves = json.loads((root/'moves.json').read_text(encoding='utf-8-sig'))
assert [m['id'] for m in moves] == list(range(1,101)), 'Exactly 100 ordered move records required'
assert all(m.get('outcome') not in (None,'pending') for m in moves), 'Finalize move outcomes first'
assert records[0]['kind'] == 'start'
assert records[-1]['kind'] == 'stop' and records[-1]['reason'] == 'stop_file', 'Stop sampler cleanly first'
assert records[-1]['samples'] == len(samples)
assert len({s['process_creation_filetime'] for s in samples}) == 1
times = [s['epoch_ns']/1e9 for s in samples]
assert all(b>a for a,b in zip(times,times[1:]))
assert all(b['cpu_s']>=a['cpu_s'] for a,b in zip(samples,samples[1:]))
assert records[-1]['audit_sampled_peak_rss_bytes'] == max(s['rss_bytes'] for s in samples)
assert records[-1]['audit_sampled_peak_private_bytes'] == max(s['private_bytes'] for s in samples)

def epoch(value): return datetime.fromisoformat(value.replace('Z','+00:00')).timestamp()
def iso(value): return datetime.fromtimestamp(value,timezone.utc).isoformat(timespec='milliseconds').replace('+00:00','Z')
def interp_cpu(at):
    i=bisect_left(times,at)
    if i==0: return samples[0]['cpu_s']
    if i==len(times): return samples[-1]['cpu_s']
    a,b=samples[i-1],samples[i]
    return a['cpu_s']+(b['cpu_s']-a['cpu_s'])*(at-times[i-1])/(times[i]-times[i-1])
def window(start,end):
    fully_sampled=times[0]<=start<=end<=times[-1]
    overlaps=start<=times[-1] and end>=times[0]
    lo=max(0,bisect_right(times,start)-1)
    hi=min(len(samples)-1,bisect_left(times,end))
    if hi<lo: hi=lo
    selected=samples[lo:hi+1]
    inside=samples[bisect_left(times,start):bisect_right(times,end)]
    active=[(a,b) for a,b in zip(selected,selected[1:])
            if (b['cpu_s']-a['cpu_s'])/((b['epoch_ns']-a['epoch_ns'])/1e9)>=0.1]
    bracket={'start_utc':selected[0]['utc'],'end_utc':selected[-1]['utc'],
              'wall_s':(selected[-1]['epoch_ns']-selected[0]['epoch_ns'])/1e9,
              'cpu_s':selected[-1]['cpu_s']-selected[0]['cpu_s'],
              'rss_first_bytes':selected[0]['rss_bytes'],'rss_last_bytes':selected[-1]['rss_bytes'],
              'private_first_bytes':selected[0]['private_bytes'],'private_last_bytes':selected[-1]['private_bytes']} if overlaps else None
    return {'requested_start_utc':iso(start),'requested_end_utc':iso(end),'requested_wall_s':end-start,
            'fully_sampled':fully_sampled,
            'coverage_note':('Fully covered by sample endpoints.' if fully_sampled else
                'Requested window extends beyond sampled coverage; full-window CPU and outer bracket are unavailable. Available-sample metrics exclude all later verification.'),
            'uncovered_before_s':max(0,min(end,times[0])-start),
            'uncovered_after_s':max(0,end-max(start,times[-1])),
            'interpolated_cpu_s':interp_cpu(end)-interp_cpu(start) if fully_sampled else None,
            'sampled_overlap_interpolated_cpu_s':interp_cpu(min(end,times[-1]))-interp_cpu(max(start,times[0])) if overlaps else None,
            'outer_bracket':bracket if fully_sampled else None,
            'available_sample_bracket':bracket,
            'contained_samples':len(inside),
            'contained_peak_rss_bytes':max((s['rss_bytes'] for s in inside),default=None),
            'contained_peak_private_bytes':max((s['private_bytes'] for s in inside),default=None),
            'first_active_interval_utc':active[0][0]['utc'] if active else None,
            'last_active_interval_utc':active[-1][1]['utc'] if active else None,
            'active_threshold_cpu_per_wall':0.1}

joined=[]
for m in moves:
    start=epoch(m['started_at']); action_end=epoch(m['action_finished_at'])
    end=epoch(m.get('settled_at') or m['action_finished_at'])
    joined.append({'id':m['id'],'name':m['name'],'outcome':m['outcome'],'observation':m.get('observation'),
                   'action_window':window(start,action_end),'observation_window':window(start,end),
                   'followup_gap_s':end-action_end,
                   'limit':'Observation time is not exact response completion; requests and other work can overlap.'})
def move_start(n): return epoch(moves[n-1]['started_at'])
final_observation=max(epoch(m.get('settled_at') or m['action_finished_at']) for m in moves)
groups=[('initial_fabric_and_routes_1_34',move_start(1),move_start(35)),
        ('cold_pe_d_entry_35',move_start(35),move_start(36)),
        ('pe_d_history_and_correlations_36_65',move_start(36),move_start(66)),
        ('relative_fabric_node_roundtrips_66_72',move_start(66),move_start(73)),
        ('node_topology_history_crosschecks_73_77',move_start(73),move_start(78)),
        ('final_fabric_route_workflows_78_100',move_start(78),final_observation)]
if move_start(1)>=times[0]: groups.insert(0,('pre_move_idle',times[0],move_start(1)))
if final_observation<=times[-1]: groups.append(('post_move_idle',final_observation,times[-1]))
max_rss=max(samples,key=lambda s:s['rss_bytes'])
max_private=max(samples,key=lambda s:s['private_bytes'])
summary={'sampling_started':records[0]['utc'],'sampling_stopped':records[-1]['utc'],
         'sample_count':len(samples),'sample_span_s':times[-1]-times[0],'sampler_elapsed_s':records[-1]['elapsed_s'],
         'process_creation_filetime':samples[0]['process_creation_filetime'],'stop_reason':records[-1]['reason'],
         'cpu_first_s':samples[0]['cpu_s'],'cpu_last_s':samples[-1]['cpu_s'],
         'cpu_delta_s':samples[-1]['cpu_s']-samples[0]['cpu_s'],
         'rss_first_gib':samples[0]['rss_bytes']/2**30,'rss_last_gib':samples[-1]['rss_bytes']/2**30,
         'private_first_gib':samples[0]['private_bytes']/2**30,'private_last_gib':samples[-1]['private_bytes']/2**30,
         'audit_sampled_peak_rss_gib':max_rss['rss_bytes']/2**30,'audit_peak_rss_utc':max_rss['utc'],
         'audit_sampled_peak_private_gib':max_private['private_bytes']/2**30,'audit_peak_private_utc':max_private['utc'],
         'lifetime_peak_rss_start_gib':samples[0]['process_lifetime_peak_rss_bytes']/2**30,
         'lifetime_peak_rss_end_gib':samples[-1]['process_lifetime_peak_rss_bytes']/2**30,
         'lifetime_peak_private_end_gib':samples[-1]['process_lifetime_peak_private_bytes']/2**30,
         'move_outcomes':dict(Counter(m['outcome'] for m in moves)),
         'final_move_observation_utc':iso(final_observation),
         'moves_with_incomplete_observation_coverage':[m['id'] for m in joined if not m['observation_window']['fully_sampled']],
         'limitations':['One-Hz process snapshots can miss peaks. Browser/GPU/children excluded.',
                        'Already-running warm server; not a fresh 1M benchmark.',
                        'Workflow observation gaps include actions/tool/rendering/idle; no per-request timings.',
                        'Do not sum overlapping per-move observation windows as total CPU.',
                        'Move 100 was reclassified after late native-keyboard verification beyond sampler stop. Those later actions are excluded from measured CPU/memory; its full observation window is not sampled.']}
payload={'summary':summary,'phases':[{'name':name,**window(a,b)} for name,a,b in groups],'moves':joined}
(root/'performance-stats.json').write_text(json.dumps(payload,indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary,indent=2))
print('\nPHASES')
for p in payload['phases']:
    b=p['available_sample_bracket']; print(p['name'],'full' if p['fully_sampled'] else 'PARTIAL',round(b['wall_s'],3),round(b['cpu_s'],3),round(b['rss_first_bytes']/2**30,3),round(b['rss_last_bytes']/2**30,3))
