# Independent review: historical correlations

Reviewed saved browser snapshots43–51, their move ledger, and generator/query source at commit052903e. This note does not claim a separate browser run. No product edits, tests, server loads, or benchmarks were performed.

## Confirmed P2: shared Ethernet Segment membership appears before attachment

Browser evidence independently agrees with the reported failure:

- `move-043.txt:2716` and `:2717`: at selected +240.010s, ES0 graph includes ETG375→ES0 `member_of_es` and ES0→primary375 `active_path`. Relationship index reports5 returned, whereas only service0 is attached then (its two service relations plus uses_interface give3).
- `move-045.txt:2671`: same +240.010s table explicitly reports ETG375 `single-home`.
- `move-046.txt:2338` and `:2381`: selecting ETG375 retains single-home table state while its focused graph renders member_of_es ES0. This rules out an ES0-only canvas artifact.
- `move-047.txt:2294` and `:2344`: range starts240.037499999; table remains single-home and the early membership persists at`:2387`.
- `move-048.txt:2292` and `:2342`: at exact240.037500000, table becomes all-active and graph gains backup ownership (5 returned). The correct state transition is visible independently of the invalid early relation.
- `move-049.txt:2344` and `:2387`: rewind restores single-home but the early membership remains.
- Moves50/51 reproduce across full/focused graph switching. Full-graph omission/coverage is not the cause; the same edge remains in fresh focused results.

**Root cause:** `demo/rsl_demo_generator/_scale.py:1833` writes each `member_of_es` start as phase-wide `multi_start`, and`:1842–1848` does the same for ES→primary `active_path`. Actual attachment events are spaced by100,000ns (`:26`,`:1361–1366`); event375 occurs37.5ms after phase start. That event sets all-active state (`:918–926`) and adds precisely those relationships (`:929–934`). Hence persisted interval projections disagree with the event history by37.5ms for service375.

The first service wave partly conceals the error through ES lifecycle filtering. Service375 reuses ES0, which already exists; primary375 was created earlier, so both endpoints pass lifecycle checks. The query correctly honors the advertised relationship interval at `src/router_dump_analyzer/revision_queries.py:766–782`. This is a generator projection defect exposed by frontend inspection, not evidence that the core interval filter or request sequencing is broken. The two invalid edge kinds share one cause and should count as one defect.

**Repair direction for a later authorized fix:** use the existing per-service attachment timestamp consistently when producing multihome relationship starts; do not hide the inconsistency in the frontend or increase graph bounds. Rebuild the persisted fixture and validate before/exact/after/backwards on a shared ES, including ETG375/ES0 and ETG749/ES374.

## Separate candidate, not yet browser-confirmed

`_scale.py:1060` and`:1217` hard-code `affected_services: 3` on ES withdrawal/restoration events. The canonical layout has750 multihome services and375 ES identities, with service index modulo375 (`_es_index`), so each ES actually has2 services. ES374 specifically has374 and749. If the browser's event inspector exposes this property, selecting `node-a/scale-event-00500374` or`node-a/scale-event-00750374` should show3 while its two membership identities establish2. This is an independent generated-evidence count mismatch, not another occurrence of early validity. Current snapshots43–51 do not expose that event property, so do not count it as a confirmed browser finding yet.

No other distinct confirmed functional defect follows from snapshots43–51. A cross-layer projection with unknown ES state under the Data bridge perspective is intentional because ES state belongs to Control plane. A full-range lane containing future membership ribbons is also intentional; the selected-instant graph is the discriminating evidence.

Documentation drift check: only ignored audit evidence was added. No author-visible implementation or command changed.
