"""Join one-Hz demo process samples with browser move timing windows."""
from __future__ import annotations

import argparse
from bisect import bisect_left, bisect_right
from datetime import datetime, timezone
import json
from pathlib import Path


def epoch(value):
    return datetime.fromisoformat(value.replace("Z", "+00:00")).timestamp()


def utc(value):
    return datetime.fromtimestamp(value, timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    args = parser.parse_args()
    records = [json.loads(line) for line in (args.root / "process-samples.jsonl").read_text(encoding="utf-8").splitlines() if line.strip()]
    samples = [item for item in records if item["kind"] == "sample"]
    times = [item["epoch_ns"] / 1e9 for item in samples]
    moves_data = json.loads((args.root / "moves.json").read_text(encoding="utf-8-sig"))
    moves = moves_data if isinstance(moves_data, list) else moves_data["moves"]
    normalized_moves = []
    for source_move in moves:
        move = {**source_move, "id": source_move.get("id", source_move.get("n")), "action": source_move.get("action", source_move.get("title"))}
        end = epoch(move.get("recorded_at", move.get("ended_at")))
        start = epoch(move["started_at"]) if move.get("started_at") else end - move.get("elapsed_ms", 0) / 1000
        normalized_moves.append((start, end, move))

    def interpolate_cpu(at):
        index = bisect_left(times, at)
        if index == 0:
            return samples[0]["cpu_s"]
        if index == len(times):
            return samples[-1]["cpu_s"]
        left, right = samples[index - 1], samples[index]
        fraction = (at - times[index - 1]) / (times[index] - times[index - 1])
        return left["cpu_s"] + fraction * (right["cpu_s"] - left["cpu_s"])

    per_move = []
    for start, end, move in normalized_moves:
        first = max(0, bisect_right(times, start) - 1)
        last = min(len(times) - 1, bisect_left(times, end))
        bracket = samples[first:last + 1]
        covered = start >= times[0] and end <= times[-1]
        overlap = end >= times[0] and start <= times[-1]
        per_move.append({
            "id": move["id"], "action": move["action"], "start_utc": utc(start), "end_utc": utc(end),
            "workflow_wall_s": end - start, "fully_sampled": covered,
            "cpu_estimate_s": interpolate_cpu(end) - interpolate_cpu(start) if overlap else None,
            "bracket_cpu_delta_s": samples[last]["cpu_s"] - samples[first]["cpu_s"] if overlap else None,
            "bracket_duration_s": times[last] - times[first] if overlap else None,
            "max_bracket_rss_bytes": max(item["rss_bytes"] for item in bracket) if overlap else None,
            "max_bracket_private_bytes": max(item["private_bytes"] for item in bracket) if overlap else None,
        })

    active_intervals = []
    for left, right in zip(samples, samples[1:]):
        start, end = left["epoch_ns"] / 1e9, right["epoch_ns"] / 1e9
        cpu = right["cpu_s"] - left["cpu_s"]
        if cpu / (end - start) >= 0.15:
            active_intervals.append((start, end, cpu))
    groups = []
    for interval in active_intervals:
        if groups and interval[0] - groups[-1][-1][1] <= 2.05:
            groups[-1].append(interval)
        else:
            groups.append([interval])
    episodes = []
    for group in groups:
        start, end = group[0][0], group[-1][1]
        overlaps = [{"id": move["id"], "action": move["action"]} for a, b, move in normalized_moves if a <= end and b >= start]
        previous = [move for _, b, move in normalized_moves if b < start]
        following = [move for a, _, move in normalized_moves if a > end]
        first, last = bisect_left(times, start), bisect_right(times, end)
        span = samples[first:last]
        episodes.append({
            "start_utc": utc(start), "end_utc": utc(end), "wall_s": end - start,
            "cpu_s": interpolate_cpu(end) - interpolate_cpu(start),
            "max_one_second_cpu_percent_of_one_core": max(cpu / (b - a) * 100 for a, b, cpu in group),
            "max_sampled_rss_bytes": max(item["rss_bytes"] for item in span),
            "max_sampled_private_bytes": max(item["private_bytes"] for item in span),
            "overlapping_moves": overlaps,
            "previous_move_id": previous[-1]["id"] if previous else None,
            "following_move_id": following[0]["id"] if following else None,
        })
    summary = {
        "scope": "Read-only 1-Hz snapshots of demo Python process PID 12380. Not browser heap; no isolated backend benchmark.",
        "limits": [
            "Move elapsed time includes browser actions, rendering, waits and tool overhead.",
            "Move CPU is interpolated from adjacent one-Hz cumulative samples, not request-specific. The bracket is a wider measured interval, not proof of causation.",
            "Requests can continue after the UI action snapshot; episode overlaps and neighboring move IDs provide context only.",
            "Maximum sampled RSS/private values are one-Hz snapshots and can miss shorter peaks. Process-lifetime peak fields predate this audit and are not audit peaks.",
            "CPU percent is relative to one logical core and can exceed 100% if multiple threads execute.",
        ],
        "start": records[0], "stop": records[-1] if records[-1]["kind"] == "stop" else None,
        "sample_count": len(samples), "sample_start_utc": samples[0]["utc"], "sample_end_utc": samples[-1]["utc"],
        "sample_wall_s": times[-1] - times[0], "cpu_delta_s": samples[-1]["cpu_s"] - samples[0]["cpu_s"],
        "first_rss_bytes": samples[0]["rss_bytes"], "last_rss_bytes": samples[-1]["rss_bytes"],
        "max_sampled_rss_bytes": max(item["rss_bytes"] for item in samples),
        "max_sampled_private_bytes": max(item["private_bytes"] for item in samples),
        "moves": per_move, "cpu_episodes": episodes,
    }
    (args.root / "process-summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    gib = 1024 ** 3
    lines = ["# Demo process observations", "", summary["scope"], "", f"{len(samples)} samples from {summary['sample_start_utc']} to {summary['sample_end_utc']}; {summary['cpu_delta_s']:.3f} s CPU over {summary['sample_wall_s']:.3f} s wall time.", f"RSS snapshots: first {summary['first_rss_bytes'] / gib:.3f} GiB, last {summary['last_rss_bytes'] / gib:.3f} GiB, maximum {summary['max_sampled_rss_bytes'] / gib:.3f} GiB. Maximum private snapshot {summary['max_sampled_private_bytes'] / gib:.3f} GiB.", "", "## Largest CPU episodes", "", "| UTC interval | CPU s | Wall s | Max sampled RSS GiB | Overlapping moves |", "|---|---:|---:|---:|---|"]
    for item in sorted(episodes, key=lambda item: item["cpu_s"], reverse=True)[:20]:
        move_ids = ", ".join(str(move["id"]) for move in item["overlapping_moves"]) or f"between {item['previous_move_id']} and {item['following_move_id']}"
        lines.append(f"| {item['start_utc']} – {item['end_utc']} | {item['cpu_s']:.3f} | {item['wall_s']:.3f} | {item['max_sampled_rss_bytes'] / gib:.3f} | {move_ids} |")
    lines.extend(["", "## Interpretation limits", ""] + [f"- {limit}" for limit in summary["limits"]])
    (args.root / "process-summary.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps({key: summary[key] for key in ("sample_count", "sample_wall_s", "cpu_delta_s", "max_sampled_rss_bytes", "max_sampled_private_bytes")}))


if __name__ == "__main__":
    main()
