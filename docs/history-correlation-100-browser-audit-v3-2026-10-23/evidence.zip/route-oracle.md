# Route oracle for the third historical browser audit

Read-only source review against 052903e, 2026-10-23. Used router-plugin-validate,
AGENTS.md, the historical checks in docs/plugin-api-validation.md, and the prior
audit/repair reports. This is a source oracle, not a claim that browser actions
have passed. No fixture, server, product, or public-authoring materials changed.

## Applied time and clocks

UTC base is **1759680000000000000**. Use the generated fabric-underlay and
observed-status context. Native time = UTC + node offset; an absolute trace
requires every executing decision and its independent source evidence to be
valid across the entire uncertainty window.

| Node | Offset ms | Uncertainty ms |
| --- | ---: | ---: |
| A | -4 | 5 |
| B | +6 | 9 |
| C | +11 | 7 |
| D | -8 | 6 |
| E | +14 | 8 |
| P1 | +1 | 3 |
| P2 | -2 | 4 |
| CE-West | +19 | 12 |
| CE-East | -17 | 15 |
| Edge-C | +31 | 25 |

Inventory rows are authored at UTC+601s. Scenario rows instead use
UTC+610s + (zero-based coverage index)*1ms. Do not reuse the inventory boundary
for a selected scenario. The prior repair regenerated projections; the serving
archive should be router-state-lab-history-clock-2026-10-23.tgz.

## New high-value inventory sequences

Use Any router to any router, default VRF, IPv4 unicast family/type, both
directions. These endpoints extend past the previous A/B VPN test and amplify
clock differences. A missing source table row before its own uncertainty bound
is expected; direct tracing must not bypass it. After each reconstructed time,
rerun the trace; table seeding must be repeated because reconstruction retires a
seed's authority.

| Source→destination | Authored shortest path | First fully admissible UTC ns |
| --- | --- | --- |
| A→D | A,D | 1759680601006000000 |
| A→C | A,P2,C | 1759680601007000000 |
| A→E | A,P1,E | 1759680601008000000 |
| A→CE-West | A,CE-West | 1759680601012000000 |
| A→CE-East | A,P1,B,CE-East | 1759680601015000000 |
| A→Edge-C | A,P2,C,Edge-C | 1759680601025000000 |

For each chosen pair, test boundary−1ns → boundary → boundary−1ns → boundary,
then swap source/destination. Before the boundary, do not assert an exact UI
label for an incomplete candidate, but neither direction may claim complete
end-to-end resolution. At/after it, these healthy default IPv4 paths should
resolve both ways. At +601.012s, A→CE-West should resolve while A→CE-East should
not. At +601.015s, A→CE-East should resolve while A→Edge-C should not. The
different outcome is expected, not retained state from the preceding trace.

Cross-component variants: inspect the destination's route table at boundary−1;
seed its reverse row at the exact boundary; open its node workspace and return;
rerun the restored form; compare selected time, source, destination, direction,
and graph-mode state. Native node cursor must be compared after applying offset,
not using the fabric UTC number as if it were native time.

## New scenario admission sequences

1. **Transit observation with endpoint return validation**, coverage index7,
   authored UTC+610.007s. Forward starts P1→B although packet source is A;
   return is B→P2→A. First full evidence admission is **1759680610016000000**
   (+610.016s, B's9ms bound). Test 1ns before/exact/after/backward. On completion,
   return must end at A, not at the observation start P1. Change explicit start
   and restore scenario; distinguish flow source from observation start in graph
   labels, tabs, details, and jump destinations.
2. **Asymmetric PE-A to PE-C service**, index8, authored UTC+610.008s.
   Forward A→P2→C, selected return C→P2→P1→A, standby return C→P2→A.
   First full admission **1759680610015000000** (+610.015s). The return's different
   path is authored asymmetry; choosing focused/all paths must not silently turn
   standby into selected. Test before/exact/repeat and node/fabric round trip.
3. **EVPN multihoming all-active**, index10, authored UTC+610.010s. Forward
   A→P1→B and A→P2→E; return E→P1→A and E→P2→A. E branch can be admitted at
   **+610.018s**, B branch at **+610.019s**. At 018999999 do not require the B
   candidate to be complete. At019000000 both forward candidates may be complete.
   Switch focused candidate, direction, All paths, reconstruct earlier, and
   verify no old completed branch survives as authoritative. These are all-active
   members, not a singular primary/standby pair.
4. Diagnostic MPLS label mismatch index2 is observed UTC+610.002s; full path
   bound is **+610.011s**. VXLAN VNI mismatch index3 uses **+610.012s**. At latest,
   both have forward mismatch and independently authored return agreement.
   A valid mismatch does not necessarily mean reachability failed. At times
   before evidence admission, the previous complete consistency report must
   not remain presented as a newly evaluated historical result.

## Topology and local-status cross-checks

These authored status events are much earlier than route-row admission. A
historical graph can correctly show a down link while a route trace reports no
valid route evidence; do not invent pre-601 routes to force a crossing.

| Component | Authored UTC offset events | Stable checkpoints |
| --- | --- | --- |
| P1 interface:Ethernet3/1 on P1-P2 10.64.255.0/31 | down90.05, up240.1 | 80up,100down,250up |
| P2 interface:Ethernet4/1 on same circuit | stale down96, update_snapshot=false; up242.5 | 100 must not apply stale down locally |
| D interface:Ethernet1/1.310 on 10.64.0.0/24 | delete180, create300 | 170present,200absent,310present |
| C interface:Ethernet1/1.320 on 10.64.2.0/31 | down420.2, up528 | 410up,450down,540up |
| P2 interface:Ethernet2/1.320 on same circuit | down435, up521 | 430up,450down,525up |
| E vpn:blue-evpn | down400, up560 | 390up,450down,570up |

At UTC+430, C-P2 is down because C is down although P2 is still up. At+525,
P2 is restored but C is still down; at+540 both restored. This is a useful
two-sided conjunction and cross-node correlation test. Observe each end's
single-node status and return to fabric; do not conflate per-node up with circuit
usable. Reconstruct450→540→525→450 and compare labels/tooltips, not just colors.

## Interpretation guards

- Absolute/relative basis and strict/best-effort clock policy are separate from
  route missing-hop policy. Record both when changing them.
- Relative0 refers to each node's latest complete watermark, not one UTC instant.
- Wait for reconstruction, table query, trace, and local graph independently.
- Returning from the node workspace restores a form; it does not imply a fresh
  trace ran. Rerun explicitly before judging graph controls.
- A popup containing hidden stale text is not by itself a visible stale result.
- Current source was inspected and small read-only catalog/path calculations
  confirmed clock values and routes. No route service was invoked here; a
  disagreement requires browser evidence and payload/source corroboration.

Source anchors: demo/rsl_demo_generator/assembly.py (_coverage_timestamp,
_inventory_projection_rows, _inventory_continuation_rows, _source_topology_changes,
_FORWARD_PATHS/_REVERSE_PATHS); demo/router-state-lab-default.scenario.json;
demo/rsl_demo_plugin/scenario_registry.py; core MultiNodeRouteService
_route_evidence_valid_at. Public documentation drift check: audit-only oracle,
no public behavior/API/author-command change; no maintained-doc update required.
