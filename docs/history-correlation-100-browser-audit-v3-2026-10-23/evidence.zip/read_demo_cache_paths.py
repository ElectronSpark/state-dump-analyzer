"""Read only four nonsecret path variables from the known local demo process.

Windows x64 fallback when psutil is unavailable. Never prints or saves the
environment block, nor any variable outside the explicit allowlist.
"""
import ctypes
from ctypes import wintypes
import json

PID = 12380
KEYS = ("ROUTER_DUMP_SEARCH_CACHE_DIR", "LOCALAPPDATA", "TEMP", "TMP")
kernel = ctypes.WinDLL("kernel32", use_last_error=True)
ntdll = ctypes.WinDLL("ntdll")
kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
kernel.OpenProcess.restype = wintypes.HANDLE
kernel.CloseHandle.argtypes = [wintypes.HANDLE]
kernel.ReadProcessMemory.argtypes = [wintypes.HANDLE, ctypes.c_void_p,
                                    ctypes.c_void_p, ctypes.c_size_t,
                                    ctypes.POINTER(ctypes.c_size_t)]
kernel.ReadProcessMemory.restype = wintypes.BOOL


class BasicInfo(ctypes.Structure):
    _fields_ = [("reserved1", ctypes.c_void_p), ("peb", ctypes.c_void_p),
                ("reserved2", ctypes.c_void_p * 2),
                ("pid", ctypes.c_size_t), ("reserved3", ctypes.c_void_p)]


ntdll.NtQueryInformationProcess.argtypes = [wintypes.HANDLE, wintypes.DWORD,
                                          ctypes.c_void_p, wintypes.ULONG,
                                          ctypes.POINTER(wintypes.ULONG)]
ntdll.NtQueryInformationProcess.restype = wintypes.LONG
if ctypes.sizeof(ctypes.c_void_p) != 8:
    raise RuntimeError("This targeted reader requires a 64-bit interpreter")
handle = kernel.OpenProcess(0x0400 | 0x0010, False, PID)
if not handle:
    raise ctypes.WinError(ctypes.get_last_error())


def read(address, size):
    target = ctypes.create_string_buffer(size)
    got = ctypes.c_size_t()
    if not kernel.ReadProcessMemory(handle, address, target, size, ctypes.byref(got)):
        raise ctypes.WinError(ctypes.get_last_error())
    return target.raw[:got.value]


try:
    info = BasicInfo()
    returned = wintypes.ULONG()
    status = ntdll.NtQueryInformationProcess(handle, 0, ctypes.byref(info),
                  ctypes.sizeof(info), ctypes.byref(returned))
    if status != 0 or info.pid != PID:
        raise RuntimeError("Cannot resolve the requested process environment")
    parameters = int.from_bytes(read(info.peb + 0x20, 8), "little")
    environment = int.from_bytes(read(parameters + 0x80, 8), "little")
    if not environment:
        raise RuntimeError("Process has no readable environment")
    # Read through a bounded, WCHAR-aligned terminator without retaining data
    # on disk. Small chunks avoid crossing the end of the mapped block.
    block = bytearray()
    ended = False
    for offset in range(0, 65536, 128):
        block.extend(read(environment + offset, 128))
        for position in range(max(0, len(block) - 130), len(block) - 2, 2):
            if block[position:position + 4] == b"\0\0\0\0":
                block = block[:position]
                ended = True
                break
        if ended:
            break
    if not ended:
        raise RuntimeError("Environment exceeded the targeted reader's bound")
    selected = {key: None for key in KEYS}
    for entry in block.decode("utf-16-le").split("\0"):
        key, sep, value = entry.partition("=")
        if sep and key.upper() in selected:
            selected[key.upper()] = value
    print(json.dumps({"pid": PID, "environment": selected}, indent=2))
finally:
    kernel.CloseHandle(handle)

