# Route evidence review: moves 9–38

Read-only review of saved DOM, ledger, contracts, and source. No new browser actions, tests, service requests, or product changes.

Counts: 23 functional-pass, 3 harness-inconclusive, 2 trigger-inconclusive, 2 confirmed-finding. Two confirming moves establish **one** distinct interaction finding.

## EVPN aggregate result is expected

Moves31/33 show E branch resolved and B branch incomplete at UTC+610.018. This is not a second bug. Every plug-in-selected active branch participates in endpoint aggregation (plugin-contract.md2923–2926). Core returns unknown when any selected result is unknown (multi_node_route.py7609–7611); frontend maps that to unresolved/incomplete (topology.js4593–4597,4935–4944). The selected E path can correctly be resolved while the all-active set remains incomplete. At+610.019 both branches complete.

## Review ledger

| Move | Classification | Assessment |
| --- | --- | --- |
| 009 | functional-pass | CE-East at UTC+601.014999999 is unresolved in both directions; the destination final-hop gap is retained. |
| 010 | functional-pass | Exact CE-East +601.015 boundary resolves both directions after rewind. |
| 011 | harness-inconclusive | Click failed with No node found at given location after destination edit; snapshot has no completed trace. Do not infer route failure. |
| 012 | functional-pass | Explicit retry after field settlement gives unresolved Edge-C in both directions at +601.015, as expected. |
| 013 | functional-pass | Edge-C remains unresolved 1ns before +601.025. |
| 014 | functional-pass | Exact Edge-C +601.025 boundary resolves both directions. |
| 015 | functional-pass | Return tab selected; endpoint remains PE-A, with Edge-C as return origin. |
| 016 | functional-pass | Focused path stays in Return and shows Edge-C via C/P2 to PE-A. |
| 017 | harness-inconclusive | Trace-button click failed after budget edit/layout invalidation. This does not test the one-hop result. |
| 018 | harness-inconclusive | Wait helper timed out; snapshot contains empty alerts and generic idle trace guidance. Restore itself invalidates the result and requires rerun. No input-validation error or backend failure is established. |
| 019 | functional-pass | Changing route TYPE to MPLS L3VPN updates dependent family/VRF to VPNv4/blue. This type-driven compatibility is expected. |
| 020 | trigger-inconclusive | Default text remains in snapshot with L3VPN/VPNv4. It does not reproduce silent reset; native change/blur emission was not established. |
| 021 | trigger-inconclusive | Repeated equal-value fill likewise remains default. Not confirmation of reset and not evidence of an asynchronous app race. |
| 022 | functional-pass | Changing TYPE to IPv4 first yields IPv4 family/default VRF; recovery context is valid. |
| 023 | functional-pass | Explicit trace with corrected context restores Edge-C reachability at +601.025. |
| 024 | functional-pass | Transit scenario loads P1 as observation start and A as packet source; no trace result yet. |
| 025 | functional-pass | At prior inventory time +601.025, later-observed transit scenario stays incomplete in both directions. |
| 026 | functional-pass | Transit at +610.015999999 remains incomplete in both directions. |
| 027 | functional-pass | Exact +610.016 resolves forward P1 to B and return B to source A. |
| 028 | functional-pass | Return-only disables unused start and Forward tab; reachable return ends at A. |
| 029 | functional-pass | Forward-only restores observation start P1 and disables Return tab; reachable forward ends at B. |
| 030 | functional-pass | Both directions and All paths restore correct distinct observation and endpoint semantics. |
| 031 | functional-pass | At +610.018, E branch segments are Resolved, B branch is Incomplete, return has two candidates. Aggregate Trace is incomplete is intended: one selected active branch remains unknown. |
| 032 | functional-pass | At +610.019 both forward branches complete; summary correctly allows reachable asymmetric endpoint sets. |
| 033 | functional-pass | Rewind +610.018 makes B incomplete again; focused E remains Resolved. Aggregate incompleteness does not contradict focused branch success. |
| 034 | functional-pass | At +610.019 current forward branch resolves again. Snapshot remains Forward; title mentions return, but return switching is only established by35. |
| 035 | functional-pass | Return tab and focused E-to-A path are consistent. Saved snapshot shows ecmp-p1; it alone does not establish a separate alternate-branch selection. |
| 036 | functional-pass | Changing TYPE from EVPN to MPLS L3VPN correctly applies VPNv4/blue and invalidates prior result. |
| 037 | confirmed-finding | Parent recorded explicit default edit followed by selecting IPv4 FAMILY; settled DOM instead reads blue/VPNv4/MPLS-L3VPN. This is silent old-type-priority coercion, corroborated by existing change handler. |
| 038 | confirmed-finding | Same family-change operation repeats blue/VPNv4/MPLS-L3VPN. Confirms the same interaction finding, not a second defect. |

## Confirmed interaction finding

Moves37/38 support silent loss of explicit VRF/family edits. The shared change handler calls applyCompatibleRouteContext with no identity of the edited field. Its resolver always honors the existing route type first, so a family change incompatible with that old type snaps back, and a newly typed default VRF becomes blue. This is deterministic field-priority coercion, not a historical route or asynchronous-response defect. Type-first editing remains a working control. Moves20/21 did not trigger this behavior and must not be cited as reproductions.

## Limits

Functional-pass means the captured result supports the stated check; it is not an automated assertion or exhaustive validation. Moves34/35 substantiate only the saved direction/path state, not every action implied by their compound titles. Snapshot files include full details and line references are retained in route-review.json. No new performance claim follows from end-to-end tool times.
