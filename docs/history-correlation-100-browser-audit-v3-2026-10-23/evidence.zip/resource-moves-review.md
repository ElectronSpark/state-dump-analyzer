# Review of node moves40–80

Independent review of saved DOM snapshots and the move ledger. Classifications refer only to visible recorded state, not to an independently repeated browser run, performance threshold, or exhaustive pass. Action-only captures support navigation/filter operation, not all expectations in their ledger prose. Exact timestamps are supported by the range fields plus selected-moment state; the graph caption itself rounds to milliseconds.

| Move | Classification | Recorded evidence and limit |
| --- | --- | --- |
| 40 | Cursor control observed | Range starts240.01 and graph reports selected+240.010; this alone does not establish all resource semantics. |
| 41 | Action observed | ES table navigation at unchanged cursor. |
| 42 | Action observed | ES0 search at unchanged cursor; graph is not yet selected to ES0. |
| 43 | Defect reproduced | ES0 at+240.010 has service375 member_of_es/active_path before attachment. |
| 44 | Action observed | Disjoint ETG search while ES selection remains; empty current-kind rows are not a defect. |
| 45 | Boundary control observed | ETG375 row is single-home at+240.010; ES graph still exhibits early membership. |
| 46 | Defect reproduced | Focused ETG375 exposes member_of_es ES0 while its table says single-home. |
| 47 | Defect reproduced | At240.037499999 table single-home, early membership retained. |
| 48 | Boundary control observed | Exact240.037500000 changes ETG375 to all-active and adds backup ownership. |
| 49 | Defect reproduced | Rewind1ns returns table to single-home but leaves membership. |
| 50 | Defect reproduced across scope | Full graph also contains the early edge; truncation is disclosed. Does not prove entire full graph coverage. |
| 51 | Defect reproduced across scope | Focus selected recovers the same early membership at pre-attachment time. |
| 52 | Action observed | ETG749 search changes rows while preserving the cursor. |
| 53 | Defect reproduced on second identity | ETG749 is single-home yet attached to ES374 before its own attachment. |
| 54 | Defect reproduced on boundary | ETG749 remains single-home at240.074899999 with early ES membership. |
| 55 | Boundary control observed | Exact240.074900000 changes ETG749 to all-active. |
| 56 | Action observed | ES374 filter change; does not itself assert graph selection changed. |
| 57 | Table control observed | ES374 row up at unchanged cursor. |
| 58 | Correlation control observed | ES374 selected after both attachments; primary374 and primary749 active_path identities present. |
| 59 | Historical control observed | At360.0374 ES374 withdrawn while both service paths still primary. This stagger is intended. |
| 60 | Historical control observed | At360.0749 active_path is backup374 plus primary749. |
| 61 | Historical control observed | At360.1124 both active_paths are backups. |
| 62 | Backward control observed | At360.112399999 mixed backup374/primary749 returns. |
| 63 | Historical control observed | At480.0374 ES374 up while both paths remain backups. |
| 64 | Historical control observed | At480.0749 active_path is primary374 plus backup749. |
| 65 | Historical control observed | At480.1124 both paths primary. |
| 66 | Backward control observed | At480.112399999 mixed primary374/backup749 returns. |
| 67 | Action observed | VIF0 search does not advance the ES-selected cursor. |
| 68 | Table control observed | VIF0 row shows neighbor_count2 and all-active at480.112399999. |
| 69 | Correlation control observed | Focus VIF0 contains two has_neighbor identities, both up. |
| 70 | Boundary control observed | At120.037399999 VIF0 neighbor_count1; only peer0 association present. |
| 71 | Boundary control observed | Exact120.0374 gives count2 and adds peer374 association. |
| 72 | Backward control observed | Rewind1ns restores count1 and removes peer374 association. |
| 73 | Historical control observed | At360.037399999 both associations remain; peer0 down, peer374 up.9.457s complete move duration is a latency observation, not CPU attribution. |
| 74 | Historical control observed | Exact360.0374 both neighbors down, both structural associations remain. |
| 75 | Historical control observed | At480.037399999 peer0 up, peer374 down; associations/count unchanged. |
| 76 | Historical control observed | Exact480.0374 both neighbors up and count2. |
| 77 | Pointer defect reproduced | Intended peer374 edge opens peer0 resource card; see occlusion review. |
| 78 | Keyboard control observed | Enter on exact edge opens relationship has_neighbor VIF0→peer374. |
| 79 | Pointer defect reproduced | Repeated pointer action opens selected VIF0 resource card instead. |
| 80 | Target-node control observed | Actual peer374 node opens correct peer374 resource card. |

Within these41 moves:8 reproduce the shared-ES validity defect;2 reproduce the pointer occlusion defect;6 are action-only observations;25 establish the stated specific boundary/correlation/control observation. These are move classifications, not41 independent tests or defects.

No timing result is classified as a pass or regression. Move durations include automation actions, scrolling, snapshots, and asynchronous work. The known fresh-search/dashboard cost remains a separate investigation. See`resource-confirmed-findings.md` and`correlation-label-occlusion-review.md` for root-cause evidence and candidate limits.
