# Passive performance observations — 100-move browser audit v3

The hidden 1 Hz sampler stopped cleanly by stop file at 2026-10-23T22:43:19.457Z. It recorded 992 samples of demo Python PID 12380 from 2026-10-23T22:26:47.473Z to 2026-10-23T22:43:18.456Z; moves 1–3 preceded sampling. No server requests, replay workload, or benchmark were issued by the sampler.

| Process measurement | Observed |
|---|---:|
| Total process CPU during sample window | 314.562 s |
| Sample window wall time | 990.983 s |
| First / last RSS snapshot | 2.251 / 2.990 GiB |
| Maximum sampled RSS | 3.037 GiB |
| First / last private snapshot | 2.242 / 2.983 GiB |
| Maximum sampled private memory | 3.032 GiB |

## Search delay: cold construction and restart, not a new demonstrated warm-search defect

The largest sustained CPU episode ran 2026-10-23T22:39:58.465Z–2026-10-23T22:41:31.471Z: 93.219 process CPU seconds over 93.005 wall seconds. It overlaps moves 81–89 and some other resource operations; it is not an isolated search-thread measurement.

Move 81 started the exact-ID search at 2026-10-23T22:39:58.786Z. It remained pending until cleared in move 84 about 40.1 s later; approximately 40.3 process CPU s accrued in that interval. Browser progress reached 1,039,360 records before clear (move 84) and 1,052,672 in the immediate next capture (move 85). Resource table and correlation interactions remained responsive during the search.

The process's allowlisted path variables establish LOCALAPPDATA/RouterDumpAnalyzer/cache as its effective cache; no search-cache override was present. The regenerated node archive computes identity `9142c5657c9d2e3680ea06a7bacb7f760b3e61c9519a5bfaa06b878011c694f0`. Its matching newly published sidecar is 75,038,720 bytes, v7, complete=1, with 1,250,005 documents. Creation 2026-10-23T22:40:39.912098+00:00 aligns with the replacement search (move 85), and last write 2026-10-23T22:41:31.226407+00:00 precedes the settled move-90 result. That published file's lifetime is 51.3 s, with approximately 51.8 process CPU s.

This is direct evidence that a new corpus was published during the delay. The creation time after cancellation, the observed progress reset reported by the browser driver, and `HistorySearchCorpus.ensure`'s cancellation cleanup/retry path support an interrupted first build followed by a second build. Without request-level spans, this remains an attribution inference; no claim is made that every CPU second belongs to construction. The old sidecar has a different identity and cannot be reused safely for this archive.

Cold first-search construction was already documented at ~46.7 s in `docs/root-cause-repairs-2026-10-22.md`; the earlier ~5 s reopened-sidecar diagnosis in `docs/frontend-review-marker-audit-2026-10-21.md` describes a different path. The final ~51 s build window is consistent with cold construction plus concurrent UI requests. Record this as an existing performance limitation with evidence of cancellation/retry amplification, not a newly established regression.

| Settled browser control | Workflow wall | One-Hz estimated process CPU |
|---|---:|---:|
| Move 96: Repeat exact event-ID search after index construction | 3.002 s | 2.090 s |
| Move 99: Restore unfiltered normalized stream | 0.785 s | 0.129 s |
| Move 100: Repeat exact ES374 event search warm | 0.660 s | 0.101 s |

Moves 96 and 100 each returned the exact one-match event result. These warm controls do not reproduce a sustained stall. The first uncached term after corpus readiness still costs more than a same-term cached repeat; the sampler does not isolate decompression/search from other serving work.

## Other interpretations

- Move 5's 20.8 s was a harness wait for a route-outcome predicate while the UI already displayed a deterministic validation error. It is not UI latency; only ~0.65 process CPU s occurred in its wider sampled interval.
- Repeated historical cursor workflows produced additional multi-second CPU episodes. They are consistent with previously documented temporal reconstruction, search, and dashboard costs; no new isolated performance regression was established.
- RSS increased across the broader live workflow and remained ~2.990 GiB at the final snapshot. Lazy-history reconstruction and caches are part of that workload. No isolated repeat/retirement experiment proves a leak; do not compare the observed peak directly to the narrower 52-phase benchmark's peak as if the workloads matched.

## Limits

- Move elapsed time includes browser actions, rendering, waits and tool overhead.
- Move CPU is interpolated from adjacent one-Hz cumulative samples, not request-specific. The bracket is a wider measured interval, not proof of causation.
- Requests can continue after the UI action snapshot; episode overlaps and neighboring move IDs provide context only.
- Maximum sampled RSS/private values are one-Hz snapshots and can miss shorter peaks. Process-lifetime peak fields predate this audit and are not audit peaks.
- CPU percent is relative to one logical core and can exceed 100% if multiple threads execute.

Evidence: `process-samples.jsonl`, `process-summary.json`, `process-summary.md`, `final-performance.json`, `live-demo-cache-paths.json`, `live-search-sidecar.json`, move snapshots 81–90 and 96–100. Source inspections are read-only; no product or maintained author documentation changed.
