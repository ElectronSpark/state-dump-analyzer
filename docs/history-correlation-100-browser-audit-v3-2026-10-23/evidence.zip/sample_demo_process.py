"""One-Hz Windows process CPU/RSS monitor for the browser audit only."""
from __future__ import annotations

import argparse
import ctypes
from ctypes import wintypes
from datetime import datetime, timezone
import json
from pathlib import Path
import time


class ProcessMemoryCounters(ctypes.Structure):
    _fields_ = [
        ("cb", wintypes.DWORD), ("PageFaultCount", wintypes.DWORD),
        ("PeakWorkingSetSize", ctypes.c_size_t), ("WorkingSetSize", ctypes.c_size_t),
        ("QuotaPeakPagedPoolUsage", ctypes.c_size_t), ("QuotaPagedPoolUsage", ctypes.c_size_t),
        ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t), ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
        ("PagefileUsage", ctypes.c_size_t), ("PeakPagefileUsage", ctypes.c_size_t),
        ("PrivateUsage", ctypes.c_size_t),
    ]


def utc_now():
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def ft_int(value):
    return (value.dwHighDateTime << 32) | value.dwLowDateTime


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--pid", type=int, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--stop-file", type=Path, required=True)
    parser.add_argument("--duration", type=float, default=2700)
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    psapi = ctypes.WinDLL("psapi", use_last_error=True)
    kernel32.OpenProcess.argtypes = (wintypes.DWORD, wintypes.BOOL, wintypes.DWORD)
    kernel32.OpenProcess.restype = wintypes.HANDLE
    kernel32.GetProcessTimes.argtypes = (wintypes.HANDLE,) + (ctypes.POINTER(wintypes.FILETIME),) * 4
    kernel32.GetProcessTimes.restype = wintypes.BOOL
    kernel32.GetExitCodeProcess.argtypes = (wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD))
    kernel32.GetExitCodeProcess.restype = wintypes.BOOL
    kernel32.CloseHandle.argtypes = (wintypes.HANDLE,)
    kernel32.CloseHandle.restype = wintypes.BOOL
    psapi.GetProcessMemoryInfo.argtypes = (wintypes.HANDLE, ctypes.POINTER(ProcessMemoryCounters), wintypes.DWORD)
    psapi.GetProcessMemoryInfo.restype = wintypes.BOOL
    handle = kernel32.OpenProcess(0x1000 | 0x10, False, args.pid)
    if not handle:
        raise ctypes.WinError(ctypes.get_last_error())
    start = time.monotonic()
    count = 0
    reason = "duration"
    try:
        with args.output.open("x", encoding="utf-8", buffering=1) as output:
            output.write(json.dumps({"kind": "start", "utc": utc_now(), "epoch_ns": time.time_ns(), "pid": args.pid, "sample_period_s": 1, "hard_duration_s": args.duration, "stop_file": str(args.stop_file), "metrics": "demo Python process only; working-set/private snapshots, cumulative CPU; not browser heap"}) + "\n")
            deadline = start
            while time.monotonic() - start < args.duration:
                if args.stop_file.exists():
                    reason = "stop_file"
                    break
                exit_code = wintypes.DWORD()
                if not kernel32.GetExitCodeProcess(handle, ctypes.byref(exit_code)):
                    raise ctypes.WinError(ctypes.get_last_error())
                if exit_code.value != 259:
                    reason = "target_exited"
                    break
                creation, exit_time, kernel, user = (wintypes.FILETIME() for _ in range(4))
                memory = ProcessMemoryCounters()
                memory.cb = ctypes.sizeof(memory)
                if not kernel32.GetProcessTimes(handle, ctypes.byref(creation), ctypes.byref(exit_time), ctypes.byref(kernel), ctypes.byref(user)):
                    raise ctypes.WinError(ctypes.get_last_error())
                if not psapi.GetProcessMemoryInfo(handle, ctypes.byref(memory), memory.cb):
                    raise ctypes.WinError(ctypes.get_last_error())
                output.write(json.dumps({"kind": "sample", "utc": utc_now(), "epoch_ns": time.time_ns(), "elapsed_s": time.monotonic() - start, "cpu_s": (ft_int(kernel) + ft_int(user)) / 10_000_000, "user_cpu_s": ft_int(user) / 10_000_000, "kernel_cpu_s": ft_int(kernel) / 10_000_000, "rss_bytes": memory.WorkingSetSize, "private_bytes": memory.PrivateUsage, "process_lifetime_peak_rss_bytes": memory.PeakWorkingSetSize, "process_lifetime_peak_private_bytes": memory.PeakPagefileUsage}) + "\n")
                count += 1
                deadline += 1
                time.sleep(max(0, deadline - time.monotonic()))
            output.write(json.dumps({"kind": "stop", "utc": utc_now(), "epoch_ns": time.time_ns(), "elapsed_s": time.monotonic() - start, "samples": count, "reason": reason}) + "\n")
    finally:
        kernel32.CloseHandle(handle)


if __name__ == "__main__":
    main()
