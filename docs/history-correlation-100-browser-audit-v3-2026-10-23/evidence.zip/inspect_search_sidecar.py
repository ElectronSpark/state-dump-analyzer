"""Read only the current demo's declared search cache identity and metadata."""
from datetime import datetime, timezone
import json
from pathlib import Path
import sqlite3

from rsl_demo_plugin.scale_data import _history_search_identity

root = Path(__file__).resolve().parent
archive = root.parent / "history-correlation-repairs-v2-2026-10-23/server-temp/router-dump-plugin-assembly-hzvwcmfk/000-node-a.tgz"
paths = json.loads((root / "live-demo-cache-paths.json").read_text(encoding="utf-8-sig"))["environment"]
identity = _history_search_identity(archive)
cache = Path(paths["ROUTER_DUMP_SEARCH_CACHE_DIR"]) if paths["ROUTER_DUMP_SEARCH_CACHE_DIR"] else Path(paths["LOCALAPPDATA"]) / "RouterDumpAnalyzer/cache"
sidecar = cache / f"{archive.stem}-{identity[:24]}.history-search.sqlite3"
stat = sidecar.stat()
with sqlite3.connect(sidecar.as_uri() + "?mode=ro", uri=True) as connection:
    connection.row_factory = sqlite3.Row
    metadata = dict(connection.execute("SELECT * FROM metadata WHERE singleton=1").fetchone())
result = {
    "inspected_utc": datetime.now(timezone.utc).isoformat(),
    "target_pid": 12380,
    "archive": str(archive),
    "identity": identity,
    "sidecar": str(sidecar),
    "bytes": stat.st_size,
    "created_utc": datetime.fromtimestamp(stat.st_ctime, timezone.utc).isoformat(),
    "written_utc": datetime.fromtimestamp(stat.st_mtime, timezone.utc).isoformat(),
    "metadata": metadata,
    "identity_matches_metadata": metadata["identity"] == identity,
    "limits": "Read-only metadata check only; not a full integrity scan or a request span. File times alone do not establish every canceled build attempt.",
}
(root / "live-search-sidecar.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
print(json.dumps(result, indent=2))
