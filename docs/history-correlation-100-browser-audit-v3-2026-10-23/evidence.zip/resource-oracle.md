# Single-node correlation oracle — third 100-move audit

Read-only support at commit `052903ee0bfb498357fa851b98d622ec9fc81d4c`, 2026-10-23. These are source-derived expectations and candidate checks, **not executed browser moves or confirmed browser defects**. No server, browser, benchmark, product source, or maintained author documentation was changed.

Read `AGENTS.md`, the router-plugin-validate skill, the API validation map's historical/correlation checks, the second audit oracle, the last repair report, and current generator/frontend source. Used the configured Python 3.12 environment to evaluate selected generator events only; no archive generation or million-event load.

## Time and identity conventions

All offsets are seconds from the node's native origin. UTC base is `1759680000000000000` ns. Native origins: PE-A `1759679999996000000`; PE-B `1759680000006000000`; PE-C `1759680000011000000`; PE-D `1759679999992000000`; PE-E `1759680000014000000`; transit-P1 `1759680000001000000`; transit-P2 `1759679999998000000`.

For exact browser selection, use range `[T,T+0.000000001]`, then Actions → Select this moment. Applying a range alone does not change the cursor. Wait independently for resource table and graph refreshes. Use exact displayed cursor evidence, because capture-edge range clamping can shift T.

Prefix local IDs with `node-a/`, or the selected node's namespace. Alternate identities:

| Alias | Local resource ID |
| --- | --- |
| ES374 | `control-plane/EVPN_ES/es-00374` |
| ES0 | `control-plane/EVPN_ES/es-00000` |
| VIF0 | `data-bridge-layer/VIRTUAL_INTERFACE/ae-00000` |
| VIF373 | `data-bridge-layer/VIRTUAL_INTERFACE/ae-00373` |
| Neighbor374 | `control-plane/NEIGHBOR/blue/peer-00374` |
| Neighbor0 | `control-plane/NEIGHBOR/blue/peer-00000` |
| ETG375 | `data-bridge-layer/ETG/blue/etg-000375` |
| ETG374 | `data-bridge-layer/ETG/blue/etg-000374` |
| ETG749 | `data-bridge-layer/ETG/blue/etg-000749` |
| Primary/backup374 | `data-bridge-layer/ETE/etg-000374/primary` or `/backup` |
| Primary/backup749 | `data-bridge-layer/ETE/etg-000749/primary` or `/backup` |

Canonical layout has 1,875 ETGs/DTEs/primary ETEs, 750 backup ETEs, 375 Ethernet Segments/neighbors, **374** virtual interfaces, and one IP-routing fallback. Each ES has two actual service attachments in this layout, separated by 375 service indices. ES374 therefore has services374 and749. VIF0 has two neighbors (0 and374); other VIFs have one. ES374 has no direct `uses_interface` attachment because there is no VIF374. That absence is intended; it does not make neighbor374 absent (neighbor374 uses VIF0).

## Exact discriminating boundaries

Event UIDs in the table acquire the node prefix in an assembly.

| Offset | Event UID suffix | Expected state/relationship change |
| ---: | --- | --- |
| +120.000000000 | `scale-event-00000000` | VIF0 and neighbor0 created; VIF0 neighbor count1, outgoing `has_neighbor`→neighbor0. |
| +120.037399999 | — | Neighbor374 absent; VIF0 still count1. |
| +120.037400000 | `scale-event-00000374` | Neighbor374 created; VIF0 count2 and second `has_neighbor`→neighbor374. Neighbor374 protocol ARP, address172.20.1.121, local interfaceae-00000. |
| +240.000000000 | `scale-event-00312500` | ES0 created and service0 attached; VIF0 becomes all-active, ES0 uses VIF0. Service375 has not yet attached. |
| +240.037400000 | `scale-event-00312874` | ES374 created and service374 attached; backup374 created standby. No direct uses_interface edge on ES374. |
| +240.037500000 | `scale-event-00312875` | Service375 attaches to ES0; backup375 created; ETG375 becomes all-active and gains `member_of_es`→ES0; ES0 gains `active_path`→primary375. |
| +240.074900000 | `scale-event-00313249` | Service749 attaches to ES374; backup749 created; ETG749 all-active and member_of_es ES374. |
| +360.000000000 | `scale-event-00500000` | ES0 withdrawn and neighbor0 down/expired/unreachable. ES0→VIF0 `uses_interface` removed. VIF0 itself remains up with both neighbor identities. |
| +360.037399999 | — | Neighbor374 still up/reachable; neighbor0 down. Both VIF0 `has_neighbor` relations remain. |
| +360.037400000 | `scale-event-00500374` | ES374 withdrawn and neighbor374 down/expired/unreachable. Primary374/749 are still active until their later service failovers. |
| +360.074900000 | `scale-event-00500749` | Service374 failover: primary374 down, backup374 active, ETG374 degraded and selected_egress→backup374; ES374 active_path for374 changes to backup374; DTE374→IP_ROUTING. Service749 remains on primary. |
| +360.112400000 | `scale-event-00501124` | Service749 failover: primary749 down, backup749 active, ETG749 degraded and selected_egress→backup749; ES374's second active_path changes to backup749; DTE749→ETG750. |
| +480.000000000 | `scale-event-00750000` | ES0 restored and neighbor0 up/reachable. Neighbor374 still down until its distinct restoration. |
| +480.037399999 | — | Neighbor0 up, neighbor374 down; VIF0 still has both identities. |
| +480.037400000 | `scale-event-00750374` | ES374 and neighbor374 restored; both ES374 service paths still use backups. |
| +480.074900000 | `scale-event-00750749` | Service374 restored; primary374 active, backup374 standby, selected_egress/active_path return to primary374. Service749 still uses backup. |
| +480.112400000 | `scale-event-00751124` | Service749 restored similarly; DTE749→ETG749. |

Each boundary is half-open: at T−1ns retain the earlier state; at T use the changed state. Ownership of both ETEs remains during failover. `owns` is not equivalent to `selected_egress`; `has_neighbor` is a structural identity association and remains while a neighbor is down. ES state changes before dependent service failovers, so withdrawn ES with still-primary service is valid transient history.

## New source lead worth browser confirmation

`_relationship_lines()` in `demo/rsl_demo_generator/_scale.py` starts every ETG→ES `member_of_es` and ES→primary `active_path` at phase-wide `multi_start`, while `_event_for_phase()` adds those relationships at each service's actual multihome event. Endpoint lifecycle filtering masks this for the first 375 services because ES creation is delayed. It cannot mask second-wave services whose ES already exists.

For example at **+240.010000000** or **+240.037499999**, ES0 and primary375 both exist. Applied event history says ETG375 is still single-home, backup375 absent, and no ES0→primary375 or ETG375→ES0 relationship should exist until **+240.037500000** (`scale-event-00312875`). Persisted relationship rows may expose both early. Compare table state, correlation list, and exact attachment event. Repeat at the exact boundary and backwards. A matching early edge is a generator historical-projection consistency defect, not automatically stale frontend state. This remains a source-only candidate until observed through the browser.

The same discriminant on ES374 is just before/exact **+240.074900000** for ETG749→ES374 and ES374→primary749. `uses_interface` uses exact per-ES times already, so it provides an independent control.

## Suggested new operations to combine into the parent's 100 moves

1. Select VIF0 before neighbor374 creation, then exact creation and back1ns; compare neighbor_count against two has_neighbor edges.
2. Open neighbor374 through the relation index; verify its node namespace and local interfaceVIF0.
3. Change resource kind/search without changing cursor; selected graph identity must stay deliberate and not silently become a similarly named other kind.
4. Select ES0 before/exact service375 attachment; inspect incoming member_of_es and outgoing active_path separately, then compare ETG375 single-home/all-active table state.
5. Repeat that future-attachment control on ES374/service749.
6. At +360.037399999 inspect both VIF0 neighbors; only neighbor0 should be down.
7. Advance1ns to neighbor374 withdrawal; both down, relationships retained.
8. Select ES374 while both services still primary, then advance to first service failover; inspect mixed primary749/backup374 active_paths.
9. Advance to second service failover; both backups. Go back to mixed state; no retained second-path highlight/selection may change data semantics.
10. Pin primary374's edge card, move cursor across its replacement by backup374, then inspect the surviving owns edge; stale semantic pin must not claim selected_egress.
11. At restore boundaries compare mixed primary374/backup749 before both-primary restoration; ownership remains stable.
12. Inspect VIF0 at +480.037399999 then +480.037400000; count remains2 while only reachability changes.
13. Cross from correlation endpoint to timeline, hide/reveal a layer, switch combined/separate lanes, and compare selected instant with viewport-wide historical ribbons.
14. Show all correlations then Focus selected for ES374 and neighbor374; bounded omission must say Not covered, not zero relationships.
15. Repeat after searching a disjoint term; table search does not prove graph absence or a changed cursor.
16. Open another node (PE-B or transit-P1) via fabric, repeat one boundary using that node's native origin, then return to PE-A. Same numeric native offset yields same local scale history; absolute native timestamps differ.
17. Use actual browser Back across fabric/node and settled table filter changes; restored labels must match returned rows and node namespace.
18. Compare fresh searched cursor after3+distinct times against exact repeats, with the same open dashboards; record UI settling separately from CPU attribution.

## Coverage and performance limits

The previous repair fixed response-coverage labels and narrow popup interception. Full scale graph is still representative/bounded; a depth/cap-limited response does not establish the entire population's absence. Expanded list entries are returned relationships, not necessarily all historical relationships. Graph instant, lane range and table filter remain distinct controls.

Fresh active search still reconstructs/search-projects all7,510 resources to maintain cross-kind counts, with only two timestamp search snapshots. Last controlled production-service medians were1.524s active search and1.104s open dashboards, while first lazy history initialization took6.888s. Those are known costs, not new regressions. A new browser delay needs exact timestamps, search state, dashboard state, repeated/cold classification, and measured settlement boundaries. Tool latency is not CPU time.

Documentation drift check: support-only ignored evidence document, no author-visible behavior or API changes; no maintained author documentation update required.
