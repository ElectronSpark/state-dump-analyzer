# Correlation edge label occlusion review

Independent source/snapshot review at052903e; no browser actions were performed by this reviewer. Read moves77–80, inspected`correlation-edge-popup.png`, and reviewed the existing focus layout, edge geometry, CSS stacking and activation handlers.

## Finding

At the narrow browser width, with VIF0 selected at+480.037400000, the `has_neighbor` label for peer00374 is covered by resource cards. Pointer activation of the intended edge produces a resource popup; Enter on the same accessible edge produces the correct relationship popup.

- Move77 ends in **RESOURCE STATE peer-00000**, despite the intended edge target being peer00374.
- Move78 ends in **RELATIONSHIP has_neighbor**, sourceVIF0 and targetpeer00374, and marks that exact edge pressed/active.
- Move79 ends in **RESOURCE STATE ae-00000**, reproducing pointer diversion after the keyboard control.
- Move80 opens **RESOURCE STATE peer-00374** through its actual node, confirming the target resource and its own handler are correct.
- The parent reports a DOM`elementsFromPoint` observation at the edge label center that hits the selected VIF0 node above the edge. The screenshot independently shows the crowded selected/output cards and VIF0 popup; it does not by itself establish the sampled hit-test coordinate.

This is a **layout/hit-target occlusion defect**, not evidence that the edge listener captures the wrong ID. The locator-based pointer action follows the target's coordinate and is redirected by a real overlapping element. It should not be described as every visible point of the edge being inaccessible without further coordinate sampling. Keyboard and node controls show that the underlying relationship identity is sound.

## Cause in existing code

- `frontend/assets/app.js:7196`(`focusGraphLayout`) fixes incoming/selected/outgoing columns at15/50/85percent and only scales vertical height. It does not reserve a horizontal label corridor using actual card dimensions.
- `app.js:7659`(`graphEdgeGeometry`) chooses horizontal midpoint labels between endpoints;`:7680–7686` applies a small vertical offset rather than checking node rectangles. For outgoing edges the label center remains67.5percent of stage width.
- `frontend/assets/styles.css:4713–4718` retains132px neighboring cards and146px selected cards below760px. The outgoing label center is only17.5percent of stage width from the selected center: for a stage narrower than~417px, the center lies inside the selected card's73px half-width. With two outgoing neighbors their labels are also close vertically to the selected card.
- The SVG edge layer has z-index1 (`styles.css:1342–1349`); resource nodes have z-index2 (`:1388–1402`) and selected/hovered nodes4 (`:1404–1409`). Thus overlapped labels correctly lose physical pointer hit testing to cards, despite their own`pointer-events:all`(`:4236–4246`).
- Edge pointer and Enter/Space listeners both use the same captured edge inspection (`app.js:7905–7926`). A handler-ID patch would not address the observed cause.

For a later fix, preserve edge/node identity logic and repair the existing responsive geometry so labels and node hit targets have separate reachable areas. Merely raising the entire SVG above cards could invert the interception problem. Validate actual hit tests at narrow widths after focus changes, not only DOM label presence or keyboard activation.

Documentation drift: ignored audit evidence only; no product or author contract changed.
