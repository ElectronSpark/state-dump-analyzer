"""Record the final passive performance observations, without replaying work."""
from bisect import bisect_left
from datetime import datetime
import json
from pathlib import Path

root = Path(__file__).resolve().parent
summary = json.loads((root / "process-summary.json").read_text(encoding="utf-8"))
sidecar = json.loads((root / "live-search-sidecar.json").read_text(encoding="utf-8"))
records = [json.loads(line) for line in (root / "process-samples.jsonl").read_text(encoding="utf-8").splitlines()]
samples = [row for row in records if row["kind"] == "sample"]
moves = json.loads((root / "moves.json").read_text(encoding="utf-8"))
times = [row["epoch_ns"] / 1e9 for row in samples]
by_move = {row["id"]: row for row in summary["moves"]}


def epoch(text):
    return datetime.fromisoformat(text.replace("Z", "+00:00")).timestamp()


def cpu(at):
    index = bisect_left(times, at)
    if index == 0:
        return samples[0]["cpu_s"]
    if index == len(times):
        return samples[-1]["cpu_s"]
    left, right = samples[index - 1], samples[index]
    ratio = (at - times[index - 1]) / (times[index] - times[index - 1])
    return left["cpu_s"] + ratio * (right["cpu_s"] - left["cpu_s"])


def span(name, start, end):
    return {"name": name, "start_utc": start, "end_utc": end, "wall_s": epoch(end) - epoch(start), "process_cpu_estimate_s": cpu(epoch(end)) - cpu(epoch(start))}


move_lookup = {row["n"]: row for row in moves}
search_episode = max(summary["cpu_episodes"], key=lambda row: row["cpu_s"])
first_attempt = span("Original search start until clear-search move", move_lookup[81]["started_at"], move_lookup[84]["started_at"])
published_build = span("Published sidecar creation through final write", sidecar["created_utc"], sidecar["written_utc"])
gib = 1024 ** 3
result = {
    "scope": summary["scope"],
    "stop": summary["stop"],
    "sample_count": summary["sample_count"],
    "uncovered_move_ids": [row["id"] for row in summary["moves"] if not row["fully_sampled"]],
    "sample_wall_s": summary["sample_wall_s"],
    "process_cpu_s": summary["cpu_delta_s"],
    "first_rss_gib": samples[0]["rss_bytes"] / gib,
    "last_rss_gib": samples[-1]["rss_bytes"] / gib,
    "max_sampled_rss_gib": summary["max_sampled_rss_bytes"] / gib,
    "first_private_gib": samples[0]["private_bytes"] / gib,
    "last_private_gib": samples[-1]["private_bytes"] / gib,
    "max_sampled_private_gib": summary["max_sampled_private_bytes"] / gib,
    "cold_search_episode": search_episode,
    "first_search_attempt": first_attempt,
    "published_build_window": published_build,
    "sidecar": sidecar,
    "warm_search_moves": [by_move[number] for number in (96, 99, 100)],
    "classifications": {
        "move_5": "Harness settlement predicate timed out while UI displayed an invalid-inventory error. Not a measured UI performance defect.",
        "moves_81_to_90": "Existing cold-index construction cost reproduced on a new archive identity. Sustained CPU and a newly published sidecar distinguish it from a UI-only stall or old-sidecar reopening. Search cancellation/retry likely discarded partial construction; exact request attribution was not traced.",
        "moves_96_to_100": "After construction the exact-ID search returned one match in 3.002 s workflow wall; clear and same-term repeat took 0.785 and 0.660 s. These include UI/tool overhead. No sustained warm-search stall reproduced.",
        "memory": "Observed process RSS retention across lazy histories, searches, graphs, and dashboard work. This is a richer live workload than the 52-phase core benchmark; no isolated before/after replay or leak test establishes a new leak.",
    },
    "known_reports": [
        "docs/frontend-review-marker-audit-2026-10-21.md:268 (earlier sidecar-reopen/temporal-contention diagnosis)",
        "docs/root-cause-repairs-2026-10-22.md:50 (known cold construction ~46.7 s; cancellation cleanup retained)",
        "docs/history-correlation-repairs-v2-2026-10-23/README.md (remaining cursor, dashboard, and lazy-history costs)",
    ],
    "limits": summary["limits"],
}
(root / "final-performance.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
lines = [
    "# Passive performance observations — 100-move browser audit v3", "",
    f"The hidden 1 Hz sampler stopped cleanly by stop file at {summary['stop']['utc']}. It recorded {summary['sample_count']} samples of demo Python PID 12380 from {summary['sample_start_utc']} to {summary['sample_end_utc']}; moves 1–3 preceded sampling. No server requests, replay workload, or benchmark were issued by the sampler.", "",
    "| Process measurement | Observed |", "|---|---:|",
    f"| Total process CPU during sample window | {result['process_cpu_s']:.3f} s |",
    f"| Sample window wall time | {result['sample_wall_s']:.3f} s |",
    f"| First / last RSS snapshot | {result['first_rss_gib']:.3f} / {result['last_rss_gib']:.3f} GiB |",
    f"| Maximum sampled RSS | {result['max_sampled_rss_gib']:.3f} GiB |",
    f"| First / last private snapshot | {result['first_private_gib']:.3f} / {result['last_private_gib']:.3f} GiB |",
    f"| Maximum sampled private memory | {result['max_sampled_private_gib']:.3f} GiB |", "",
    "## Search delay: cold construction and restart, not a new demonstrated warm-search defect", "",
    f"The largest sustained CPU episode ran {search_episode['start_utc']}–{search_episode['end_utc']}: {search_episode['cpu_s']:.3f} process CPU seconds over {search_episode['wall_s']:.3f} wall seconds. It overlaps moves 81–89 and some other resource operations; it is not an isolated search-thread measurement.", "",
    f"Move 81 started the exact-ID search at {move_lookup[81]['started_at']}. It remained pending until cleared in move 84 about {first_attempt['wall_s']:.1f} s later; approximately {first_attempt['process_cpu_estimate_s']:.1f} process CPU s accrued in that interval. Browser progress reached 1,039,360 records before clear (move 84) and 1,052,672 in the immediate next capture (move 85). Resource table and correlation interactions remained responsive during the search.", "",
    f"The process's allowlisted path variables establish LOCALAPPDATA/RouterDumpAnalyzer/cache as its effective cache; no search-cache override was present. The regenerated node archive computes identity `{sidecar['identity']}`. Its matching newly published sidecar is {sidecar['bytes']:,} bytes, v7, complete=1, with {sidecar['metadata']['document_count']:,} documents. Creation {sidecar['created_utc']} aligns with the replacement search (move 85), and last write {sidecar['written_utc']} precedes the settled move-90 result. That published file's lifetime is {published_build['wall_s']:.1f} s, with approximately {published_build['process_cpu_estimate_s']:.1f} process CPU s.", "",
    "This is direct evidence that a new corpus was published during the delay. The creation time after cancellation, the observed progress reset reported by the browser driver, and `HistorySearchCorpus.ensure`'s cancellation cleanup/retry path support an interrupted first build followed by a second build. Without request-level spans, this remains an attribution inference; no claim is made that every CPU second belongs to construction. The old sidecar has a different identity and cannot be reused safely for this archive.", "",
    "Cold first-search construction was already documented at ~46.7 s in `docs/root-cause-repairs-2026-10-22.md`; the earlier ~5 s reopened-sidecar diagnosis in `docs/frontend-review-marker-audit-2026-10-21.md` describes a different path. The final ~51 s build window is consistent with cold construction plus concurrent UI requests. Record this as an existing performance limitation with evidence of cancellation/retry amplification, not a newly established regression.", "",
    "| Settled browser control | Workflow wall | One-Hz estimated process CPU |", "|---|---:|---:|",
    *[f"| Move {number}: {by_move[number]['action']} | {by_move[number]['workflow_wall_s']:.3f} s | {by_move[number]['cpu_estimate_s']:.3f} s |" for number in (96, 99, 100)], "",
    "Moves 96 and 100 each returned the exact one-match event result. These warm controls do not reproduce a sustained stall. The first uncached term after corpus readiness still costs more than a same-term cached repeat; the sampler does not isolate decompression/search from other serving work.", "",
    "## Other interpretations", "",
    "- Move 5's 20.8 s was a harness wait for a route-outcome predicate while the UI already displayed a deterministic validation error. It is not UI latency; only ~0.65 process CPU s occurred in its wider sampled interval.",
    "- Repeated historical cursor workflows produced additional multi-second CPU episodes. They are consistent with previously documented temporal reconstruction, search, and dashboard costs; no new isolated performance regression was established.",
    "- RSS increased across the broader live workflow and remained ~2.990 GiB at the final snapshot. Lazy-history reconstruction and caches are part of that workload. No isolated repeat/retirement experiment proves a leak; do not compare the observed peak directly to the narrower 52-phase benchmark's peak as if the workloads matched.", "",
    "## Limits", "",
    *[f"- {limit}" for limit in summary["limits"]], "",
    "Evidence: `process-samples.jsonl`, `process-summary.json`, `process-summary.md`, `final-performance.json`, `live-demo-cache-paths.json`, `live-search-sidecar.json`, move snapshots 81–90 and 96–100. Source inspections are read-only; no product or maintained author documentation changed.",
]
(root / "final-performance.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
print(json.dumps({key: result[key] for key in ("sample_count", "process_cpu_s", "first_rss_gib", "last_rss_gib", "max_sampled_rss_gib", "max_sampled_private_gib", "first_search_attempt", "published_build_window")}))
