# Demo process observations

Read-only 1-Hz snapshots of demo Python process PID 12380. Not browser heap; no isolated backend benchmark.

992 samples from 2026-10-23T22:26:47.473Z to 2026-10-23T22:43:18.456Z; 314.562 s CPU over 990.983 s wall time.
RSS snapshots: first 2.251 GiB, last 2.990 GiB, maximum 3.037 GiB. Maximum private snapshot 3.032 GiB.

## Largest CPU episodes

| UTC interval | CPU s | Wall s | Max sampled RSS GiB | Overlapping moves |
|---|---:|---:|---:|---|
| 2026-10-23T22:39:58.465Z – 2026-10-23T22:41:31.471Z | 93.219 | 93.005 | 3.037 | 80, 81, 82, 83, 84, 85, 86, 87, 88, 89 |
| 2026-10-23T22:38:38.464Z – 2026-10-23T22:39:04.463Z | 22.922 | 25.999 | 3.017 | 72, 73, 74, 75, 76 |
| 2026-10-23T22:37:22.460Z – 2026-10-23T22:37:50.462Z | 22.094 | 28.001 | 2.965 | 62, 63, 64, 65, 66 |
| 2026-10-23T22:34:49.471Z – 2026-10-23T22:35:08.465Z | 17.609 | 18.995 | 2.886 | 38, 39 |
| 2026-10-23T22:34:15.466Z – 2026-10-23T22:34:35.463Z | 14.422 | 19.997 | 2.287 | 32, 33, 34 |
| 2026-10-23T22:36:58.462Z – 2026-10-23T22:37:16.473Z | 13.016 | 18.011 | 2.965 | 57, 58, 59, 60, 61 |
| 2026-10-23T22:31:48.473Z – 2026-10-23T22:32:05.467Z | 12.672 | 16.994 | 2.268 | 12, 13, 14 |
| 2026-10-23T22:33:17.463Z – 2026-10-23T22:33:35.473Z | 12.453 | 18.010 | 2.276 | 24, 25, 26, 27 |
| 2026-10-23T22:28:56.476Z – 2026-10-23T22:29:13.469Z | 12.281 | 16.993 | 2.258 | 6, 7, 8 |
| 2026-10-23T22:42:05.460Z – 2026-10-23T22:42:17.467Z | 11.359 | 12.007 | 2.993 | 94, 95 |
| 2026-10-23T22:33:43.462Z – 2026-10-23T22:34:01.473Z | 10.984 | 18.011 | 2.285 | 28, 29, 30, 31 |
| 2026-10-23T22:31:25.476Z – 2026-10-23T22:31:37.466Z | 9.141 | 11.991 | 2.267 | 9, 10 |
| 2026-10-23T22:36:35.474Z – 2026-10-23T22:36:48.471Z | 8.703 | 12.998 | 2.960 | 53, 54, 55 |
| 2026-10-23T22:38:21.468Z – 2026-10-23T22:38:32.459Z | 8.219 | 10.991 | 3.000 | 68, 69, 70, 71 |
| 2026-10-23T22:36:10.473Z – 2026-10-23T22:36:19.462Z | 7.375 | 8.988 | 2.956 | 48, 49, 50, 51 |
| 2026-10-23T22:35:55.462Z – 2026-10-23T22:36:03.468Z | 5.156 | 8.006 | 2.950 | 45, 46, 47 |
| 2026-10-23T22:41:50.467Z – 2026-10-23T22:41:56.470Z | 4.875 | 6.003 | 2.991 | 92, 93 |
| 2026-10-23T22:35:22.473Z – 2026-10-23T22:35:31.463Z | 4.812 | 8.990 | 2.931 | 40, 41, 42 |
| 2026-10-23T22:32:56.466Z – 2026-10-23T22:33:00.468Z | 3.219 | 4.002 | 2.268 | 22, 23 |
| 2026-10-23T22:42:26.457Z – 2026-10-23T22:42:29.459Z | 2.188 | 3.002 | 2.998 | 96 |

## Interpretation limits

- Move elapsed time includes browser actions, rendering, waits and tool overhead.
- Move CPU is interpolated from adjacent one-Hz cumulative samples, not request-specific. The bracket is a wider measured interval, not proof of causation.
- Requests can continue after the UI action snapshot; episode overlaps and neighboring move IDs provide context only.
- Maximum sampled RSS/private values are one-Hz snapshots and can miss shorter peaks. Process-lifetime peak fields predate this audit and are not audit peaks.
- CPU percent is relative to one logical core and can exceed 100% if multiple threads execute.
