# Single-node resource correlation source oracle — 2026-10-23

Supporting investigation for the 100-move historical route/resource-correlation browser audit. This evidence comes from read-only source inspection and deterministic generator evaluation, not browser validation. No product files were changed.

## Inputs and method

- Read `AGENTS.md`, `.agents/skills/router-plugin-validate/SKILL.md`, relevant sections of `docs/plugin-api-validation.md`, frontend correlation/timeline code, core relationship evaluation, tests, prior audit reports, and the generator.
- Read the outer and node-a manifests directly from `demo/fixtures/router-state-lab-algorithms-2026-10-02.tgz`, without extracting or modifying the archive.
- Outer manifest identifies node-a with 1,250,005 event records, 7,510 resources, revision `demo/node-a/revision-0001`, identity namespace `node-a/`, and clock offset -4,000,000 ns.
- Node-a manifest identifies scale generator version 8 and a 1,250,000-event generated component, plus authored records. Generated layout has 1,875 ETGs, 1,875 DTEs, 1,875 primary ETEs, 750 backup ETEs, 375 ESs, and 750 multihome services.
- Imported the generator with the configured Python environment and evaluated `_layout(7500)`, `_phase_event_counts(1250000)`, and selected `_event_for_phase(...)` records. Native times below include the PE-A -4 ms offset applied by assembly generation.
- Source: `demo/rsl_demo_generator/_scale.py:707`, `:1289`, `:1353`; `demo/rsl_demo_generator/assembly.py:600`, `:616`.

## Exact resource identities

| Role | Resource ID |
|---|---|
| DTE0 | `node-a/data-bridge-layer/DTE/blue/dte-000000` |
| ETG0 | `node-a/data-bridge-layer/ETG/blue/etg-000000` |
| ETG17 | `node-a/data-bridge-layer/ETG/blue/etg-000017` |
| Primary ETE | `node-a/data-bridge-layer/ETE/etg-000000/primary` |
| Backup ETE | `node-a/data-bridge-layer/ETE/etg-000000/backup` |
| ES0 | `node-a/control-plane/EVPN_ES/es-00000` |
| Fallback routing | `node-a/control-plane/IP_ROUTING/blue` |
| VIF0 | `node-a/data-bridge-layer/VIRTUAL_INTERFACE/ae-00000` |
| Neighbor0 | `node-a/control-plane/NEIGHBOR/blue/peer-00000` |

## Event and relationship oracle

Offsets are relative to node-a's generated base, `1759679999996000000` ns. The authored source base before clock adjustment is `1759680000000000000` ns. UI offsets can use a different selected capture origin; absolute native nanoseconds avoid that ambiguity.

| Event | Event UID | Native timestamp ns | Relative offset s | Applied result |
|---|---|---:|---:|---|
| Service creation | `node-a/scale-event-00000000` | `1759680119996000000` | 120 | DTE0 next_hop -> ETG0; ETG0 owns and selects primary ETE |
| Multihome addition | `node-a/scale-event-00312500` | `1759680239996000000` | 240 | DTE0 still -> ETG0; ETG0 additionally owns backup ETE and is member_of_es ES0; ES0 active_path -> primary and uses_interface -> VIF0 |
| ES withdrawal | `node-a/scale-event-00500000` | `1759680359996000000` | 360 | ES0 withdrawn, Neighbor0 down; no relationship mutations yet |
| Service failover | `node-a/scale-event-00500375` | `1759680360033500000` | 360.0375 | DTE0 -> IP_ROUTING/blue; selected_egress and active_path move primary -> backup |
| ES restoration | `node-a/scale-event-00750000` | `1759680479996000000` | 480 | ES0 and Neighbor0 up; no relationship mutations yet |
| Service restoration | `node-a/scale-event-00750375` | `1759680480033500000` | 480.0375 | DTE0 -> ETG0; selected_egress and active_path move backup -> primary |
| First DTE churn | `node-a/scale-event-01000000` | `1759680599996000000` | 600 | DTE0 -> ETG17 |
| Second DTE churn | `node-a/scale-event-01000750` | `1759680600071000000` | 600.075 | DTE0 -> IP_ROUTING/blue |
| Failed DTE churn | `node-a/scale-event-01007500` | `1759680600746000000` | 600.75 | Attempted ETG17; DTE0 remains -> IP_ROUTING/blue; effects and relationship_effects are empty |

The service failover and restore occur 37.5 ms after their ES state changes. An ES withdrawal by itself must not immediately retarget DTE0. `owns` relationships remain for both ETEs after multihome creation; `selected_egress` changes independently. At failover the primary is down, backup active, ETG degraded, and DTE programmed. At restore primary is active, backup standby, ETG active, and DTE programmed.

## Intended frontend behavior and limits

- Graph/index are point-in-time. Timeline relationship tree rows represent the whole visible window, so an inactive relation may retain its child row while its ribbon is inactive. `frontend/assets/app.js:2832`, `:2851`, `:2907`, `:7014`.
- Relationship validity is half-open `[from, to)`. Both endpoints must exist at the selected time; false-presence edges are omitted. `src/router_dump_analyzer/normalized_data.py:3344`.
- Failed reprogramming does not mutate state or relationships. The attempted next hop in event properties is not the applied destination. `demo/rsl_demo_generator/_scale.py:1289`.
- Graph request uses depth 3 for focused mode, 20 for full mode, and max_nodes 500. High-fanout IP_ROUTING may show 499 incoming endpoints with a truncation note. The graph canvas has a separate render bound; the index remains pageable across the full response. `frontend/assets/app.js:7033`, `:7098`, `:7448`, `:7891`.
- Direction labels represent stored source/target endpoints. Arrows depend on the plug-in descriptor; an unknown or undirected relation is not proof of causal direction. `frontend/assets/app.js:869`, `:7448`.
- Correlation-index resource buttons jump to timeline only for Ctrl/Meta-click. Ordinary hover/focus shows details. `frontend/assets/app.js:7516`.
- Layer visibility filters timeline lanes; the correlation graph has separate scope controls. Large-dataset All lanes mode intentionally displays representative lanes. `frontend/assets/app.js:8026`.
- Explicitly unknown existence/presence must remain unknown. Core supports ambiguous graph nodes, demonstrated by `tests/test_legacy_graph_perspectives.py:108`.

## Candidates requiring separate browser verification

These are not confirmed browser findings and must not be counted as such.

1. **Explicit unknown existence displayed as true in graph hover.** `graphNodeHoverHtml` uses `["Exists", node.exists ?? true]` at `frontend/assets/app.js:7413`. For a supported `exists: null` graph node, this formats true. Core tests intentionally retain null existence and unknown status. Generated PE-A resources may not supply an ambiguous node, so current fixture coverage may be unavailable.
2. **Graph failure silently substitutes an empty local fallback in scale mode.** `requestGraph` catches non-abort errors and uses `localGraphAt` at `frontend/assets/app.js:7135`, without a visible fallback/error distinction. Scale bootstrap collections for relationships/intervals are empty, so a naturally failed read can resemble no active correlation. A request failure must be observed before treating this as a browser finding.
3. **Combined relationship intervals use only three modulo rows.** `combinedAssociationLane` uses `index % 3` at `frontend/assets/app.js:2982`; simultaneously active intervals can overlap. This is already documented as an improvement opportunity in `docs/single-node-audit-2026-07-22.md:338`, so a new reproduction must be distinguished from a newly discovered defect.

## Documentation drift

No implementation or public plug-in behavior changed during this supporting investigation. No maintained authoring-document update is required.

## Exact cursor selection through the existing UI

There is no editable exact-cursor textbox: Selected time is a range slider. The existing range editor and Actions menu provide an exact user-accessible path:

1. In Timeline, fill **Start offset (s)** with target offset T and **End offset (s)** with T + 0.000000001. Offsets are relative to the timeline's capture start, with up to nine decimals.
2. Click **Apply range**. This selects the duration but does not move the cursor.
3. Click the Timeline toolbar **Actions**, then **Select this moment**. The toolbar uses the selected range's exact integer midpoint; the midpoint of [T, T + 1 ns] is T.
4. Optionally click **Clear range**. That clears the duration selection while preserving the selected cursor time. **Clear timeline selection** and **Reset** have broader effects and should not be substituted.

Example: start `360.037500000`, end `360.037500001` selects exactly +360.0375 s. Check the capture origin before translating the native timestamps above into an offset.

An event-time alternative is **Normalized event log** → **Search** the exact event UID → select the matching row → **Reveal in timeline**, or double-click the row. That selects the event's exact timestamp and resource.

Sources: `frontend/pages/node.html:217`, `:236`, `:265`, `:622`; `frontend/assets/app.js:5247`, `:5264`, `:5410`, `:11673`, `:12077`, `:12484`. This navigation path is source-derived and must still be grounded in live DOM and validated in the browser.

## Source diagnosis for browser-reported pinned correlation card obstruction

The parent audit reproduced this sequence in the browser: pin a DTE resource-state card in the single-node correlation graph; scroll to the timeline; the card remains at the same viewport position over **Actions**. A hit test at the Actions center returned the card's `<dd>+720.000s</dd>`. Clicking Actions did not open its menu; Escape dismissed the card and a subsequent click succeeded. Parent evidence: `correlation-pin-over-actions.png` and `correlation-pin-over-actions.txt` in this directory. This supporting agent reviewed source and the saved DOM text; it did not independently operate the browser.

Root cause is the correlation card's missing anchor lifecycle:

- `correlationHoverCard()` appends `#correlation-hover` directly to the document body (`frontend/assets/app.js:7320`). Its `timeline-hover` class uses `position: fixed` and `z-index: 200` (`frontend/assets/styles.css:3487`). The card remains hit-testable and permits internal scrolling.
- `showCorrelationHover()` reads the supplied trigger rectangle and positions the card once (`app.js:7333`). It does not retain a live anchor for later viewport checks.
- `pinGraphInspection()` records semantic resource/edge identity and opens the card pinned (`app.js:7702`). `scheduleCorrelationHoverClose()` explicitly returns for pinned cards (`app.js:7374`), so leaving the node while scrolling cannot close it.
- The captured document scroll handler only calls `positionHover()` (`app.js:12502`), which exclusively manages `#timeline-hover` (`app.js:5132`). No scroll path checks the correlation card's trigger visibility or updates its fixed position.
- `openTimelineContextMenu()` already calls `closeCorrelationHover()` (`app.js:12034`), but that logic executes only after the click reaches Actions. The overlaid card prevents the click from reaching the button; therefore adding another close inside that handler would not address the cause.
- Escape invokes `clearPinnedGraphInspection()` (`app.js:5497`), explaining the observed recovery. Empty graph clicks also clear the pin, but unrelated page controls do not.

This is a distinct popup implementation from the earlier Fabric/route fixes. `frontend/assets/topology.js:10273` manages `#mn-topology-hover-card` and `#mn-route-hover-card` with retained anchors, and its route service positioner validates anchor connectivity and viewport/sticky-header clipping at `:8534`. Neither manages the single-node `#correlation-hover`. The earlier single-node timeline popup repair likewise applies to `#timeline-hover`, not this card.

Potential repair boundary, for a future authorized fix: use the existing correlation show/close and document-scroll paths to retain/check the actual graph anchor, reposition while visible, and dismiss when disconnected or clipped; keep internal card scrolling and semantic graph pin state deliberate. Avoid changing Actions or adding per-control workarounds. This investigation made no product changes.
