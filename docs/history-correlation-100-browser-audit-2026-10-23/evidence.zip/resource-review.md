# Review of resource-correlation browser snapshots 051–073

Reviewed on 2026-10-23. This supporting agent read the saved browser snapshots and source oracle; it did not operate the browser. The parent agent performed the UI actions. No product changes were made.

Inputs: `051.txt` through `073.txt`, corresponding entries in `moves.json`, `resource-oracle.md`, and current frontend/core/generator source. The exact-time helper applies a range [T, T + 1 ns] and uses **Actions → Select this moment**; integer midpoint is exactly T. Displayed three-decimal labels cannot distinguish the before/at boundary pair, so the recorded range fields and exact endpoint IDs are essential evidence.

## Results

| Moves | Observed evidence | Assessment |
|---|---|---|
| 051 | Initial single-node page says Selected moment loading; resource history is not yet available | Startup observation, not a settled correctness test |
| 052–053 | Resource explorer/search shows DTE0 at capture +720 s, programmed, next hop ETG17 | Matches final generated state |
| 054–056 | Focused DTE graph has exactly the DTE0 → ETG17 next_hop edge; edge and resource inspectors opened | Matches table and source oracle; parent separately reproduced the pinned-card obstruction |
| 057 | Range fields are [119.999999999, 120], but table says showing +720 s / updating to +119.999 s; graph still shows +720 s | Pending snapshot: does not establish absence before creation. Needs a settled repeat. Not evidence of a state-reconstruction defect |
| 058–059 | Exact creation boundary [120, 120.000000001]; graph and flat resource table both show DTE0 → ETG0 | Pass for at-creation target |
| 060 | [239.999999999, 240]; DTE0 remains programmed → ETG0 | Expected immediately before multihome |
| 061 | [240, 240.000000001]; DTE0 remains → ETG0 | Expected at multihome; that event changes ETG/ES/ETE relationships, not DTE's next hop |
| 062 | ETG0 selected at +240 s; graph includes owns → primary, owns → backup, selected_egress → primary | Correct distinction between ownership and selected forwarding path |
| 063 | [360.037499999, 360.0375]; graph/table both DTE0 → ETG0 | Correct 1 ns before failover |
| 064–065 | [360.0375, 360.037500001]; graph/table both DTE0 → IP_ROUTING/blue | Correct at failover; old target not retained |
| 066 | [480.037499999, 480.0375]; graph/table both DTE0 → IP_ROUTING/blue | Correct 1 ns before service restoration |
| 067–068 | [480.0375, 480.037500001]; graph/table both DTE0 → ETG0 | Correct at restoration |
| 069 | [599.999999999, 600]; graph/table both DTE0 → ETG0 | Correct 1 ns before first churn |
| 070–071 | [600, 600.000000001]; graph/table both DTE0 → ETG17 | Correct at first churn; move 070 has no trustworthy per-action latency because the multi-action tool limit interrupted observation |
| 072–073 | [600.075, 600.075000001]; graph/table both DTE0 → IP_ROUTING/blue | Correct at second churn |

Graph node/table status remains **programmed** for DTE0 across applied next-hop transitions, as the source oracle requires. The focused graph has two visible resources and one visible relationship in the DTE checks. Some IP_ROUTING cases disclose the underlying server 500-node cap even though the locally focused display has only two nodes; this is not evidence of a missing selected DTE edge.

Temporal topology rows elsewhere in these snapshots sometimes report ambiguous existence at transition boundaries while the flat resource table has exact native-time state. Those sections use different reconstruction/clock semantics. These observations must not be labelled inconsistent resource correlation without comparing applied time basis, clock uncertainty and perspective. This review does not establish a defect in that difference.

## Confirmed defect in this area

The parent browser reproduction establishes a pinned correlation popup that survives its graph anchor scrolling off-screen and obstructs Timeline Actions. Its source diagnosis and exact evidence are recorded in `resource-oracle.md` under **Source diagnosis for browser-reported pinned correlation card obstruction**. It is a distinct implementation from previous Fabric, VPN-service, and timeline-marker popup repairs. The historical graph/table target checks above do not reveal an additional settled target mismatch.

## Performance observation and attribution limit

- Move 069 records **14,538 ms** for the complete exact-cursor UI workflow and settled resource table.
- Move 072 records **9,581 ms** for the workflow including observation.
- These are user-path observations, not server-only CPU time or a performance profile. They include input/actions, range work, dependent refreshes, browser observation, and waiting for table settlement.
- Move 070 explicitly has no per-action timing claim; the multi-action tool limit is not itself a product stall measurement.

Source-backed investigation lead:

1. The snapshots retain **Search resources = dte-000000** during the cursor sequence.
2. `requestResources()` sends the search text and exact cursor to `resources/query` (`frontend/assets/app.js:5707`, `:5736`). Cursor refresh also schedules graph, resource and dashboard reads together (`app.js:4233`).
3. On an uncached timestamp with a nonempty search, `resources_at()` builds search documents for **every resource** by calling `resource_state_at` and safe text projection (`src/router_dump_analyzer/normalized_data.py:3898–3916`). Kind filtering occurs afterward, so displaying one filtered DTE does not imply one-resource reconstruction work.
4. The search-document cache retains only two exact timestamp snapshots (`demo/rsl_demo_plugin/scale_data.py:331`). New 1 ns cursor positions do not reuse neighboring snapshots.
5. `resource_state_at()` reads lifecycle/state histories (`normalized_data.py:3201`); `_active_intervals()` scans candidate interval lists (`:537`). The generated lazy interval cache can also perform first-touch reconstruction (`demo/rsl_demo_plugin/scale_data.py:401`, `:501`).

This establishes a potentially costly path, **not its contribution to the recorded wall times**. No profiler was run and no controlled search-cleared comparison was observed in 051–073. Do not claim late-cursor scaling, CPU attribution, memory growth, or a regression from these timings alone. A useful next check would compare the same settled cursor sequence with search empty versus retained, while recording request timing and backend profile independently.

## Remaining coverage within this reviewed subset

- Repeat the pre-creation check after settlement (057 is pending).
- The failed churn at +600.75 s is not covered by snapshots through 073; its required result is unchanged DTE0 → IP_ROUTING despite the attempted ETG17 target.
- Unknown-existence graph hover, failed-request fallback, and combined interval packing remain source candidates from the oracle, not new browser-confirmed bugs from this subset.
- This review covers only 051–073, not the complete 100-move audit.

Documentation drift check: this supporting audit changes only runtime evidence documents. Public plug-in behavior and authoring contracts are unchanged.

## Supplemental review: snapshots 074–090

Read the new snapshots and their move notes. This remains review of parent-produced browser evidence, not independent browser execution.

| Moves | Observed evidence | Assessment / limitation |
|---|---|---|
| 074 | Inspector identifies DTE0 failure at exact `1759680600746000000` ns (+600.750 s), attempt 10, `SyntheticProgrammingError`, current IP_ROUTING and attempted ETG17; resource/graph still explicitly updating from +600.075 s | Exact event identity and failed intent established; do not treat this pending snapshot alone as settled state |
| 075 | Same failure inspector; resource table and graph settled at +600.750 s with DTE0 programmed → IP_ROUTING/blue | Correct retained state despite attempted ETG17 |
| 076 | Exact range [600.749999999, 600.75]; graph/table DTE0 → IP_ROUTING | Correct 1 ns before the failed attempt |
| 077–078 | Exact range [600.75, 600.750000001]; table settled by 077, graph still updating in 077 and settled in 078; both retain DTE0 → IP_ROUTING | Failed operation does not create an applied relationship mutation; use 078 for settled combined assertion |
| 079 | Primary ETE resource table shows active at +600.750 s; graph updating during selection | Correct post-restoration table state; not a settled graph comparison |
| 080 | Cursor moved to service failover +360.0375 s; primary ETE table/graph down; `owns` from ETG0 persists, with ETE next_hop and egresses_via relations | Correct. The move label's “failure” refers to service failover, not the later failed DTE programming attempt |
| 081–082 | Backup ETE at service failover: active, owned and selected by degraded ETG0, active_path from withdrawn ES0, plus its next_hop and interface relation | Correct separation of relationship presence from endpoint health. 081 is updating; 082 is settled |
| 083 | Synthetic CTF projections enabled while exact failed-event search remains; backup graph stays at service-failover context | Source-stream inclusion is not a change to resource identity or selected historical state |
| 084–085 | Failed event revealed through event-log path; inspector returns to exact +600.750 s and DTE0; transitional graph/table reads are labelled pending | Navigation intent is visible; use later settled snapshots to judge state |
| 086 | [600.74, 600.76] zoom exposes individual markers; graph settled at +600.750 s with DTE0 → IP_ROUTING; inspector retains failed attempt | Correct selected identity and time after zoom |
| 087 | Parent observed Ctrl-click first focus the correct event row and navigation-target; saved snapshot has cleared event-log search and no exact UID row retained in the later virtual window | Inconclusive for persistent reveal/focus, not a confirmed bug. Clearing search is intentional. The initial row's aria-selected=false refers to bulk log selection and does not alone prove navigation failure |
| 088 | Exact UID search restored; toolbar reveal returns to same failure inspector and DTE0 graph; dependent reads still updating in snapshot | Recovery action succeeded in identifying the intended event. Persistent log-navigation focus is still unproven |
| 089–090 | Topology perspective switches Control-plane reachability → Data bridge programmed state; graph remains settled at +600.750 s and DTE0 → IP_ROUTING | Correlation focus survives independent topology controls. Cross-layer unknown topology status is explicitly labelled; no mismatch established |

### Interpretation details

- The failed event correctly has an attempted `next_hop_after=ETG17` in its event properties while the applied resource state and correlation remain IP_ROUTING. These are distinct facts, not contradictory results.
- The restored primary is active at +600.750 s (079), then down after moving back to the failover moment (080). The snapshots do not describe one unchanged cursor context.
- After selecting/revealing DTE0 from the log, **Search resources** remains `etg-000000/backup` while the selected resource kind becomes DTE. The flat table consequently reports zero matches. The retained filter is visible; that alone is not a correlation or identity defect. Graph focus and table filtering are separate UI state.
- Event-log navigation and bulk row selection are separate concepts. The Ctrl-click path `jumpToNormalizedLog` clears layer/search filters and invokes event selection before row reveal (`frontend/assets/app.js:4417`). A row's aria-selected=false does not establish that the wrong event was revealed.
- The later virtualized log window omitting the event in move 087 requires a controlled settled repeat with both-axis visibility, scroll position, current row UID, active element, and intervening scroll/focus activity recorded. Initial correct focus followed by a different virtual window is insufficient for a confirmed functional defect.

### Additional timing evidence

Move 076 records an **11,641 ms** exact-cursor workflow; move 077 records **1,935 ms**. The latter snapshot still shows the graph updating, so it must not be presented as complete all-component settlement. These times retain the earlier attribution limits: UI workflow and observation durations, no CPU profile or isolated request measurement. They do not prove that the previously identified resource-search projection path caused the delay.

The failed-churn coverage gap from the earlier 051–073 review is now closed by 075 and 078. The pre-creation gap and final moves 091–100 are outside this supplemental subset. No additional settled resource-target mismatch was found in 074–090.

## Final supplemental review: 091–100 and settled controls

Reviewed `091.txt` through `100.txt`, `creation-boundary-repeat.json`, `cursor-performance-control.json`, and the later `100-settled.txt` / `100-settled-graph.txt`. The final graph screenshot was refreshed by the parent after settlement.

| Moves | Observed evidence | Assessment |
|---|---|---|
| 091–093 | Full-span relationship lane expansion and resource search changes retain the +600.750 s DTE0 → IP_ROUTING graph; resource search then cleared | Correct separation of historical lane visibility/search and selected-time graph |
| 094 | Fresh +600.800 s cursor with empty resource search; graph/table both DTE0 programmed → IP_ROUTING | Correct retained state between failed attempt and next successful update; workflow recorded 3,420 ms |
| 095–096 | Range changed to [350,490] spanning failover/restoration, while cursor stays +600.800 s; graph and pinned edge still identify DTE0 → IP_ROUTING | Correct: selected duration does not union historical edges into a point-in-time graph |
| 097–098 | Repeated +119.999999999 → +120 → +119.999999999; saved settled graph text shows absent → DTE0/ETG0 edge → absent; final resource table says Exists no / absent | Pass. Closes the initially pending pre-creation test 057 and checks backward reconstruction |
| 099 | Reload clears ephemeral selection/range and restores the URL member context at +720 s | Consistent reset, not stale control/content mismatch |
| 100 | Initial snapshot has settled resource table but graph pending with old ETG17. Later `100-settled-graph.txt` and `100-settled.txt` show +360.037 s, DTE0 programmed → IP_ROUTING, one relationship in index | Pass using settled supplement. The initial pending graph is not a defect |

The `creation-boundary-repeat.json` includes the three settled graph bodies and exact selected offsets. In the final pre-creation snapshots, both the graph and relationship index explicitly state no active correlation / selected resource outside its lifecycle; the table independently reports DTE0 absent. The at-creation middle state names the canonical DTE0 identity and ETG0 endpoint.

The final settled post-reload graph is explicitly **Selected moment**, not **Updating**, and the flat table reconstructs the same applied target. A transient loading banner in an earlier screenshot was removed in the refreshed final evidence; it is not counted as a defect.

### Updated performance interpretation

`cursor-performance-control.json` records +600.800 s, resource search empty, complete scripted workflow **3,420 ms**. This is shorter than the retained-search observations (14,538 ms and 9,581 ms) and is consistent with the source lead that nonempty search builds per-resource state text at each uncached timestamp. It is not a controlled same-timestamp paired benchmark: cursor timestamps, cache state, surrounding requests and observation timing differ. Do not attribute the entire difference to search or claim an isolated backend/CPU improvement.

### Final resource-review conclusion

- One confirmed functional defect in this audit area: the pinned single-node correlation card survives its off-screen anchor and can intercept Timeline Actions.
- No new settled resource-correlation target mismatch was found across the reviewed native-time creation, multihome, failover, restoration, successful churn, failed churn, range-change, reverse-time or reload sequences.
- A slow exact-cursor workflow with retained resource search was observed; source identifies a credible full-resource projection path, but CPU attribution remains unprofiled.
- Move 087's persistent log reveal/focus remains inconclusive and is not counted as a confirmed defect.
- Source-only candidates concerning unknown existence, failed-request fallback and combined interval packing remain unconfirmed in this browser run.

This review now covers the resource portion of the audit, snapshots 051–100 plus named settled supplements. It does not claim every possible resource identity, clock policy, relationship type or temporal boundary was exhausted.
