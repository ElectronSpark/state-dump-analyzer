# Historical route/source oracle — 2026-10-23

Read-only investigation by the history-route-oracle supporting agent. No product
files changed, no browser use, and no browser validation claimed. Read
`AGENTS.md`, `.agents/skills/router-plugin-validate/SKILL.md`, and relevant sections
of `docs/plugin-api-validation.md`.

## Fixture identity and time semantics

Inspected `demo/fixtures/router-state-lab-algorithms-2026-10-02.tgz` directly with
Python tarfile, without extracting or rewriting it. Its manifest's source
scenario SHA-256 is
`972715737901e2f68dfc7858a62ee3419479c8ca02a688e2f294bb53b6dc57fd`, exactly matching
`demo/router-state-lab-default.scenario.json` on disk.

The authored base is `1759680000000000000`, 2025-10-05 16:00:00 UTC. Capture is
base +720 seconds. The PE-A topology projection has observed_at_ns
`1759680719996000000`, including its -4ms node clock offset.

- `demo/rsl_demo_generator/scenario_source.py:201`: resources_at replays authored
  observations inclusively at the selected time; `update_snapshot=false` does
  not mutate resource state.
- `demo/rsl_demo_generator/assembly.py:2603`: authored topology changes transport
  exact event UID, operation, outcome, state_changed, and timestamp.
- `src/router_dump_analyzer/multi_node_topology.py:408`: `_status_view_at` skips
  explicit no-op state changes, applies transitions inclusively, and uses
  half-open resource validity.
- `src/router_dump_analyzer/multi_node_topology.py:509`: `_status_window_at`
  samples both sides of transitions crossed by clock uncertainty. Ambiguity at
  the exact boundary is expected, rather than a stale-data defect.
- `docs/api-contract.md:2891`: relative offsets resolve independently against
  selected projection watermarks. Relative capture vectors must not be labeled
  as one simultaneous UTC instant.
- Manifest clock uncertainty ranges from 3ms to 15ms. Use at least 20ms either
  side of a transition for clear before/after assertions. Strict policy does not
  remove declared clock uncertainty.

## Known authored transitions

All IDs below are node-local source IDs. Materialized canonical IDs prepend
`node-id/layer/RESOURCE_TYPE/`; `_source_resource_id` is at
`demo/rsl_demo_generator/assembly.py:873`.

| Offset | UTC ns | Expected local state |
|---:|---:|---|
|30s|1759680030000000000|PE-A creates `route:blue:198.51.100.0/30`.|
|90.05s|1759680090050000000|P1 `interface:Ethernet3/1` becomes down.|
|91s|1759680091000000000|P1 removes `neighbor:10.64.255.1`.|
|96s|1759680096000000000|P2 stale carrier-down observation leaves `interface:Ethernet4/1` up.|
|108s|1759680108000000000|P2 failed withdrawal leaves `route:blue:203.0.113.0/24` installed.|
|120s|1759680120000000000|PE-A service route next hop changes `10.64.0.2` to `.3`.|
|180s|1759680180000000000|PE-D deletes `interface:Ethernet1/1.310`.|
|181s|1759680181000000000|PE-D deletes `neighbor:10.64.0.2`.|
|210s|1759680210000000000|PE-A deletes temporary `198.51.100.0/30` route.|
|240.1s|1759680240100000000|P1 carrier returns up.|
|270s|1759680270000000000|PE-A recreates the temporary route.|
|300s|1759680300000000000|PE-D recreates its detached interface.|
|304s|1759680304000000000|PE-D recreates its adjacency.|
|360s|1759680360000000000|PE-B failed next-hop update retains `10.64.1.2`.|
|400s|1759680400000000000|PE-E `vpn:blue-evpn` down; physical underlay unchanged.|
|420.2s|1759680420200000000|PE-C Ottawa core-facing interface down.|
|435s|1759680435000000000|P2 sees Ottawa circuit down after delayed poll.|
|439s|1759680439000000000|PE-C removes `route:blue:10.255.0.1/32`.|
|521s|1759680521000000000|P2 Ottawa interface restores first.|
|528s|1759680528000000000|PE-C Ottawa interface restores.|
|535s|1759680535000000000|PE-C loopback route restores.|
|560s|1759680560000000000|PE-E blue EVPN attachment restores.|
|610s|1759680610000000000|PE-A service route returns to `10.64.0.2`.|

Source events are in `demo/router-state-lab-default.scenario.json`.
`demo/tests/test_scenario_source.py:135` independently asserts create/delete/
recreate and carrier transitions; `:170` asserts failed/stale preservation.

## Historical route-row validity: definite implementation omission

There is a definite omission in the current route-table code: it does not
evaluate the validity interval it exposes for each row against the selected
historical time. This is stronger than merely observing an unchanged next hop.
Whether the UI should omit out-of-interval observations or retain them with
explicit unavailable/unknown historical status needs a design decision; the
sources do not justify inventing an earlier route state.

Evidence, with exact current source lines:

1. `src/router_dump_analyzer/multi_node_route.py:4339` explicitly sets each
   normalized row's `valid_from_ns` to its generated `observed_at_ns`; line 4340
   copies `valid_to_ns`.
2. The capability at `:4762` declares `state_location: time_bound_query_only`.
   `tests/test_multi_node_route.py:1587` is explicitly named
   `test_route_table_capabilities_are_descriptors_not_timeless_rows` and asserts
   that declaration. It does not test a historical interval crossing.
3. `route_tables` at `:4981` says it federates rows at one topology time context.
4. Its row loop starts at `:5153`. At `:5193–5207`, it obtains the selected
   per-node query time, rejects only timestamps before `self.topology.start_ns`,
   then appends the unchanged row with the new `basis_time_ns` and clock-derived
   quality. Neither valid_from_ns nor valid_to_ns is consulted.
5. Response ownership at `:5344` explicitly assigns
   `time_context_filtering_and_pagination` to core.
6. `docs/api-contract.md:3943` says the response contains rows under the frozen
   assembly context. This section does not separately spell out a row-specific
   half-open interval formula; the unambiguous implementation evidence is the
   exposed validity fields, capability declaration, and stated core ownership.
7. `demo/rsl_demo_plugin/route_policy.py:274–298` builds RouteProjectionSet once
   from immutable per-node projections; there is no per-request historical
   route-row producer in this path.

Exact fixture counterexample for browser verification:

- Node `node-a`, blue VRF, family `vpnv4_unicast`, type `mpls_l3vpn`, destination
  `node-b`.
- Path `route-path:inventory:generic-mpls_l3vpn-blue-vpnv4_unicast:node-a:node-b`.
- The archive's `plugin-projection/routes.jsonl` row has observed_at_ns (thus
  normalized valid_from_ns) **`1759680600996000000`**, base +600.996s.
- Query absolute **`1759680100000000000`**, base +100s, well before that bound.
- Inspect whether the row remains installed/active and traceable as historical
  evidence, and whether its popup/request facts disclose the mismatch. Source
  inspection proves the interval is not checked; actual UI behavior still
  requires parent browser validation.

Do not conflate this row with authored `route:blue:203.0.113.0/24` history:
generated inventory routes and authored resource routes are separate records.
An unchanged candidate alone cannot prove a reconstruction defect.

## Suggested composed checks

- `srv6-all-active`: inspect P1/P2 transport at +89s, +100s, +241s.
- `site-a-site-c-asymmetric` and `site-b-site-c-one-way`: inspect Ottawa link
  before +419s, one-sided down +425s, both down +440s, one-sided restored +525s,
  restored +530s. Compare forward/return and resolution-step evidence.
- `evpn-mh-all-active`: +399s, +401s, +559s, +561s; switch VPN/underlay views to
  distinguish service attachment from physical transit membership.
- PE-D destination/source routes: +179s, +181s, +299s, +301s; distinguish
  absence from down and ensure a historical selection survives route switching.
- Repeated current→past→current with an open popup, selected route table row,
  focused path, and graph node. Compare applied time and context IDs after each
  settled result, not merely draft controls.
- Cross-component jumps should preserve exact member/revision/resource IDs and
  selected historical time, or clearly disclose that the destination has a
  different basis. Failed/stale event wording must never override retained
  successful state.

No product or public plug-in behavior was modified. Documentation drift check:
no maintained authoring-material change required for this read-only report.
