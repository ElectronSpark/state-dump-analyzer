# Review of historical route browser observations

Reviewed parent-produced actual UI snapshots `001.txt` through `043.txt`,
`047.txt`, `048.txt`, `p1-p2-repeat.json`, `future-row.txt`, and their `moves.json`
entries against `route-oracle.md`.
This supporting agent did not operate the browser. No product files changed.

## Confirmed: later route evidence is presented at an earlier selected time

The browser confirms the source omission described in route-oracle.md:

- `future-row.txt:474` says snapshot basis is absolute 1759680100.000 seconds,
  i.e. base +100s. The applied reconstruction identity is the same historical
  context, not merely an unsubmitted form value.
- `future-row.txt:592–631` contains PE-A's blue `mpls_l3vpn` row for destination
  `10.255.2.0/32` / node-b, active and installed, with usable **Use in trace**.
  Node summary at lines 563–570 binds it to the same historical time and ±5ms.
- `013.txt:456–505` shows that row seeded a completed trace reporting **Route is
  reachable**, **Both traffic endpoints are reachable**, and resolved segments
  A→P1→B. The applied time remains base +100s. Both trace and reconstruct buttons
  are enabled, so this is not a pending-result interpretation.
- Direct immutable fixture inspection found that exact route row observed at
  `1759680600996000000` (base +600.996s). Normalization explicitly publishes that
  value as its valid_from_ns (`multi_node_route.py:4339`). Parent separately
  reports inspecting this same value in the row's plug-in details. The saved
  accessibility snapshot itself contains the details trigger, but not the
  expanded JSON; the fixture supplies independent timestamp evidence.
- The selected instant precedes valid_from by **500.996 seconds**, far exceeding
  clock uncertainty. Generic incomplete-coverage wording does not explain why
  this specifically out-of-interval observation is displayed active/installed
  and used to establish historical reachability.

Treat table and trace as two manifestations of the same missing historical
validity enforcement unless subsequent evidence establishes separate causes.
Do not count repeated +119.999s and +120.001s observations as additional bugs.

## Confirmed: typed point-to-point link remains usable during historical carrier loss

`future-row.txt:785` onward lists P1→P2's typed-federation point-to-point link as
**usable** at +100s. The source fixture was inspected again directly:

- Resource
  `transit-p-1/data-bridge-layer/VIRTUAL_INTERFACE/interface:Ethernet3/1`
  has a successful state_changed=true down event at
  `1759680090050000000`, and restoration only at `1759680240100000000`.
- Its `transit-p-1/topology/p1-p2-sr` claim references that same interface,
  segment `subnet:p1-p2-sr`, prefix `10.64.255.0/31`, and says calculation basis
  includes interface status. The initial claim status is usable.
- `demo/rsl_demo_plugin/typed_topology.py:302–306` discards resolved_time and
  returns prebuilt states; `_claim_state` at :309–358 copies initial claim status
  into a permanently existing ResourceStateView. The projection at :179–268
  derives usable status from that frozen claim instead of the historical local
  resource changes.

The explicit P1→P2 follow-up confirms route impact:

- `047.txt` applies absolute +100s and declares **Route is reachable**, **Both
  traffic endpoints are reachable** for the direct ISIS underlay P1/P2 route.
- `048.txt` retains that result and exposes the return segment as **usable;
  Resolved**, over the same typed `demo.underlay.point_to_point` boundary.
- `p1-p2-repeat.json` repeats +100s→+241s→+100s; all three completed results
  claim both endpoints reachable. Recorded action/settled-observation intervals
  are 4232ms, 3460ms, and 3385ms, including observation overhead.
- Graph labels explicitly bind the circuit to P1 physical interface Ethernet3/1,
  P2 Ethernet4/1, and 10.64.255.0/31. This removes the earlier SRv6-path ambiguity.
- The +100s samples lie about ten seconds after carrier-down and 140 seconds
  before restore, far outside the 3–4ms clock bounds.

The root cause is the typed demo adapter: its builder at
`typed_topology.py:460–489` snapshots only raw claims, ignoring topology resource
changes; its state provider discards the selected time; projection then derives
usability from the frozen initial claim. The legacy connectivity-domain path
does reconstruct resource state, which explains why PE-D deletion correctly
affected its multi-access route while this typed point-to-point circuit did not.

The fixture archive proves local carrier history. Parent is also navigating to
the local P1 view for an additional cross-component visual comparison. That
extra screenshot is not required to establish the existing direct-route/source
contradiction and must not be represented as already reviewed here.

## Controls that behaved correctly or remain inconclusive

| Moves | Assessment |
|---|---|
|001|Trace button disabled; lacks a settled route outcome. Not a failure.|
|002–003|Latest-watermark Return/all-paths outcomes retain reachable route; relative capture vector explicitly says simultaneity not implied.|
|004,006,008,011|Reconstruction pending; retained result still identifies its old applied context and draft controls are disabled. No stale-result defect established.|
|005,007,009|Applied reconstruction settled but Trace route remains disabled; route result omission is transient/inconclusive.|
|010|Settled primary route remains reachable near carrier failure. It uses A→P1→B, not the failed P1→P2 link. Not a failure.|
|012–015|Confirms future route evidence issue above; service context stays separate from transit membership.|
|016,018|Pending reconstruction.|
|017,019|Same inventory VPN path stays reachable near +120s. This is not the authored `route:blue:203.0.113.0/24` resource that changes next hop, so no separate reroute defect is established. Both timestamps also lie within clock uncertainty of the authored change.|
|020,022|Pending reconstruction.|
|021→023|Correct before/after control: PE-D destination reachable at +179s; +181s trace becomes incomplete with both directions unresolved after interface deletion.|
|024,026|Pending reconstruction.|
|025→027|SRv6 all-active unchanged across carrier restoration is valid for the shown paths A→P1→E and A→P2→E; neither traverses P1→P2.|
|028–029|Intermediate reconstruction snapshots; no independent settled +299s trace result captured.|
|030|PE-D reachable at +301s after interface recreation, consistent with oracle. Route type changed to IPv4, so not a strict same-query round trip from021/023.|
|031–034|EVPN scenario remains endpoint-reachable around PE-E local VPN attachment failure. Scenario forward termination is PE-B and return starts PE-E. Exact scenario endpoint/attachment references must be compared with `vpn:blue-evpn` before claiming a separate defect.|
|035|Pending +559s reconstruction; cannot establish the before-restoration state from this snapshot.|
|036,038|Settled +561s EVPN result reachable after restoration, consistent with known state.|
|037|Strict-policy reconstruction pending; no settled strict-versus-best-effort comparison in this snapshot.|
|039|Prestart reconstruction pending.|
|040|Before capture start (-10s), settled trace is incomplete and route table has no matching rows. Correct fail-closed control.|
|041|Applied +800s topology visible, but secondary table still has prior empty rows; do not report the transient empty table as failure.|
|042|Settled +800s EVPN trace reachable, with explicit outside-advertised-history warning and partial coverage. See qualification below.|
|043|Invalid absolute timestamp produces integer-nanosecond validation error; old applied +800s result retained and timeline says draft differs. No changed applied identity claimed.|

## After-watermark reachability: policy/wording candidate, not confirmed defect

At +800s, the selected instant exceeds the authored +720s capture. Snapshot042
shows reachable endpoints, but also explicitly says the selected request is
outside advertised history and reports partial/incomplete coverage.

The current documented normalized-resource contract permits open validity ends:
`docs/api-contract.md:2739–2741` and `docs/plugin-contract.md:1602–1607` enforce
the supplied half-open interval with either end optional. `_status_view_at`
retains the last successful state when no later event or valid_to_ns exists.
There is no found normative rule imposing capture/watermark as an implicit
expiry of each open-ended fact. `_resolve_time` accepts absolute timestamps;
relative positive offsets are separately rejected.

Therefore this evidence does not establish a new correctness defect. A useful
product question is whether **Both endpoints reachable** should explicitly say
that it is extrapolated from retained observations beyond known coverage,
instead of relying on a nearby history warning. This must not be merged with
the confirmed future-evidence issue: +100s is earlier than a supplied valid_from,
whereas +800s is later than the latest observation with no supplied valid_to.

## Performance limits

Move019 recorded 5010ms from trace action through settled browser observation.
This establishes a several-second user-path observation, including tool/UI
observation overhead; it does not measure server CPU or isolate a scan. The
long timestamp gaps elsewhere include audit inspection time and must not be
reported as operation latency. No new CPU regression is proven by these files.

## Correction to initial source oracle suggestions

The initial oracle recommended SRv6 all-active as a P1/P2 transition probe
because both nodes are involved. Actual path evidence shows parallel A→P1→E
and A→P2→E branches, so this does **not** exercise the mutual P1→P2 circuit.
Use a route whose actual segment explicitly crosses P1→P2 for that assertion.
No product changes; documentation stewardship drift check requires no update.
