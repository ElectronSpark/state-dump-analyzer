# Final route review: moves 88–100

Read-only review of the recorded snapshots, move ledger, route oracle, and current source at `4f49279e9192709aa81b5fa305b69051708d4e51`. No new browser/server requests, tests, benchmarks, or product changes were made.

## Historical and cross-component outcomes

The recorded outcomes are consistent with the source oracle. No additional route-validity or direction defect is established by these final moves.

| Moves | Recorded evidence and conclusion |
| --- | --- |
| 88 | The pending snapshot has the frozen UTC input `1759680096010000000`; the settled snapshot restores `tctx1-0c7fb0c48426d7b9d43e7fe4`, with the D/E red VPN parameters in its generated links. The node-local 480-second cursor did not overwrite the fabric context. |
| 89–90 | At `1759680601025000000`, CE-West→Edge-C uses default IPv4 and resolves both directions. The forward snapshot explicitly contains CE-West→A→P2→C→Edge-C, one active path, complete forwarding evidence, and both traffic endpoints reachable. This is the +601.025-second gate set by Edge-C's 25 ms uncertainty. |
| 91–93 | Return focuses Edge-C→C→P2→A→CE-West. All paths preserves the return direction and one candidate; switching forward and focused restores the original forward path. |
| 94–95 | Exact UTC `1759680601024999999` replaces the context with `tctx1-5dccdbdee863dddd69dba8b1`. Move 94 clears the old trace. Move 95 marks both directions unresolved and the selected forward path incomplete, with the final Edge-C resolution stating that route or forwarding evidence is unavailable at the selected time. The physically usable links do not falsely establish endpoint delivery. |
| 96–97 | Move 96's selection-call timeout is inconclusive as an automation timing result. Move 97 independently confirms Return only applied: the route is reachable in return, Forward is disabled and explicitly “not run,” and the outcome states that the opposite direction was not requested. No stale forward success is retained. |
| 98 | Edge-C's historical route table contains 9 rows at +601.025, all with an incorrectly shortened egress display name `1`; the canonical Ethernet1/1 resource remains visible. This extends the existing H4-2 label defect. |
| 99–100 | Table seeding sets Edge-C as start/source, CE-East as destination, default VRF, IPv4 family/type, and Both directions. The final trace resolves Edge-C→C→P2→B→CE-East with both endpoints reachable at the same +601.025 context. That gate is valid because Edge-C's 25 ms remains the largest uncertainty on this path. |

The table population also agrees with the boundary: move 95 has 609 total routes before the gate; move 98 has 618 total, with the newly admitted nine Edge-C rows. Displayed summary times round/truncate to milliseconds, so the exact UTC input—not the short “601.024 s” caption—is the evidence for the one-nanosecond rewind.

## H4-2 has two producer sites

The conceptual defect is the same assumption that the final slash-delimited token is a useful resource name, but there are two independent implementations:

1. `demo/rsl_demo_plugin/scale.py:90` (`scale_resource_label`) splits the full handle and usually retains only the last component. An interface handle ending in `interface:Ethernet4/1` therefore becomes `1`; a subinterface can become `1.320`.
2. `src/router_dump_analyzer/multi_node_route.py:4063` (`_generated_route_table_entry`) separately produces `egress_interface.name` with `egress_resource_id.rsplit("/", 1)[-1]` at line 4379. Move 98 demonstrates its output as `1` for all nine `edge-c/data-bridge-layer/VIRTUAL_INTERFACE/interface:Ethernet1/1` egress cells. Earlier snapshots also expose `1.310` for node-a's Ethernet1/1.310.

The frontend respects the supplied egress name. `routeDisplayValue()` at `frontend/assets/topology.js:1420` prefers `label`, `display_name`, `value`, then `name`; `normalizeRouteTableEntry()` at 1717 uses that value, and the cell renderer at 9607 renders it with the intact resource ID as supporting text/title. It performs no slash truncation on this path. Fixing only `scale_resource_label` would leave the route table defect. Prefer producer-declared display information, preserving the full opaque handle as a fallback where no label exists; avoid teaching the generic frontend to parse demo interface IDs.

## Warm fabric return timing

Move 88 starts at `02:35:45.663Z`, records a pending reconstruction snapshot by `02:35:46.116Z`, and has a settled snapshot at `02:35:55.193Z`. The observed interval from action start to settled observation is **9.530 seconds**. That is an upper bound on observed readiness, not an exact request duration: the ledger does not record the instant the result became ready between snapshots.

This is worth retaining as a warm-navigation latency observation, but it does not establish a regression, repeated default-node load, or CPU attribution. There is no matched baseline here. The earlier `fabric-navigation-load-review.md` shows that the warm fabric request path reuses the provider and bounded projections; the page performs a new reconstruction and table query on return. A load-progress display is not proof of a full history reload. Preserve the separate caveat that a root `/health` probe can itself load the default revision.

Documentation drift review: only audit evidence was added under `.runtime`; no author-visible behavior or maintained authoring documentation changed.
