# Resize-only graph focus and popup loss

Source review at `4f49279`; browser evidence belongs to parent move59 and `resize-focus-check.json`. No product edits or independent browser/server calls.

Before resize at 474×546, the focused SVG text has accessible label `Inspect uses_interface relationship between node-a/control-plane/EVPN_ES/es-00001 and node-a/data-bridge-layer/VIRTUAL_INTERFACE/ae-00001`; popup visible; graph scrollLeft=150.39999389648438. After resize only to 1280×720, active element is BODY, accessible label null, popup hidden, scrollLeft=0. The parent reports unchanged time, resource selection and graph mode.

## Source chain

- `frontend/assets/app.js:12561–12573` handles resize. It first repositions the existing correlation popup, then schedules `renderGraph()` after a 120 ms debounce whenever `state.graph` exists. This redraw is unconditional with respect to semantic graph changes.
- `renderGraph()` at `7786` immediately calls `closeCorrelationHover()`. Thus a valid pinned popup is explicitly dismissed during resize redraw even if its edge still exists and its anchor is geometrically valid.
- The renderer replaces `stage.innerHTML` with a new graph canvas (`7832` onward). The focused SVG text belongs to the removed subtree. There is no capture of the old `document.activeElement`/graph target identity and no `.focus()` call anywhere in this renderer to restore focus to its replacement.
- It does retain **inspection identity**: `validGraphInspection(graph, state.graphPinnedInspection)` validates the pinned resource/edge; after binding new controls, `setGraphInspection(stage, graph, retainedInspection)` restores highlight classes and aria-pressed states. This is not keyboard-focus or popup restoration. `setGraphInspection()` only changes classes/attributes; it never calls `showCorrelationHover()` or focuses the new target.
- `pinGraphInspection()` (`7750` vicinity) opens a popup only on explicit activation. The resize renderer never reacquires a live anchor and reopens the retained pinned inspection. Retaining `state.graphPinnedInspection` therefore cannot prevent this observed popup/focus loss.

**Diagnosis:** resize-only subtree replacement drops valid keyboard focus; explicit popup close without replacement-anchor restoration dismisses the valid pinned card. The observed move59 is consistent with this exact source path. Stable edge/resource IDs survive in state, but their DOM interaction state does not. This is distinct from losing focus because the selected resource/relationship disappeared or explicit navigation superseded an inspection.

The scrollLeft=0 observation alone is not an additional defect: the widened viewport may eliminate horizontal overflow, in which case clamping to zero is expected. To establish harmful scroll loss separately, use a redraw that retains overflow and a still-valid target. The clear demonstrated effects here are BODY focus and dismissal of a valid pinned popup after resize alone.

Documentation stewardship: runtime evidence note only; no public plug-in behavior or maintained author documentation changed.
