# Slash-containing interface display label

Read-only product-source review at `4f49279`; parent reports a settled P2 VIF row labeled `1` for the full `transit-p-2/.../interface:Ethernet4/1` identity. This note does not independently reproduce the browser result.

**Yes: the runtime compact-label helper takes the final slash-delimited basename.**

- `demo/rsl_demo_generator/assembly.py:873`, `_source_resource_id`, preserves the authored local ID intact in `node/layer/type/local-resource-id`.
- `assembly.py:1136`, `_source_resource_rows`, writes the complete ID plus properties and `source_resource_id` into `resources.table.txt`. This table has no dedicated display-label column. The original `interface:Ethernet4/1` remains in key/state JSON.
- `demo/rsl_demo_plugin/scale_data.py:1050–1083` loads these rows through `_resource_record`, imported from `scale_resource_record` at line 61.
- `demo/rsl_demo_plugin/scale.py:195` unconditionally supplies `label: scale_resource_label(resource_id)`.
- `scale.py:90–98`, `scale_resource_label`, splits the entire ID on `/` and returns its last component unless `parts[1]` is ETG/ETE. For `transit-p-2/data-bridge-layer/VIRTUAL_INTERFACE/interface:Ethernet4/1`, the result is exactly `1`. This is label loss in fixture runtime normalization; the canonical resource identity is intact.
- `frontend/assets/app.js:2211`, `resourceLabel`, prefers supplied `record.label`; it does not split interface names itself. A supplied `1` therefore propagates into table/graph labels.

There is an instructive alternative path: `assembly.py:2657–2664` derives topology interface labels by removing only the `interface:` prefix and explicitly supplies `Ethernet4/1`. Consequently topology labels can be correct while single-node normalized table labels are shortened. This is not evidence that the two displayed rows refer to different canonical resources.

Prior-report search across Markdown in `docs/` found mentions of the P1 Ethernet3/1 ↔ P2 Ethernet4/1 circuit in `docs/history-correlation-100-browser-audit-2026-10-23/README.md:93` and `docs/history-correlation-repairs-2026-10-23/README.md:105`, but no earlier finding describing interface labels becoming `1`, slash-name truncation, or basename-derived labels. This bounded search does not establish that every raw snapshot/ZIP lacks the symptom.

Scope: a presentation defect if the parent's settled observation is retained; source does not imply canonical-ID corruption, wrong temporal state, or failed search. Parent already confirms the early `Ethernet4/1` search applied successfully after loading. No product edits, browser/server calls or tests were performed for this note.
