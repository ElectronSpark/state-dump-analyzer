# V4 browser audit performance preparation

Prepared against commit `4f49279`. The sampler has not been started. Parent must verify the live server identity before starting it: expected PID 35624, loopback port 8883, and `router-state-lab-history-correlation-2026-10-23.tgz` (SHA-256 `5f204e5836be8966f148ae14671f9488007970619cff094cc9bda60c71892105`). A PID alone does not establish which fixture is loaded.

`sample_demo_process.py` reuses the previous v3 audit's native Windows process sampler. It opens only a query/read handle, never sends requests to or changes the process, and writes a new JSONL file exclusively. It records UTC/epoch/monotonic timestamps, working set (RSS), private committed bytes, cumulative user/kernel CPU, process-creation identity, and separately named process-lifetime peak counters. The stop record includes maxima over this audit's actual samples and sampled CPU delta. Sampling is nominally 1 Hz; actual timestamps must be used for calculations. Default duration is 5,400 seconds, with an enforced maximum of 7,200 seconds. Creating the stop file ends sampling without stopping the demo. An existing output or stop file must not be reused. Python syntax was checked without executing the sampler.

## Parent launch command

Run from the repository directory using the verified demo Python interpreter. If launched with `Start-Process`, use `-WindowStyle Hidden` and retain the sampler PID. The following is the sampler command; it does not launch the server:

```powershell
& 'C:/Users/82046/anaconda3/envs/router-dump-analyzer-demo/python.exe' -B '.runtime/history-correlation-100-v4-2026-10-23/sample_demo_process.py' --pid 35624 --output '.runtime/history-correlation-100-v4-2026-10-23/process-samples.jsonl' --stop-file '.runtime/history-correlation-100-v4-2026-10-23/stop-sampler' --duration 5400
```

After the last move and a short idle observation window, stop only the sampler:

```powershell
New-Item -ItemType File -Path '.runtime/history-correlation-100-v4-2026-10-23/stop-sampler'
```

## Interpretation rules

- Record each move's UTC start and completion plus its action, pending/settled state, and observed result. Include any overlap with another request. Workflow duration includes typing, rendering, waits, snapshots, and browser-tool overhead; it is not endpoint latency.
- Calculate server CPU deltas from adjacent cumulative counters and actual sample intervals. CPU percent is relative to one logical core and can exceed 100%. One-Hz interpolation only estimates move-associated CPU; keep the measured outer bracket and do not attribute overlapping work to a single action.
- Report first/last RSS and private memory and maximum **sampled during this audit** separately from process-lifetime high-water counters. Lifetime values may include work before this audit. One-Hz samples can miss brief peaks. Browser heap, child processes, and other host processes are not covered.
- Keep first-use/index-construction work separate from repeated warm operations. Record visible index-building progress and eventual settled results. Cancellation/retry can overlap or restart work; samples alone cannot prove request-level attribution.
- Reproduce an apparent slow operation under the same resource, search, cursor, graph mode, dashboard state, and cache condition. A successful exact repeat is not evidence that a first-use cost disappeared. A moving cursor is a different state reconstruction, not an identical repeat.
- Flag a performance candidate when a repeated comparable operation remains unexpectedly slow or CPU continues after the UI settles. Confirm progress, responsiveness of other controls, and eventual completion before calling it a stall. Do not call a single long browser-tool call a backend defect.
- A retained higher RSS after navigation is not sufficient to establish a leak. Compare several settled roundtrips and idle windows, and distinguish bounded cache growth from growth that continues with repetitions. Do not compare this broad live-server workflow to the isolated 52-phase benchmark as if they were the same workload.
- Keep automation failures, pending snapshots, and incomplete submissions inconclusive until a valid retry. This is an exploratory audit, not a statistical performance comparison.

## Existing known costs to distinguish from new regressions

The controlled v2 repair investigation (`docs/history-correlation-repairs-v2-2026-10-23/README.md`) already measured direct-service costs, excluding HTTP and browser rendering:

| Component | Fresh median wall / CPU | Exact-repeat median wall / CPU |
| --- | --- | --- |
| Resource table, empty search | 84.5 / 78.1 ms | 87.1 / 78.1 ms |
| Resource table, active search | 1.524 / 1.500 s | 2.83 ms / below CPU timer resolution |
| Focused correlations | 25.7 / 31.3 ms | 25.4 / 31.3 ms |
| Open live dashboards | 1.104 / 1.094 s | 1.126 / 1.094 s |

The first searched cursor took 6.888 s wall / 6.703 s CPU and raised RSS from 2.174 to 2.761 GiB. Search reconstructs safe searchable text across all 7,510 resources at a new timestamp; default-open dashboards reconstruct/redact 7,125 resource states and do not reuse the search-text snapshot. A repeated dashboard outlier was 3.642 s wall / 3.578 s CPU. Small focused graphs were around 3 ms; cases at the unchanged 500-node bound were around 0.25 s. These are observations, not upper bounds. The v3 correctness repair explicitly made no cursor-speedup claim.

The previous v3 audit (`docs/history-correlation-100-browser-audit-v3-2026-10-23/README.md`) saw a first event-log search build a 75,038,720-byte v7 sidecar for 1,250,005 events. File-lifetime evidence was about 51.3 seconds; an overlapping CPU episode consumed 93.219 CPU seconds over 93.005 wall seconds including cancellation/retry and resource operations. Exact warm event search later completed in a 0.660-second browser workflow. Sampled server RSS rose from 2.251 to 3.037 GiB and ended near 2.990 GiB. The current repaired archive has a different source identity, so prior cache existence must not be assumed.

No product, test, skill, or maintained authoring documentation was changed by this preparation. Documentation drift check: audit-only runtime instrumentation, with no author-visible behavior change.
