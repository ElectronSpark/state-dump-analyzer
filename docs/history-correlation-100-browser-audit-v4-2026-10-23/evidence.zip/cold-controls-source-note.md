# Cold node scaffold controls: bounded source note

Source-only review at `4f49279`, prompted by the parent's ongoing P2 cold-navigation observation. **Candidate only; no new browser reproduction or settled result was obtained here.** No product edits, server requests or tests.

## Ordering and expected outcomes

`frontend/pages/node.html:297–299` provides a normal enabled `resource-search` input. The collapse button at lines 321–328 is also enabled, advertises `aria-expanded="true"`, and starts with `Collapse correlation`. These controls exist before the module's async startup completes.

`frontend/assets/app.js:12747` starts `initialize()`. Its first substantial action awaits the bootstrap dataset request (line 12749); it later awaits `requestTimeline()` (12794). Only after both stages does the initial render sequence call `bindControls()` at line 12800. The binding installs correlation toggle handling at `12459` through `bindCorrelationPanelControls()`, and resource input handling at `12499`.

Consequently, before `bindControls()` runs:

- A native search input accepts typing and visually retains its DOM value, but its `input` event has no application listener yet. No immediate debounce or resource request follows that early event.
- The enabled collapse button has no application click handler. Clicking it has no state effect, queues no intent, and cannot change its caption. `state.correlationPanelExpanded` remains its initial `true` (line 266). Binding later calls `syncCorrelationPanel()` and leaves the panel expanded. The early collapse click is therefore discarded, assuming successful startup.

**The early search edit is not expected to be discarded on successful startup.** No assignment in app.js clears/replaces `resource-search.value`, and normal initial renders replace table/graph contents, not that outer input. The final startup `Promise.allSettled` starts `requestResources()` after binding (`12829`). That request reads the current DOM value directly at `5736` for scale mode or a relationship-bundled view, so an early `Ethernet4/1` should become the initial search request once startup reaches this stage. Generic non-scale rendering also reads the current DOM input (`6272`). It is temporarily inactive, not necessarily permanently ignored.

If startup fails, the catch branch replaces `<main>` with the startup error/retry panel (`12831` onward), which naturally removes the early input. That is a separate failure path, not evidence of successful-startup lost search state.

## Suggested settled confirmation

1. Preserve the exact pre-binding click/input timestamps and the loading indication. Wait until the resource table and graph settle independently.
2. Verify the search input still says `Ethernet4/1`, and whether the settled table/request reflects that exact search. If it does, classify early input as delayed application; do not label it lost.
3. Verify the correlation panel remains expanded despite the early click; click Collapse again after readiness and confirm it now works. This isolates unbound scaffold controls from persistent broken binding.
4. Distinguish accepting a native field edit from providing actionable controls during loading. The confirmed browser finding, if reproduced, would be the enabled collapse action silently doing nothing during bootstrap; search-state loss requires additional evidence.

No maintained author documentation drift: this runtime note changes no plug-in behavior, contract, example or command.

## Move 45: unbound range form triggers native navigation

Parent's browser evidence now establishes a stronger symptom of the **same initialization root**. During PE-A cold bootstrap, start `240.037599999` and end `240.037600000` were entered and **Apply range** clicked. The contextual `/node?topology_id=...&node_id=...&time_ns=...&return_to=...#temporal-topology` became `http://127.0.0.1:8883/node?#temporal-topology`; inputs reset and the loading UI reported two operations. This review did not independently operate the browser.

The exact source chain is:

1. `frontend/pages/node.html:264` declares `<form class="range-editor" id="range-editor">` with no `action`, `method`, inline submit handler, or disabled fieldset. Native defaults submit to the current document with GET.
2. Its start/end inputs (267, 271) have IDs but **no `name` attributes**. The submit button (273) is also unnamed. Their filled values therefore contribute no form entries to a native submission.
3. `frontend/assets/app.js:12506` attaches `submit → applyRangeEditor` only inside late `bindControls()`, reached after both awaited dataset bootstrap and timeline load (`12749`, `12794`, `12800`). Before then, no listener prevents native form submission.
4. `applyRangeEditor()` begins with `event?.preventDefault()`, but an early click never invokes this function. The browser proceeds with an empty GET form submission, replacing the query with an empty query and retaining the fragment, matching the observed `/node?#temporal-topology`.
5. This full navigation constructs a new document and new JS state, so previous resource-search and range-input DOM values reset. Losing `topology_id`, `node_id`, `time_ns` and `return_to` also loses the explicit member/time/return context. It is distinct from merely waiting for the original initialization to finish.

The two loading operations are browser-observed UI state; this source review does not establish whether the first server operation was cancelled, continued in the background, or overlapped the second. Do not infer a server leak or exact duplicate-load duration from the count alone.

Count the ignored early Collapse click and the native range submission/context loss as **one startup-controls initialization defect** with different consequences. The settled P2 check independently confirmed that early `Ethernet4/1` search text survived normal successful startup and filtered to one VIF row; its later loss during move45 follows the full page navigation, not normal initial resource rendering. No repair was made.
