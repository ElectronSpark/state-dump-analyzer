from collections import Counter
from hashlib import sha256
import json
from pathlib import Path
import shutil
import zipfile

root = Path(__file__).resolve().parent
repo = root.parents[1]
out = repo / 'docs/history-correlation-100-browser-audit-v4-2026-10-23'
out.mkdir(exist_ok=True)
moves = json.loads((root / 'moves.json').read_text(encoding='utf-8'))
assert [m['id'] for m in moves] == list(range(1, 101))
assert Counter(m['status'] for m in moves) == {'pass': 83, 'bug': 11, 'inconclusive': 6}
for move in moves:
    assert move['observation']
    assert (root / move['snapshot']).is_file()
    if move.get('settledSnapshot'):
        assert (root / move['settledSnapshot']).is_file()

def cell(value):
    return str(value).replace('|', '\\|').replace('\r', '').replace('\n', '<br>')

lines = [
    '# Fourth historical-route and correlation audit: 100-move ledger', '',
    '100 UI workflows, including preparation and retries: 83 pass, 11 defect observations across three findings, 6 inconclusive attempts. '
    'Action duration includes browser-tool and capture overhead. The settled observation timestamp, when present, is an upper bound on readiness, not endpoint latency. '
    'Raw snapshots and timing data are in `evidence.zip`; detailed structured entries are in `moves.json`.', '',
    '| Move | Action | Expected | Result | Observation | Action seconds | Evidence |',
    '| --- | --- | --- | --- | --- | ---: | --- |',
]
for m in moves:
    evidence = m['snapshot'] + (', ' + m['settledSnapshot'] if m.get('settledSnapshot') else '')
    status = m['status'] + (' / ' + ', '.join(m['finding_ids']) if m['finding_ids'] else '')
    lines.append('| ' + ' | '.join(cell(v) for v in [m['id'],m['action'],m['expected'],status,m['observation'],f"{m['seconds']:.3f}",evidence]) + ' |')
(out / 'moves.md').write_text('\n'.join(lines) + '\n',encoding='utf-8')
for name in ('moves.json','interface-truncation.png','early-range-load.png','performance-summary.md'):
    shutil.copy2(root / name, out / name)

environment = {
    'date_local': '2026-10-23', 'timezone': 'America/Toronto',
    'build': '4f49279e9192709aa81b5fa305b69051708d4e51',
    'branch': 'codex/comprehensive-router-dump-demo',
    'url': 'http://127.0.0.1:8883/', 'server_pid': 35624,
    'fixture': 'demo/fixtures/router-state-lab-history-correlation-2026-10-23.tgz',
    'fixture_sha256': '5f204e5836be8966f148ae14671f9488007970619cff094cc9bda60c71892105',
    'fixture_bytes': 286504605,
    'node_a': {'events':1250005,'resources':7510},
    'transit_p_2': {'events':1250006,'resources':7506},
    'server_restarted': False, 'product_changes': False,
    'viewport_override_reset': True, 'console_final_entries': 0,
    'sampler_stopped': True, 'demo_left_running': True,
    'verification': 'Server PID, executable, command line, listener and fixture identity were checked before auditing. This metadata records those observations; packaging does not issue HTTP requests.',
}
(root / 'environment.json').write_text(json.dumps(environment, indent=2) + '\n',encoding='utf-8')
files = sorted(p for p in root.iterdir() if p.is_file() and p.name != 'stop-sampler')
archive = out / 'evidence.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for path in files:
        z.write(path, path.name)
entries = []
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for path in files:
        data = path.read_bytes()
        assert z.read(path.name) == data
        entries.append({'path':path.name,'bytes':len(data),'sha256':sha256(data).hexdigest()})
manifest = {
    'archive':'evidence.zip', 'sha256':sha256(archive.read_bytes()).hexdigest(),
    'bytes':archive.stat().st_size, 'entry_count':len(entries),
    'move_count':len(moves), 'classifications':dict(Counter(m['status'] for m in moves)),
    'verification':'ZIP CRC and all entry SHA-256/source bytes verified after packaging', 'entries':entries,
}
(out / 'evidence-manifest.json').write_text(json.dumps(manifest,indent=2) + '\n',encoding='utf-8')
print(json.dumps({k:v for k,v in manifest.items() if k!='entries'},indent=2))
