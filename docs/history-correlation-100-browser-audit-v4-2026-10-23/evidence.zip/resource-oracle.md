# Resource-correlation source oracle, v4

Read-only source review at `4f49279`, using router-plugin-validate and the API map's historical route/correlation and frontend recovery checks. This document supplies expectations, not browser findings. Assumes the existing PE-A scale layout has 7,500 generated resources (375 ES, 750 multihome services, 375 neighbors, 374 VIFs); the assembled resource count is 7,510. Confirm fixture identity before applying these numbers. All times below are **single-node native cursor offsets**, not Fabric UTC.

## Exact identities and timing rules

- `ETG(i)` = `data-bridge-layer/ETG/blue/etg-{i:06d}`; `DTE(i)` = `data-bridge-layer/DTE/blue/dte-{i:06d}`.
- `P(i)` / `B(i)` = `data-bridge-layer/ETE/etg-{i:06d}/primary` / `/backup`.
- `ES(j)` = `control-plane/EVPN_ES/es-{j:05d}`; `VIF(j)` = `data-bridge-layer/VIRTUAL_INTERFACE/ae-{j:05d}`.
- `N(j)` = `control-plane/NEIGHBOR/blue/peer-{j:05d}`; `IP` = `control-plane/IP_ROUTING/blue`.
- Service i attaches to ES(i mod 375) at `+240 + i*0.0001 s`. ES j withdraws at `+360 + j*0.0001`; service i fails over later at `+360 + (375+i)*0.0001`. Restoration uses the same sequences beginning at +480.
- Half-open edge validity: old edge absent and new edge present at the exact change timestamp. Compare 1 ns before, exact, and rewind. Wait separately for graph and table to settle.
- Shared pairs are (0,375), (1,376), ..., (374,749). Each ES withdrawal/restore's `affected_services` is **2**, from actual membership, not 3.

## Eighteen suggested new moves/workflows

| Move | Native time / action | Exact expected facts |
| --- | --- | --- |
| 1 | +240.037599999, focus ETG(376), then ES(1) | ETG376 still single-home. ES1 exists through service1, but ETG376→ES1 `member_of_es` and ES1→P376 `active_path` are absent. This adds an interior shared pair beyond v3's endpoints. |
| 2 | +240.037600000, same roots | ETG376 all-active; B376 exists; membership and ES1→P376 appear. ES1 also retains its service1 membership/path. |
| 3 | Rewind +240.037599999; full/focused/full, then exact again | No future edges survive rewinding or scope changes. Judge full-graph omission using coverage notes, not as absence; use focused root to establish the edge set. |
| 4 | +360.000000000, focus ES0 and ETG0 | ES0 withdrawn and N0 down. ES0→VIF0 `uses_interface` is absent, but ES0→P0/P375 `active_path` and both service memberships remain until their distinct service transitions. Withdrawal alone does not select backups. |
| 5 | +360.037499999 → +360.037500000, ETG0/DTE0/ES0 | First boundary switches ETG0 selected egress P0→B0, ES0 active path P0→B0, DTE0 next_hop ETG0→IP. ETG375 remains on P375. ETG0 degraded; P0 down; B0 active. Structural `owns` and `member_of_es` survive. |
| 6 | +360.074999999 → +360.075000000, ETG375/DTE375/ES0 | Service375 switches only at .075: selected egress B375; ES0→B375 active path; DTE375→ETG376 next_hop (odd-service fallback), not IP. ES0 now has both backup paths. |
| 7 | +360.037599999 → +360.037600000, DTE1/ETG1 | Odd service1 switches next_hop ETG1→ETG2, selected egress P1→B1. Compare with even service0 to distinguish fallback policies. |
| 8 | +360.037399999 → +360.037400000, focus VIF0, N374 and ES374 | N374 flips up→down; N0 is already down since +360.0. VIF0→N0 and VIF0→N374 `has_neighbor` persist. VIF0 remains oper up/all-active; adjacency down is not deletion. ES374 has no VIF374 because only VIF0..373 exist. |
| 9 | +360.074899999 → +360.074900000, ES374/ETG374 | ES374 withdrawn earlier at .0374; first shared service374 changes P374→B374 now, while service749 remains P749. DTE374 falls back to IP. |
| 10 | +360.112399999 → +360.112400000, ES374/ETG749 | Later service749 finally changes P749→B749; DTE749 falls back to ETG750. Both memberships remain; ES374 now has B374 and B749 active paths. |
| 11 | +480.000000000, ES0/VIF0/DTE0 | ES0 up, N0 up, ES0→VIF0 restored. Service0 still uses B0/IP until +480.0375; service375 still uses B375/ETG376 until +480.0750. N374 still down. Restoring ES is distinct from restoring its services. |
| 12 | +480.037399999 → +480.037400000, VIF0/N374 | N374 becomes up exactly at .0374; both VIF0 neighbors now up. VIF0 home_mode and neighbor_count remain all-active and 2. `has_neighbor` edges did not disappear during the down period. |
| 13 | +480.037499999 → +480.037500000, ETG0/ES0/DTE0 | Service0 restores P0, ES0→P0, DTE0→ETG0. ETG375 still backup until .075. Rewind 1 ns to restore the mixed old state. |
| 14 | +480.074999999 → +480.075000000, ETG375/ES0/DTE375 | Service375 returns to P375; DTE375 returns from ETG376 to ETG375. Both ES0 paths now primary. |
| 15 | +120.037399999 → +120.037400000, VIF0/N374 | VIF0 already exists with N0 and neighbor_count=1. N374 appears at exact .0374, attaches to VIF0, and count becomes 2; VIF0 still single-home with blank ES before +240.0. This independently checks discovery rather than withdrawal. |
| 16 | +480.037400000, 474×546 viewport, VIF0 focused; horizontally scroll graph to outgoing column; activate N374 `has_neighbor` by pointer, then Enter/Space | Selected relation endpoints must be VIF0/N374 for all activations. Capture label/card rectangles and elementsFromPoint at label center after scroll; cards must not cover label. N0 is a different relation despite same type. |
| 17 | Same native time: pin that edge, scroll stage until anchor partly then fully clipped; click visible graph scope control; switch full/focus, reacquire label, activate again | Partial anchor may keep popup; fully clipped anchor dismisses it; scrolling back does not resurrect dismissed card. Full graph can omit root in bounded output; use coverage guidance. Scope control must remain reachable; the reacquired label must still identify N374. |
| 18 | On scrolled focused graph, keyboard-focus outgoing N374 label, resize narrow→wide→narrow, then change cursor +360.0374→+480.0374; repeat pointer activation after each settled redraw | Inspect label visibility, live anchor, horizontal scroll position, and keyboard focus separately. Relationship identity remains N374; down/up facts follow applied cursor. A rendered label alone or a working Enter key does not prove pointer access. |

## Source-derived candidates and limits

1. **Redraw/scroll/focus recovery candidate, unconfirmed.** `renderGraph()` replaces the complete canvas subtree, closes hover, measures width while the replacement canvas initially fits the viewport, then expands its min-width. A previously scrolled stage may clamp its scrollLeft while measuring, and an active SVG label is replaced without explicit focus restoration. Resize/cursor redraw after keyboard focus or horizontal scroll is worth observing. A dismissed popup on explicit navigation alone is not evidence of failure.
2. **Full-graph label occlusion candidate, unconfirmed.** Measured width reservation applies only in `mode-focus`; full dependency layout still uses the viewport width. Its labels are normally hidden until inspection. If a label becomes visible through keyboard/hover inspection, check actual pointer access rather than assuming the focused repair covers full mode. Treat any reproduced interception as a separate demonstrated instance only after recording geometry and identity.
3. No premature attachment or affected-services defect is claimed from this source: generator version 8 now starts shared membership/primary active paths at each service attachment and computes affected_services from membership.

Source anchors: `demo/rsl_demo_generator/_scale.py`: `_layout`, `_service_transition_time_ns`, `_vif_neighbor_count`, `_vif_state`, `_failover_target`, `_event_for_phase`, `_relationship_lines`, `_relationship_mutation_lines`; `frontend/assets/app.js`: `graphLayout`, `focusGraphLayout`, `renderGraph`, `positionCorrelationHover`; `frontend/assets/styles.css`: focused canvas overflow and full graph label visibility.

No browser/server calls, product changes, generation, heavy tests or benchmark. Default Python was C:/Python312/python.exe (3.12.5); its inventory attempt failed `ModuleNotFoundError: router_dump_analyzer`. Parent will run the inventory once with the installed demo environment, avoiding duplicate checks. Documentation drift check: this runtime oracle changes no plug-in behavior or maintained author material.
