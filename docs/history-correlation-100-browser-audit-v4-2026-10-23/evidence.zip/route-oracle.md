# Route history oracle for browser audit v4

Read-only source review at `4f49279e9192709aa81b5fa305b69051708d4e51`. No browser, server request, tests, generation, benchmark, or product edits were performed. These are expected results and candidate workflows, not confirmed bugs.

## Clock and evidence rules

UTC base is **1759680000000000000 ns** (`demo/router-state-lab-default.scenario.json`, metadata.timeline). An offset in this note means UTC offset from that base, unless explicitly called native. The node timeline's native numeric offset is not interchangeable with an absolute timestamp: use its displayed capture origin and actual selected-time fields.

| Node | Native minus UTC | Clock uncertainty |
| --- | ---: | ---: |
| node-a | −4 ms | 5 ms |
| node-b | +6 ms | 9 ms |
| node-c | +11 ms | 7 ms |
| node-d | −8 ms | 6 ms |
| node-e | +14 ms | 8 ms |
| transit-p-1 | +1 ms | 3 ms |
| transit-p-2 | −2 ms | 4 ms |
| ce-west | +19 ms | 12 ms |
| ce-east | −17 ms | 15 ms |
| edge-c | +31 ms | 25 ms |

The inventory producer assigns every route observation UTC **base +601 s**, then converts it to the owning node's native clock. Continuations convert through UTC to each executing node's native clock (`assembly.py:3610–3614`, `:4050–4053`). Route validity must cover the complete mapped uncertainty interval, including both endpoints (`multi_node_route.py:3983–4023`). Thus a path's first valid UTC moment is observation + the largest uncertainty of its required nodes, with other semantic constraints still applicable.

`strict` and `best_effort` topology clock policy do not eliminate uncertainty for these mapped clocks. They differ for missing mappings; all ten canonical nodes have usable mappings. Missing-hop resolution policy is a separate control and must not be reported as clock policy.

Known directly tested A↔B L3VPN gate: +601.006 s and +601.008999999 s are unresolved; +601.009 s and +601.010 s are valid. At +601.006 s A's route row exists while B's does not. This is correct: a valid source row cannot establish every continuation's validity. `tests/test_generated_assembly_api_integration.py:269–309` checks both origin directions, direct/table-seeded traces, and both missing-hop policies.

### Useful additional inventory thresholds

These are source-derived gates for compatible default IPv4 or named red contexts; verify the actual rendered route traverses the expected nodes before claiming endpoint reachability.

| Pair/context | Last required uncertainty | Last invalid UTC ns | First admitted UTC ns |
| --- | ---: | ---: | ---: |
| D↔E, red MPLS L3VPN via P1 | 8 ms (E) | 1759680601007999999 | 1759680601008000000 |
| A↔CE-West, default IPv4 | 12 ms (CE-West) | 1759680601011999999 | 1759680601012000000 |
| CE-West↔CE-East, default IPv4 | 15 ms (CE-East) | 1759680601014999999 | 1759680601015000000 |
| CE-West↔Edge-C, default IPv4 | 25 ms (Edge-C) | 1759680601024999999 | 1759680601025000000 |

The red VRF inventory is explicitly limited to D/E's `red_service_pe` routing group. An A/B red lookup can legitimately have no inventory; do not call that a frontend compatibility defect merely because the global VRF choice is advertised. Red offers `mpls_l3vpn/vpnv4_unicast` and `evpn_ip_prefix/l2vpn_evpn`. Default IPv4 extends to customer-edge roles; other generic contexts generally do not. See `demo/rsl_demo_plugin/scenario_registry.py:790–851`.

## Carrier history, with an important live-fixture limitation

The P1–P2 transport circuit is segment `p1-p2-sr`, prefix **10.64.255.0/31**, with exact resources:

- `transit-p-1/data-bridge-layer/VIRTUAL_INTERFACE/interface:Ethernet3/1`
- `transit-p-2/data-bridge-layer/VIRTUAL_INTERFACE/interface:Ethernet4/1`

The source physical-medium transition at +90 s is not a node observation. P1 observes down at **+90.050 s**, with 3 ms uncertainty; P2's +96 s down notification is **stale** and `update_snapshot=false`, so P2 stays up. P1 restores at **+240.100 s**. P2's +242.500 s up notification is an up→up refresh, not a prerequisite for the pair to appear recovered.

| UTC offset | Expected observed carrier state |
| --- | --- |
| +90.046999999 s | P1 window entirely before down: up; pair usable |
| +90.050 s | P1 window crosses transition: ambiguous, not a crisp up/down assertion |
| +90.053 s | P1 window entirely down; P2 stays up; segment degraded / typed circuit unusable |
| +96.005 s or +108.005 s | P2 stale carrier and failed route withdrawal do not mutate its state |
| +240.100 s | P1 window crosses restoration: ambiguous |
| +240.103 s | P1 window entirely restored; both observed carrier states up; pair can already be usable |
| +242.505 s | P2 refreshed up state; pair still usable |

The topology status evaluator samples every boundary inside the clock window and marks multiple possible states ambiguous (`multi_node_topology.py:509–620`). The typed provider delegates to that evaluator for the actual interface (`typed_topology.py:300–334`). It must not substitute final capture status.

**Live traces cannot isolate this early carrier transition:** inventory evidence begins at +601 s, and scenario evidence begins at +610 s plus a case ordinal in milliseconds. The API test for early carrier-dependent tracing deliberately mocks route/forwarding `valid_from_ns` to before the capture (`test_generated_assembly_api_integration.py:311–343`). That test is not evidence that the unmodified browser fixture must resolve a route at +100 or +243 s. At those times, unknown/rejected future route evidence is correct even if topology carrier state is known. Use topology and single-node resources for early carrier checks; use later valid inventory routes to verify the exact traversed circuit.

The Ottawa core supplies an additional asymmetric history: C `interface:Ethernet1/1.320` down at +420.200 s (7 ms uncertainty), P2 `interface:Ethernet2/1.320` down at +435 s (4 ms), P2 restores +521 s, C restores +528 s. Stable gate examples are +420.207 s, +435.004 s, +521.004 s, and +528.007 s. At +521.004 s the pair is still not fully usable because C remains down. Exact transition centers are ambiguous. Private authoring-medium IDs are not evidence the user should see in node dumps.

## Twenty additional route/cross-component moves

Each numbered item is a workflow suggestion, not an executed move. The parent may split setup and assertions into its browser ledger. Wait for both applied context and result panels to settle before classifying a result; rapid supersession cases intentionally inspect the final settled request.

1. Any-router D→E, red/MPLS L3VPN, both directions, absolute UTC **1759680601007999999**. Both directions must fail validity despite D's row already being admitted.
2. Advance one ns to **1759680601008000000**. Re-run; expect compatible D↔E route evidence through P1 (the inventory's sorted shortest path), then inspect the actual traversed circuit and endpoint identity.
3. Switch to return direction, inspect a hop/edge, then return to forward. Highlight and inspector must use that direction's executing hop, not the original evidence owner.
4. Seed D's red route from the table at the admitted timestamp. Re-run and compare context, endpoints, and path with the direct trace.
5. Rewind one ns, changing clock policy Strict→Best effort without changing the timestamp. Neither may resurrect future E evidence. Retired table seed must not bypass the validity gate.
6. Return to the admitted timestamp and change type to EVPN IP PREFIX, then family and VRF in alternate orders. Explicit advertised edits must survive; unsupported peer/context combinations should produce an explicit absence/error, not silent reuse of an old route.
7. A→CE-West default/IPv4 at **1759680601011999999**. Trace must not use future CE-West evidence.
8. Advance to **1759680601012000000**, trace both directions, then change start observation to P1 while retaining packet source A. Verify forward start differs from return target.
9. Reverse packet endpoints CE-West→A at the same timestamp, then trace from a freshly selected compatible row. Compare direct and seeded contexts rather than relying on a retired row ref.
10. Set CE-West→CE-East default/IPv4 at **1759680601014999999**, then exact **1759680601015000000**. Preserve the 12 ms vs15 ms source/destination distinction.
11. At the exact CE-East boundary, change Directions to Return only, submit, then Both directions, submit. Do not retain stale forward outcome when only return ran.
12. Change destination to Edge-C; reconstruct **1759680601024999999**, then **1759680601025000000**. Only the later request has full Edge-C evidence.
13. While the exact Edge-C trace is pending, rewind to the preceding timestamp and submit again. The final applied identity, row list, graph, and outcome must all describe the last request, including its unresolved state.
14. Return to exact Edge-C time, inspect route, open its node workspace, select the authored recovery default-route resource, then Back to fabric. A node-local cursor move that is not written into return URL must not silently replace the frozen fabric timestamp.
15. Select P1→P2, default/ISIS UNDERLAY at a valid inventory time (+700s). Verify the segment really is **10.64.255.0/31** / Ethernet3/1↔Ethernet4/1, not a path through A/B that merely contains both routers.
16. Reconstruct topology at +90.046999999s, +90.050s, +90.053s, inspecting that same circuit. Compare up→ambiguous→unusable while keeping route future-evidence rejection separate.
17. Open P2 at +96.005s and inspect Ethernet4/1 plus its stale notification. It must remain up. Return to fabric and repeat +90.053s to check frozen identity recovery.
18. At +240.100s then +240.103s, inspect P1 restoration uncertainty and stable up state; compare +242.505s. Do not wait for the non-mutating P2 refresh to call observed carrier recovery.
19. Inspect Ottawa core at +521.004s then +528.007s; P2-only restoration must not make the C↔P2 pair fully usable. Open C's interface resource and verify local state agrees with its applied time; return and rewind.
20. Reconstruct latest, switch to an explicit known scenario (for example single-active or an all-active VPN), inspect return direction/service context, then reapply the earlier absolute timestamp. Verify obsolete direction/path selection and service popup retire with the context; a scenario's +610s observation cannot silently become an early historical route.

## Candidate defects to watch, not demonstrated findings

- A valid source table row could outlive its context and keep a stale seed or popup after the destination clock boundary is crossed backward. Existing direct/seed tests reduce this risk but UI supersession still needs actual moves.
- Per-node native/UTC confusion can masquerade as a graph/table disagreement when a node workspace opens from fabric. Record both bases and their frozen IDs before calling it a bug.
- Red/global route capabilities are not per-endpoint eligibility. Keep an unsupported lookup's legitimate error separate from a silently changed user control or leaked old result.
- Circuit status must be based on the actually traced link and applied local state, not final snapshot/physical authoring truth. Early route rejection is an intentional fixture limit, not a blocked test caused by the app.

Documentation drift review: this oracle adds only audit preparation evidence under `.runtime`; public plug-in behavior and maintained authoring materials are unchanged.
