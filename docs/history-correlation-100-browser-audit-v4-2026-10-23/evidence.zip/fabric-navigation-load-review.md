# Fabric return / default-node load source review

Scope: read-only source review at commit `4f49279e9192709aa81b5fa305b69051708d4e51`, supporting browser moves 40–44. No browser requests, server requests, tests, benchmarks, or product changes were performed by this review. The source conclusions below are not captured CPU attribution.

## Conclusion

Returning from P2 to a fabric page whose topology provider has already initialized does **not** have a source path that reloads node-a's full history merely to bootstrap the page. The fabric progress indicator alone cannot demonstrate such a load. Opening PE-A afterward can legitimately cold-load node-a because the demo deliberately keeps only one materialized revision.

There is a separate, concrete first-use optimization candidate: `DemoTopologyProvider.get()` initially loads the default node's full dataset to obtain only four scalar topology metadata fields. That happens once per runtime session, not once per fabric navigation. It must not be attributed to moves 40–41 without evidence that the provider was recreated or the server restarted.

## Request and cache path

1. `frontend/pages/topology.html:643` loads `topology.js`, not the single-node `app.js`. `topology.js:10330` begins a load-progress lease, fetches topology capabilities, derives a small local `bootstrap` object from those capabilities, starts route-capability discovery, binds controls, and reconstructs topology. `runQuery()` at 9972 then queries route tables asynchronously. There is no `/v1/workspace` request in this fabric startup path.
2. `topology.js:159` polls `/v1/analysis-load`. `web/service_api.py:37` and `:173` only read the load tracker's snapshot. They cannot materialize a node runtime.
3. The capabilities/reconstruct/route APIs in `web/runtime_api.py:1083` onward obtain cached providers. `_multi_node_topology()` at 614 and `_multi_node_route()` at 639 wrap provider access in `_loading_operation()`. That wrapper (`normalized_data.py:2880`) starts telemetry; it does not itself load a dataset. A short progress episode can therefore represent reconstruction or an already-cached provider call.
4. `demo/rsl_demo_plugin/session.py:348` constructs the topology service only when `_service is None`. Its first construction explicitly calls `load_dataset(default_revision_id)`, then caches the resulting service. The route provider (`:402`) also caches its service and consumes bounded per-node route projections. The process shares these providers through the application runtime session (`runtime.py:557–588`, request binding at `:622`). Reset happens on session close, not on node navigation.
5. After construction, topology status uses the detached bounded state/claim maps in `typed_topology.py:282`; route projections use `projection_for_node()` in `route_policy.py:274`. `assembly_store.py:599` documents and implements that projection accessor without loading history. Neither core multi-node service has a `load_dataset` / `dataset_for_revision` call.
6. Single-node startup is different: `app.js:12747` requests `bootstrapDatasetPath()`, which selects `/v1/nodes/{node_id}/workspace` when contextual node identity exists (`:429`). The demo runtime sets `cache_size=1` (`session.py:448–460`). `assembly_store.py:605` returns a lease on a hit; a miss validates the requested archive, reserves an incoming slot, evicts idle history, and loads that revision. Thus P2 → PE-A can legitimately pay the full node-a cold-load cost even though the intervening fabric operation is cheap.

## Separate source candidates, not demonstrated audit defects

- **Initial topology metadata dependency:** `build_topology_metadata()` (`topology_contract.py:515`) only reads `demo.revision_id`, `capture_ns`, `timeline_start_ns`, and `timeline_end_ns`. Loading the full default-node dataset solely for these is a valid optimization target. A change should derive equivalent validated metadata from the bounded assembly/projection metadata and preserve clock/time-bound semantics. No reduction or browser timing is established by this review.
- **Root health request:** `/health` invokes `analysis_health_projection()` (`runtime_api.py:760`), which calls unscoped `load_dataset()`. The demo defaults an unscoped request to node-a (`data.py:116–131`). An actual root health probe after P2 can therefore trigger a default-node cold load. Neither topology.js nor its imported shared modules request `/health`; management.js does. Do not invoke `/health` as a supposedly harmless observer when attributing this performance issue. Any concurrent monitor or management tab would need separate request evidence.

## Evidence needed for stronger attribution

The move ledger records fabric return at `2026-10-24T02:22:09.910Z` and PE-A entry at `02:22:32.333Z`. Those action timestamps do not identify server phases, revisions loaded, or CPU work. Attribute a repeated default-node load only after matching the request path, load revision/stage, and server operation during the interval. Preserve the distinction between the first-use provider load, ordinary bounded reconstruction, and the subsequent intentional PE-A cold switch.

Documentation drift check: this note changes no author-visible behavior, APIs, examples, or commands; maintained authoring documentation requires no update.
