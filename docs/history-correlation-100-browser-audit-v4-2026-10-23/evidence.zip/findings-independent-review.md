# Findings review at move 76

Read-only review of the saved ledger/snapshots, diagnostic JSON, source notes and prior Markdown audit reports at `4f49279`. This is an evidence/source review, not a second browser run. Parent is continuing the ledger; counts below deliberately freeze at IDs 1–76.

## Count reconciliation

Through move76: **76 ledger rows = 62 pass + 6 bug + 4 inconclusive + 3 pending-review + 1 observed**. Six bug-classified rows are not six distinct defects. Rows36/43/45/47 represent one initialization defect; rows59/61 represent one resize-recovery defect. The label defect is observed in rows37/38, whose primary state/identity assertions are correctly marked pass. It can be reported as a third finding without relabeling those entire workflows or claiming eight failed assertions. Final counts must be recomputed after move100 and pending-review classification; this is not the final audit total.

## Three supported findings

| Finding | Evidence | Review conclusion / limits |
| --- | --- | --- |
| Enabled startup controls run before application handlers exist | Ignored Collapse:36/43; native Apply range navigation:45/47; cold-controls-source-note.md; early-range-load.png | **One confirmed root, two consequences.** Binding waits for dataset and timeline; early Collapse does nothing. The unnamed GET range form submits natively before prevention binds, strips query context and reloads. Strongest consequence is loss of explicit node/time/return context. Normal successful startup preserves/applies early search text; do not claim ordinary search loss. Two loading operations do not independently prove a server leak. |
| Slash-containing interface name displayed as `1` | P2 VIF row37 and focused graph38; interface-label-source-note.md | **Confirmed presentation defect.** Runtime scale_resource_label takes the last slash component; frontend honors that supplied label. Canonical ID, temporal up state, and Ethernet4/1 search remain correct. Table and graph repetitions are one normalization root, not separate defects. Topology's correct Ethernet4/1 label is a separate presentation path. |
| Resize-only correlation redraw drops valid keyboard focus and pinned popup | Width resize59; independent height-only resize61; resize-focus-check.json and height-resize-focus.json; graph-resize-focus-source-note.md | **Confirmed interaction recovery defect.** renderGraph closes the card and replaces the focused SVG subtree; retaining inspection ID/classes does not restore focus or popup. Height-only repeat strengthens attribution beyond overflow changes. No independent scroll defect is needed: wide-view zero scroll can be expected; narrow height-only clamping is supporting state loss but belongs to this redraw root. |

The saved resize JSON shows SVG text with the exact ES1→VIF1 uses_interface accessible label before width resize and BODY afterward, with popup visible→hidden. Height-only JSON likewise reports BODY/hidden. These are concrete focus/card observations; they do not establish that the relationship itself disappeared or changed identity.

## Duplicate check against prior reports

- Prior HC-03 (`docs/history-correlation-100-browser-audit-2026-10-23/README.md` and its repairs) concerns a pinned correlation card **remaining visible after its anchor scrolls out**. Current resize finding is the converse: a still-valid inspected relationship loses its card/focus during layout-only replacement. Different trigger and failing branch; do not count the old off-screen persistence as newly reproduced here.
- LV03 (`docs/lane-vpn-browser-audit-2026-10-23/README.md:35`) is an analogous delayed-redraw focus loss in **Fabric VPN service context**, repaired by preserving its service trigger across topology redraw. Current issue is single-node app.js's window-resize→renderGraph path and SVG relationship target. Report it as another affected surface with the same broad failure pattern, not a regression proof of the repaired topology path.
- HC3-3 in the third historical audit concerns resource cards intercepting narrow relationship-label pointer clicks. Current focused canvas spacing repair is not shown to fail by resize focus loss. Keep pointer occlusion and resize DOM recovery distinct.
- Search of prior Markdown audit/findings reports found no exact early unbound GET range/context-loss finding and no interface-label basename `1` finding. Prior reports mention the Ethernet3/1↔Ethernet4/1 circuit but not this display defect. Raw snapshots/ZIPs were not exhaustively searched, so avoid a blanket claim that the symptom was never seen before.

Other source candidates (e.g. full-mode hidden-label occlusion) remain candidates unless later browser moves establish them. Pending rows40–42 and inconclusive18/19/25/68 are not additional defects on this review's evidence. Preserve their provenance in the final ledger.

No product modifications, browser/server operations, tests or benchmarks. Only this runtime review was written; maintained plug-in author material requires no update.

## Final ledger/report review, all 100 moves

Reviewed the completed runtime moves.json and `docs/history-correlation-100-browser-audit-v4-2026-10-23/README.md`. Final ledger is **100 rows: 83 pass, 11 bug, 6 inconclusive**, with no observed/pending-review rows. This supersedes the interim counts and classification comments above; rows37/38 were deliberately reclassified to bug after their label observations became finding H4-2.

- **H4-1:** four bug moves36/43/45/47, one startup-readiness root. The report accurately separates normal early-search retention from input loss caused by native form navigation, and avoids claiming a server leak from two loading operations.
- **H4-2:** five bug moves37/38/86/87/98, one grouped naming/disambiguation finding across two independently affected producers. P2 table/graph label `1`, PE-A table/graph label `1.310`, and Edge-C route-table egress `1` are repeated manifestations. **Important final source correction:** route-table egress name comes from `src/router_dump_analyzer/multi_node_route.py:4379`, not the demo topology generator. That exact source uses `egress_resource_id.rsplit('/', 1)[-1]`. The report correctly names this second producer separately from demo scale normalization and correctly warns that fixing the scale helper alone is insufficient. The `assembly.py` topology-label example is illustrative, not the route-table producer.
- **H4-3:** two bug moves59/61, one single-node graph redraw recovery root. Report accurately limits this to focus and valid pinned-popup loss; it does not count wide-viewport scroll clamping as another defect. The previous LV03 topology service-context issue is analogous but a separate affected renderer, so no duplicate finding is added.

The eleven bug rows therefore partition exactly as **4+5+2**, supporting three findings rather than eleven distinct defects. The six inconclusive IDs18/19/25/68/78/96 agree with the report's bounded descriptions; attempted operations and tool failures are not promoted to product failures. The report also correctly records the full-mode pointer-occlusion suspicion as not reproduced, rather than adding a source-only fourth finding.

No factual correction to the final README is required on this review's source/evidence scope. Its narrow layout, identity/state, readiness, and repeated-resize explanations agree with the reviewed source notes and saved observations. Final console and performance statements remain bounded as written; this review does not independently validate process samples or packaging hashes.

This final review used file/source reads only and changed no report or product file, performed no browser/server action, and ran no tests or benchmarks.
