"""Offline analysis only: join saved demo-process samples and move timestamps."""
from __future__ import annotations

from bisect import bisect_left, bisect_right
from collections import Counter
from datetime import datetime, timezone
import json
from pathlib import Path
import statistics

ROOT = Path(__file__).resolve().parent
records = [json.loads(line) for line in (ROOT / "process-samples.jsonl").read_text(encoding="utf-8").splitlines() if line.strip()]
samples = [r for r in records if r["kind"] == "sample"]
moves = json.loads((ROOT / "moves.json").read_text(encoding="utf-8-sig"))
times = [s["epoch_ns"] / 1e9 for s in samples]


def epoch(value):
    return datetime.fromisoformat(value.replace("Z", "+00:00")).timestamp()


def utc(value):
    return datetime.fromtimestamp(value, timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def cpu(at):
    index = bisect_left(times, at)
    if index == 0:
        return samples[0]["cpu_s"]
    if index == len(times):
        return samples[-1]["cpu_s"]
    a, b = samples[index - 1], samples[index]
    ratio = (at - times[index - 1]) / (times[index] - times[index - 1])
    return a["cpu_s"] + ratio * (b["cpu_s"] - a["cpu_s"])


def window(start, end):
    lo = max(0, bisect_right(times, start) - 1)
    hi = min(len(times) - 1, bisect_left(times, end))
    bracket = samples[lo:hi + 1]
    inside = samples[bisect_left(times, start):bisect_right(times, end)]
    return {
        "start_utc": utc(start), "end_utc": utc(end), "wall_s": end - start,
        "fully_sampled": start >= times[0] and end <= times[-1],
        "interpolated_cpu_s": cpu(end) - cpu(start),
        "outer_sample_bracket": {
            "start_utc": samples[lo]["utc"], "end_utc": samples[hi]["utc"],
            "wall_s": times[hi] - times[lo], "cpu_s": samples[hi]["cpu_s"] - samples[lo]["cpu_s"],
            "first_rss_bytes": bracket[0]["rss_bytes"], "last_rss_bytes": bracket[-1]["rss_bytes"],
        },
        "contained_sample_count": len(inside),
        "max_contained_rss_bytes": max((s["rss_bytes"] for s in inside), default=None),
        "max_contained_private_bytes": max((s["private_bytes"] for s in inside), default=None),
    }


assert [m["id"] for m in moves] == list(range(1, 101))
assert len({s["process_creation_filetime"] for s in samples}) == 1
assert all(b > a for a, b in zip(times, times[1:]))
assert all(b["cpu_s"] >= a["cpu_s"] for a, b in zip(samples, samples[1:]))
assert records[-1]["kind"] == "stop" and records[-1]["reason"] == "stop_file"
assert records[-1]["samples"] == len(samples)
assert records[-1]["audit_sampled_peak_rss_bytes"] == max(s["rss_bytes"] for s in samples)
assert records[-1]["audit_sampled_peak_private_bytes"] == max(s["private_bytes"] for s in samples)

per_move = []
for move in moves:
    start, end = epoch(move["started"]), epoch(move["ended"])
    entry = {"id": move["id"], "action": move["action"], "status": move["status"], "observation": move["observation"], "action_window": window(start, end)}
    if move.get("settledAt"):
        entry["recorded_followup_window"] = window(start, epoch(move["settledAt"]))
        entry["recorded_followup_gap_after_action_s"] = epoch(move["settledAt"]) - end
        entry["followup_snapshot"] = move.get("settledSnapshot")
        entry["followup_limit"] = "Saved observation time, not exact completion. Other components can remain pending; interpret snapshot and observation."
    per_move.append(entry)


def move_start(n):
    return epoch(moves[n - 1]["started"])


last_observation = max(epoch(m.get("settledAt", m["ended"])) for m in moves)
phase_bounds = [
    ("pre_audit_idle", times[0], move_start(1)),
    ("initial_fabric_and_route_moves_1_33", move_start(1), move_start(34)),
    ("p2_cold_entry_and_initial_search_moves_34_36", move_start(34), move_start(37)),
    ("p2_warm_inspection_moves_37_39", move_start(37), move_start(40)),
    ("fabric_return_moves_40_41", move_start(40), move_start(42)),
    ("pe_a_cold_entry_and_unbound_form_reloads_moves_42_48", move_start(42), move_start(49)),
    ("warm_pe_a_historical_resource_moves_49_87", move_start(49), move_start(88)),
    ("return_fabric_and_ce_routes_moves_88_100", move_start(88), last_observation),
    ("post_audit_idle", last_observation, times[-1]),
]
phases = [{"name": name, **window(a, b)} for name, a, b in phase_bounds]

active = []
for i, (a, b) in enumerate(zip(samples, samples[1:])):
    delta_cpu = b["cpu_s"] - a["cpu_s"]
    wall = times[i + 1] - times[i]
    if delta_cpu / wall >= 0.15:
        active.append((times[i], times[i + 1], delta_cpu / wall))
groups = []
for interval in active:
    if groups and interval[0] - groups[-1][-1][1] <= 2.05:
        groups[-1].append(interval)
    else:
        groups.append([interval])
episodes = []
for group in groups:
    a, b = group[0][0], group[-1][1]
    episodes.append({**window(a, b), "max_interval_cpu_percent_of_one_core": max(x[2] for x in group) * 100,
                     "action_overlap_move_ids": [m["id"] for m in moves if epoch(m["started"]) <= b and epoch(m["ended"]) >= a]})

def distribution(values):
    return {"count": len(values), "min_s": min(values), "median_s": statistics.median(values), "max_s": max(values), "sum_s": sum(values)}

gaps = [{"after_move": a["id"], "before_move": b["id"], **window(epoch(a["ended"]), epoch(b["started"]))} for a, b in zip(moves, moves[1:]) if epoch(b["started"]) >= epoch(a["ended"])]
summary = {
    "scope": "Saved 1 Hz snapshots of live demo Python PID 35624; not browser heap or an isolated benchmark.",
    "start_record": records[0], "stop_record": records[-1],
    "sample_count": len(samples), "process_creation_identities": list({s["process_creation_filetime"] for s in samples}),
    "sample_interval_s": distribution([b - a for a, b in zip(times, times[1:])]),
    "sampled_window": window(times[0], times[-1]),
    "first_rss_bytes": samples[0]["rss_bytes"], "last_rss_bytes": samples[-1]["rss_bytes"],
    "first_private_bytes": samples[0]["private_bytes"], "last_private_bytes": samples[-1]["private_bytes"],
    "first_lifetime_peak_rss_bytes": samples[0]["process_lifetime_peak_rss_bytes"],
    "last_lifetime_peak_rss_bytes": samples[-1]["process_lifetime_peak_rss_bytes"],
    "last_lifetime_peak_private_bytes": samples[-1]["process_lifetime_peak_private_bytes"],
    "sampled_peak_rss_occurrences_utc": [s["utc"] for s in samples if s["rss_bytes"] == max(x["rss_bytes"] for x in samples)],
    "status_counts": dict(Counter(m["status"] for m in moves)),
    "action_duration_s": distribution([m["seconds"] for m in moves]),
    "fabric_route_action_duration_s": distribution([m["seconds"] for m in moves if m["id"] <= 33 or m["id"] >= 88]),
    "warm_pe_a_action_duration_s": distribution([m["seconds"] for m in moves if 49 <= m["id"] <= 87]),
    "phases": phases, "moves": per_move, "cpu_episodes": sorted(episodes, key=lambda r: r["interpolated_cpu_s"], reverse=True),
    "between_action_gaps": gaps,
    "limits": [
        "Action seconds include browser-tool overhead, native UI interactions and snapshots; they do not measure request latency.",
        "Recorded follow-up times are observation bounds, with possible deliberate tool gaps and other components still pending.",
        "Interpolated CPU is not request attribution; the outer measured bracket can overlap adjacent work.",
        "Sampled memory peaks can miss shorter peaks; process-lifetime peaks must not be reported as audit sampled peaks.",
        "No event-log search was recorded in these 100 moves, and no isolated benchmark was run; old index-build costs are contextual only.",
    ],
}
(ROOT / "performance-stats.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
print(json.dumps({k: summary[k] for k in ["sample_count", "sample_interval_s", "sampled_window", "first_rss_bytes", "last_rss_bytes", "first_private_bytes", "last_private_bytes", "sampled_peak_rss_occurrences_utc", "status_counts", "action_duration_s", "fabric_route_action_duration_s", "warm_pe_a_action_duration_s", "phases"]}, indent=2))
