"""One-Hz Windows process CPU/RSS monitor for the browser audit only."""
from __future__ import annotations

import argparse
import ctypes
from ctypes import wintypes
from datetime import datetime, timezone
import json
from pathlib import Path
import time


class ProcessMemoryCounters(ctypes.Structure):
    _fields_ = [
        ("cb", wintypes.DWORD), ("PageFaultCount", wintypes.DWORD),
        ("PeakWorkingSetSize", ctypes.c_size_t), ("WorkingSetSize", ctypes.c_size_t),
        ("QuotaPeakPagedPoolUsage", ctypes.c_size_t), ("QuotaPagedPoolUsage", ctypes.c_size_t),
        ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t), ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
        ("PagefileUsage", ctypes.c_size_t), ("PeakPagefileUsage", ctypes.c_size_t),
        ("PrivateUsage", ctypes.c_size_t),
    ]


def utc_now():
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def ft_int(value):
    return (value.dwHighDateTime << 32) | value.dwLowDateTime


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--pid", type=int, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--stop-file", type=Path, required=True)
    parser.add_argument("--duration", type=float, default=5400)
    args = parser.parse_args()
    if not 0 < args.duration <= 7200:
        parser.error("--duration must be greater than zero and at most 7200 seconds")
    if args.stop_file.exists():
        parser.error("stop file already exists; use a new output/stop-file pair")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    psapi = ctypes.WinDLL("psapi", use_last_error=True)
    kernel32.OpenProcess.argtypes = (wintypes.DWORD, wintypes.BOOL, wintypes.DWORD)
    kernel32.OpenProcess.restype = wintypes.HANDLE
    kernel32.GetProcessTimes.argtypes = (wintypes.HANDLE,) + (ctypes.POINTER(wintypes.FILETIME),) * 4
    kernel32.GetProcessTimes.restype = wintypes.BOOL
    kernel32.GetExitCodeProcess.argtypes = (wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD))
    kernel32.GetExitCodeProcess.restype = wintypes.BOOL
    kernel32.CloseHandle.argtypes = (wintypes.HANDLE,)
    kernel32.CloseHandle.restype = wintypes.BOOL
    psapi.GetProcessMemoryInfo.argtypes = (wintypes.HANDLE, ctypes.POINTER(ProcessMemoryCounters), wintypes.DWORD)
    psapi.GetProcessMemoryInfo.restype = wintypes.BOOL
    handle = kernel32.OpenProcess(0x1000 | 0x10, False, args.pid)
    if not handle:
        raise ctypes.WinError(ctypes.get_last_error())
    start = time.monotonic()
    count = 0
    reason = "duration"
    first_cpu_s = None
    last_cpu_s = None
    sampled_peak_rss = 0
    sampled_peak_private = 0
    try:
        with args.output.open("x", encoding="utf-8", buffering=1) as output:
            output.write(json.dumps({"kind": "start", "utc": utc_now(), "epoch_ns": time.time_ns(), "pid": args.pid, "sample_period_s": 1, "hard_duration_s": args.duration, "stop_file": str(args.stop_file), "metrics": "demo Python process only; working-set/private snapshots, cumulative CPU; not browser heap"}) + "\n")
            deadline = start
            while time.monotonic() - start < args.duration:
                if args.stop_file.exists():
                    reason = "stop_file"
                    break
                exit_code = wintypes.DWORD()
                if not kernel32.GetExitCodeProcess(handle, ctypes.byref(exit_code)):
                    raise ctypes.WinError(ctypes.get_last_error())
                if exit_code.value != 259:
                    reason = "target_exited"
                    break
                creation, exit_time, kernel, user = (wintypes.FILETIME() for _ in range(4))
                memory = ProcessMemoryCounters()
                memory.cb = ctypes.sizeof(memory)
                if not kernel32.GetProcessTimes(handle, ctypes.byref(creation), ctypes.byref(exit_time), ctypes.byref(kernel), ctypes.byref(user)):
                    raise ctypes.WinError(ctypes.get_last_error())
                if not psapi.GetProcessMemoryInfo(handle, ctypes.byref(memory), memory.cb):
                    raise ctypes.WinError(ctypes.get_last_error())
                cpu_s = (ft_int(kernel) + ft_int(user)) / 10_000_000
                first_cpu_s = cpu_s if first_cpu_s is None else first_cpu_s
                last_cpu_s = cpu_s
                sampled_peak_rss = max(sampled_peak_rss, memory.WorkingSetSize)
                sampled_peak_private = max(sampled_peak_private, memory.PrivateUsage)
                output.write(json.dumps({"kind": "sample", "process_creation_filetime": ft_int(creation), "utc": utc_now(), "epoch_ns": time.time_ns(), "elapsed_s": time.monotonic() - start, "cpu_s": cpu_s, "user_cpu_s": ft_int(user) / 10_000_000, "kernel_cpu_s": ft_int(kernel) / 10_000_000, "rss_bytes": memory.WorkingSetSize, "private_bytes": memory.PrivateUsage, "process_lifetime_peak_rss_bytes": memory.PeakWorkingSetSize, "process_lifetime_peak_private_bytes": memory.PeakPagefileUsage}) + "\n")
                count += 1
                deadline = max(deadline + 1, time.monotonic())
                time.sleep(max(0, deadline - time.monotonic()))
            output.write(json.dumps({"kind": "stop", "utc": utc_now(), "epoch_ns": time.time_ns(), "elapsed_s": time.monotonic() - start, "samples": count, "reason": reason, "audit_sampled_peak_rss_bytes": sampled_peak_rss, "audit_sampled_peak_private_bytes": sampled_peak_private, "sampled_cpu_delta_s": last_cpu_s - first_cpu_s if first_cpu_s is not None else None}) + "\n")
    finally:
        kernel32.CloseHandle(handle)


if __name__ == "__main__":
    main()
