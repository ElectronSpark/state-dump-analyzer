"""Local audit-only response gate; forwards unmodified bytes to the existing demo.

Arm one response using gate.json: {id, path_contains, body_contains?}.
Create release-<id> to release it. No gate affects upstream execution or any
other response. Each gate can be consumed once and fails open after 90 seconds.
"""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.error import HTTPError
from datetime import datetime, timezone
import json
import threading
import time

ROOT = Path(__file__).resolve().parent
LOCK = threading.Lock()
USED = set()

def log(kind, **facts):
    with LOCK:
        with (ROOT / 'proxy.jsonl').open('a', encoding='utf-8') as out:
            out.write(json.dumps(dict(utc=datetime.now(timezone.utc).isoformat(), kind=kind, **facts)) + '\n')

class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def do_GET(self):
        self.forward()

    def do_POST(self):
        self.forward()

    def forward(self):
        if not self.path.startswith('/') or self.path.startswith('//'):
            self.send_error(400)
            return
        route = 'http://127.0.0.1:8883' + self.path
        data = self.rfile.read(int(self.headers.get('Content-Length', '0'))) if self.command == 'POST' else None
        request_body = data.decode('utf-8') if data else ''
        req = Request(route, data=data, method=self.command, headers={'Accept': self.headers.get('Accept', '*/*'), 'Content-Type': self.headers.get('Content-Type', 'application/json')})
        log('request', path=self.path, method=self.command, body=request_body)
        try:
            try:
                response = urlopen(req, timeout=150)
            except HTTPError as error:
                response = error
            with response:
                body = response.read()
                status = response.status
                headers = list(response.headers.items())
            gate = None
            try:
                candidate = json.loads((ROOT / 'gate.json').read_text(encoding='utf-8-sig'))
                identity = candidate['id']
                with LOCK:
                    if identity not in USED and candidate['path_contains'] in self.path and candidate.get('query_contains', '') in self.path and candidate.get('body_contains', '') in request_body:
                        USED.add(identity)
                        gate = identity
            except (OSError, ValueError, KeyError):
                pass
            if gate:
                log('held', gate=gate, path=self.path, status=status, bytes=len(body))
                until = time.monotonic() + 90
                while not (ROOT / ('release-' + gate)).exists() and time.monotonic() < until:
                    time.sleep(0.05)
                log('released', gate=gate, path=self.path, explicit=(ROOT / ('release-' + gate)).exists())
            self.send_response(status)
            for key, value in headers:
                if key.lower() not in {'content-length', 'transfer-encoding', 'connection', 'server', 'date'}:
                    self.send_header(key, value)
            self.send_header('Content-Length', str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            log('delivered', gate=gate, path=self.path, status=status, bytes=len(body))
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError) as error:
            log('client-disconnected', path=self.path, error=type(error).__name__)
        except Exception as error:
            log('error', path=self.path, error=repr(error))
            self.send_error(502)

server = ThreadingHTTPServer(('127.0.0.1', 8884), Handler)
log('listening', host='127.0.0.1', port=8884, upstream='127.0.0.1:8883')
server.serve_forever()
