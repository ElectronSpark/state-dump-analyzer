# Drag and filter follow-up

Scope: S232, S238, S244, S246, S254, S256, S264, S266, C029.

The new `frontend/tests/audit_drag_filter_followup.test.mjs` executes production functions extracted from `frontend/assets/app.js`, including event bindings registered by the production resource and dashboard renderers. It also extracts the actual resource-search input registration, preserving its debounce. Synthetic DOM elements and deferred transport responses make event delivery and request ordering deterministic. This is controlled handler evidence, not native browser input evidence.

`node --test frontend/tests/audit_drag_filter_followup.test.mjs` passed 10/10 tests. `test-output.txt` preserves the final run and `run.json` records the production/test hashes. An initial test-harness run lacked the `resourceLabel` presentation dependency; that harness error was repaired before the recorded final run. No product failure was found or fixed.

## Pending resource requests — S232 and S238

Four tests deliver the real resource-search input event, execute its scheduled request, then click the currently rendered replacement kind while the first response remains unresolved. Both original query pairs are covered: NEIGHBOR / `peer-00000` → VIRTUAL_INTERFACE and IP_ROUTING / `blue` → MPLS_BINDING.

Each pair runs with the stale response arriving before and after the current response. The transport intentionally resolves an aborted request, proving the request-id guard rather than relying only on cancellation. Tests verify current query ownership, requested kind/search/offset, pending status, returned time, rendered current-kind columns and rows, then clear and return to the original kind through actual handlers. All pass.

This resolves the stale-response question under controlled timing. It does not claim the natural browser replay produced the same overlap or measure latency.

## Dashboard HTML drag — S244, S254 and S264

Each of the three registered module identities receives production dragstart, dragover, drop and dragend events. Repeated lower-half and upper-half drops reorder exactly once, maintain index/module ordering, clear dragging/drop classes, and allow subsequent keyboard Move up/down recovery. All three tests pass.

Required native gesture: press and drag the `span[data-dashboard-drag]` (with `draggable=true`), cross into a *different* `article.plugin-dashboard-module`, then release in that article's upper half for insertion before or lower half for insertion after. `dragstart` must establish the dragged identity; `dragover` must set `drop-before` or `drop-after`; a generic pointer release alone does not invoke those handlers. The drag handle is intentionally `aria-hidden`, so use its visible geometry rather than an accessibility role. Drop styling should be visible before release if HTML drag delivery is occurring.

Native drag delivery remains for the root agent's live browser replay. These tests do not upgrade the original real-pointer-drag assertion to a browser pass.

## No-match kind availability and dashboard population — S246, S256, S266, C029

The original 'enter a no-match search, then choose another flat kind before clearing' is unreachable in the settled UI. Backend `normalized_data.py` increments `counts_by_kind` only after the search predicate succeeds. The frontend derives kind tabs from those matching counts and explicitly retains the current selected flat kind. A zero-match result therefore exposes only that selected flat kind. This behavior is not evidence of broken recovery.

Three tests seed *nonempty* independent authoritative dashboard results (100/101/102), precomputed archive count 1,250,005, and one-row tables explicitly labelled as truncated out of 100/101/102. Actual no-match resource input/query rendering preserves all those dashboard values and scopes. Actual module close/reopen triggers dashboard-only queries (time and dashboard IDs; no resource search) and restores identical results. Clearing the filter makes another kind available, and its actual tab handler remains usable without altering dashboard population. All pass.

These tests repair the prior zero-population evidence gap at handler level. Root browser verification should choose a nonzero point-in-time baseline, and should record the alternative reachable order: clear the no-match filter, then choose another flat kind. The literal original sequence remains an invalid test precondition rather than a pass.

Documentation drift check: only tests and audit evidence changed; no plug-in API or author-visible product behavior changed. No maintained authoring-document update is required.
