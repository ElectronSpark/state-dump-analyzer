# Controlled request-race verification

Date: 2026-10-22. Prior audit cases: S273, S279, S285, S291, S297,
C010, C011, C012, C030. No product code changed.

Evidence level: deterministic Node VM/function harness using declarations and
event-registration blocks from `frontend/assets/app.js`, real request-abort
helpers, real timeline window math, real route rendering, and real resource-table
rendering. This is complementary controller evidence, not an automated browser
run or a claim that the original browser races were exercised.

Command:

```
node --test frontend/tests/audit_request_races_followup.test.mjs
```

Result: 15 tests, 15 passed, zero failed/cancelled/skipped. TAP saved in
`tests.tap`. Test file SHA-256:
`35d789cac16c07664c9d09d4c31ccbd8617fb87697f81454744da91c02a7ec56`.

## Verified assertions

- S273/S279/S285/S291/S297: the production route select-change and form-submit
  handlers create three genuinely overlapping requests. The latest request
  finishes first; both obsolete requests finish later. Obsolete success and
  obsolete error variants retain the latest route label, destination, next hop,
  egress, returned time, and basis. Busy state settles, abort-controller ownership
  clears, and a subsequent ordinary submit produces its own fresh result. Each
  audited route label has both completion variants. The harness deliberately
  ignores transport abort delivery, so successful late arrivals still exercise
  the production ownership checks.
- C010: a log-to-timeline action controller requests A in a different window.
  While its response is deferred, the installed Back click handler restores the
  recorded prior window (200..300). Late A cannot normalize data or run selection
  or focus. A subsequent explicit reveal normalizes its response, selects A,
  sets its cursor time, and calls scrolling/focus with A's exact target.
- C011: the installed Fit click handler supersedes deferred A and sets the exact
  0..1000 capture window. B is then requested and finishes first. Late A cannot
  replace B's payload, selected UID/resource, cursor, or target scroll/focus calls.
- C012: A's resource is genuinely absent while its allocation response is
  deferred. The production lane-checkbox click handler hides it and starts a
  query with no resource IDs. The newer result finishes first; stale allocation
  cannot restore the hidden lane. An explicit later reveal restores exactly one
  A lane and targets A, with its hidden-resource flag cleared.
- C030: production search-input debounce, rendered kind-button click, and
  dashboard-resource click execute while earlier resource queries are deferred.
  Query kinds are original/alternate/original, all retain the requested search.
  Completing the latest request first then the two obsolete requests preserves
  exact selected resource/kind, selected dashboard row, resource table row,
  column descriptor, cell value, settled pending flag, and released controller.
  This runs in both ETG-to-NEIGHBOR and NEIGHBOR-to-ETG directions.

## Limits and harness corrections

- Synthetic request/response fixtures exercise generic frontend ownership. The
  five route labels map the audit contexts but this does not revalidate each
  demo plug-in's forwarding algorithm, actual route ID, or backend response.
- DOM elements, timers, transport, timeline normalization/painting, and final
  selection/geometry side effects are controlled boundaries. Actual native
  event delivery, popup visibility, and final target rectangles require browser
  evidence. Timeline tests invoke the same reveal action controller used by the
  log; they do not claim to reproduce native Ctrl+Enter delivery.
- C030 validates final resource table/schema and dashboard selection, not a
  separately rendered graph inspector or every asynchronous dashboard query.
- Initial route test failures were fixture mistakes: `egress` is not an accepted
  branch response field. The fixture was corrected to the production field
  `egress_interface_resource_id`; no product logic changed. The advertised basis
  fixture is `observed_capture_vector`.

Documentation drift check: this change adds only tests, with no author-visible
plug-in behavior/API/commands changed. No maintained author document update is
required. The validation skill and API map were read. Inventory command
`C:/Users/82046/anaconda3/envs/router-dump-analyzer-demo/python.exe scripts/check_plugin_conformance.py --list`
passed; this is declaration inventory, not full conformance. `git diff --check`
passed. Full frontend check is left to the root agent after all parallel test
additions are ready, to avoid duplicate suite runs.
