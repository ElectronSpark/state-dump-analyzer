"""Select small reproducible measurement evidence, excluding caches and fixtures."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).parent
ROOT = HERE.parents[2]
selected = {}


def add(path, category):
    if path.is_file():
        selected[path.resolve()] = category


for path in HERE.iterdir():
    if path.name not in {"evidence-files.json", "evidence-files.txt"}:
        add(path, "current_scripts_reports_logs")
for dirname, category in (("after-1m-sqlite-quiet", "valid_1m_complete"), ("after-1m-quiet", "excluded_long_path_1m_complete")):
    for path in (HERE / dirname).iterdir():
        add(path, category)
for dirname in ("cursor-components", "followed-topology"):
    directory = HERE / dirname
    for path in directory.iterdir():
        add(path, dirname + "_results_profiles")
    for path in (directory / "responses").glob("*.json.gz"):
        add(path, dirname + "_full_responses")
legacy = ROOT / ".runtime/history-correlation-repairs-v2-2026-10-23"
for name in ("measure.py", "compare_results.py", "profile_cursor_components.py"):
    add(legacy / name, "reused_unmodified_legacy_harness")
baseline = ROOT / ".runtime/history-correlation-repairs-v4-2026-10-23"
add(baseline / "after-1m-quiet/result.json", "historical_1m_baseline")
for name in ("all-results.json", "summary.json", "resources_active-profile.txt", "dashboards-profile.txt", "focused_graph-profile.txt"):
    add(baseline / "cursor-components" / name, "historical_cursor_baseline")

rows = [{"path": path.relative_to(ROOT).as_posix(), "category": category,
         "bytes": path.stat().st_size, "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
        for path, category in sorted(selected.items(), key=lambda item: str(item[0]))]
result = {"repository_root": str(ROOT), "file_count": len(rows), "total_bytes": sum(row["bytes"] for row in rows),
          "exclude": ["unpacked fixtures", "search SQLite sidecars", "measurement-temp", "cursor-temp", "topology-temp", ".runtime/h5perf-t"],
          "archive_layout": "Preserve repository-relative paths if reproducing wrapper commands; source checkout and original fixture are required and recorded by hash.",
          "files": rows}
(HERE / "evidence-files.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
(HERE / "evidence-files.txt").write_text("\n".join(row["path"] for row in rows) + "\n", encoding="utf-8")
print(json.dumps({key: value for key, value in result.items() if key != "files"}, indent=2))
