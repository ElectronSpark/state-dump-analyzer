$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath ([IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..\..')))
$taskTemp = Join-Path (Get-Location).Path '.runtime/h5perf-t/topology'
New-Item -ItemType Directory -Force -Path $taskTemp | Out-Null
$env:TEMP = $taskTemp
$env:TMP = $taskTemp
$env:PYTHONHASHSEED = '0'
$env:PYTHONUTF8 = '1'
$env:PYTHONIOENCODING = 'utf-8'
& 'C:/Users/82046/anaconda3/envs/router-dump-analyzer-demo/python.exe' -B -X utf8 (Join-Path $PSScriptRoot 'profile_followed_topology.py')
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

