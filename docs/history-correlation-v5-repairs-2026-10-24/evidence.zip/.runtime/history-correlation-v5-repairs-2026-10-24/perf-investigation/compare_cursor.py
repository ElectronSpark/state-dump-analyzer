"""Compare all ordered current cursor outputs to the preceding complete run."""
import json
from pathlib import Path

HERE = Path(__file__).parent
ROOT = HERE.parents[2]
BASE = ROOT / ".runtime/history-correlation-repairs-v4-2026-10-23/cursor-components/all-results.json"
AFTER = HERE / "cursor-components/all-results.json"
before = json.loads(BASE.read_text(encoding="utf-8"))
after = json.loads(AFTER.read_text(encoding="utf-8"))
summary = json.loads((HERE / "cursor-components/summary.json").read_text(encoding="utf-8"))
assert summary["timed_component_occurrences"] == 128
assert summary["exact_repeat_pairs"] == summary["exact_repeat_matches"] == 64
assert summary["cross_round_pairs"] == summary["cross_round_matches"] == 64
assert all(summary["profile_output_matches"].values())


def ordered_rows(data):
    return [(tuple(row.get(key) for key in ("name", "round", "audit_move", "offset_ns", "occurrence", "profile_only")), row["sha256"])
            for row in data["records"] if "sha256" in row]


old_rows, new_rows = ordered_rows(before), ordered_rows(after)
assert len(old_rows) == len(new_rows)
assert [key for key, _ in old_rows] == [key for key, _ in new_rows]
metadata_fields = ("fixture_bytes", "fixture_sha256", "python", "python_version", "pythonhashseed", "stage", "rounds",
                   "native_origin_ns", "controls", "revision_id", "resources", "events", "dashboard_ids")
comparison = {
    "method": "One current isolated sequential run versus a historical run; timing differences are descriptive, not causal A/B evidence. Every response occurrence is retained in order.",
    "baseline": str(BASE), "after": str(AFTER),
    "ordered_digest_occurrences": len(new_rows), "all_ordered_response_digests_equal": old_rows == new_rows,
    "different_response_occurrences": [{"occurrence_index": i, "key": key, "baseline_sha256": digest, "after_sha256": new_rows[i][1]}
        for i, (key, digest) in enumerate(old_rows) if digest != new_rows[i][1]],
    "metadata_equal": {field: before["metadata"].get(field) == after["metadata"].get(field) for field in metadata_fields},
    "source_hashes_equal": {name: digest == after["metadata"]["source_sha256"].get(name)
        for name, digest in before["metadata"]["source_sha256"].items()},
    "timings": {name: {occurrence: {"baseline": old_values, "after": after["metadata"]["summary"][name][occurrence],
        "delta_wall_median": after["metadata"]["summary"][name][occurrence]["wall_median"] - old_values["wall_median"],
        "delta_cpu_median": after["metadata"]["summary"][name][occurrence]["cpu_median"] - old_values["cpu_median"]}
        for occurrence, old_values in by_occurrence.items()} for name, by_occurrence in before["metadata"]["summary"].items()},
}
(HERE / "cursor-comparison.json").write_text(json.dumps(comparison, indent=2), encoding="utf-8")
print(json.dumps({key: value for key, value in comparison.items() if key != "timings"}, indent=2))
