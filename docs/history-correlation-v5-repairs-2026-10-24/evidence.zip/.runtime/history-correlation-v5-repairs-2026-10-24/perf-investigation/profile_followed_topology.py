"""Separate current-UI followed-topology component measurement; no HTTP calls."""
from __future__ import annotations

import cProfile
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import platform
import pstats
import statistics
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).parent / "followed-topology"
HARNESS = ROOT / ".runtime/history-correlation-repairs-v2-2026-10-23/profile_cursor_components.py"
spec = importlib.util.spec_from_file_location("cursor_measure_helpers", HARNESS)
helpers = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helpers)


def main():
    if (OUT / "results.json").exists():
        raise RuntimeError("Retain the existing result; choose a new output location")
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "responses").mkdir(exist_ok=True)
    fixture = ROOT / "demo/fixtures/router-state-lab-history-correlation-2026-10-23.tgz"
    sys.path[:0] = [str(ROOT / "src"), str(ROOT / "demo"), str(ROOT / "state-dump-generator/src")]
    os.environ["ROUTER_DUMP_SEARCH_CACHE_DIR"] = str(ROOT / ".runtime/h5perf-t/topology-search")
    from rsl_demo_plugin.session import runtime
    from router_dump_analyzer.normalized_data import NormalizedDataService

    metadata = {
        "method": "Direct request-owned provider factory plus production TemporalTopologyService.query; sequential and isolated. Excludes HTTP scheduling, browser work, serialization and digesting. Profiles are separate occurrences. Memory values are query-boundary snapshots, not lifetime peaks.",
        "fixture": str(fixture), "fixture_bytes": fixture.stat().st_size,
        "fixture_sha256": helpers.file_digest(fixture), "python": sys.executable,
        "python_version": platform.python_version(), "pythonhashseed": os.environ.get("PYTHONHASHSEED", "random"),
        "search_cache_dir": os.environ["ROUTER_DUMP_SEARCH_CACHE_DIR"],
        "source_sha256": {name: helpers.file_digest(ROOT / name) for name in (
            "src/router_dump_analyzer/temporal_topology.py", "src/router_dump_analyzer/normalized_data.py",
            "src/router_dump_analyzer/temporal_core.py", "demo/rsl_demo_plugin/session.py",
            "demo/rsl_demo_plugin/temporal_contract.py", "demo/rsl_demo_plugin/scale_data.py", "frontend/assets/app.js",
        )},
        "ui_semantics": "Current follow cursor copies native cursor number into the absolute UTC field; reproduce that request literally, with no extra clock conversion. Full timeline view assumed; preceding 120-second history window. PE-A timings match the controlled cursor workload, not the audit's exact PE-D workflow.",
        "warmth": "Fresh process and loaded PE-A; first topology call measured separately. Subsequent timestamp cases retain existing lazy histories. Every request creates its own temporal service as the API does. No product caches are cleared or extended.",
    }
    records = []

    def flush():
        (OUT / "results.json").write_text(json.dumps({"metadata": metadata, "records": records}, indent=2), encoding="utf-8")

    def response_digest(value):
        encoded = json.dumps(value, sort_keys=True, ensure_ascii=True, separators=(",", ":")).encode("utf-8")
        digest = hashlib.sha256(encoded).hexdigest()
        target = OUT / "responses" / f"{digest}.json.gz"
        if not target.exists():
            target.write_bytes(gzip.compress(encoded, mtime=0))
        return digest, len(encoded)

    def measure(name, operation, response=False, **facts):
        before = helpers.memory()
        start, cpu = time.perf_counter(), time.process_time()
        value = operation()
        elapsed, cpu_seconds = time.perf_counter() - start, time.process_time() - cpu
        row = {"ordinal": len(records), "name": name, "seconds": elapsed, "cpu_seconds": cpu_seconds,
               "memory_before": before, "memory_after": helpers.memory(), **facts}
        if response:
            row["sha256"], row["json_bytes"] = response_digest(value)
            row["counts"] = value["counts"]
            row["node_times"] = value["node_times"]
            row["returned"] = {key: len(value[key]) for key in ("resources", "relationships", "inferred_connectivity", "changes")}
        records.append(row)
        flush()
        print(json.dumps(row), flush=True)
        return value, row

    with runtime.open(fixture) as session:
        svc = NormalizedDataService(session.data_source, session.data_policy)
        revisions, _ = measure("archive_preparation", lambda: session.revision_store.assembly.revisions)
        revision = next(item for item in revisions if "/node-a/" in item.revision_id)
        dataset, _ = measure("node_a_load", lambda: svc.load_dataset(revision.revision_id))
        index = svc.history_runtime(dataset)
        metadata.update(revision_id=revision.revision_id, resources=len(index.resources), events=len(index.events))
        timeline_start = int(dataset["demo"]["timeline_start_ns"])

        def request(offset):
            instant = helpers.ORIGIN_NS + offset
            return {
                "projection_id": "plugin.resource-association", "status_perspective_id": "data-bridge-layer",
                "node_ids": ["node-a"], "member_id": "member:node-a",
                "basis": {"kind": "absolute_time", "clock_domain": "utc", "time_ns": str(instant), "clock_policy": "best_effort"},
                "clock_policy": "best_effort", "include": ["resources", "relationships", "inferred_connectivity", "changes"],
                "limit": 80, "resource_limit": 80, "connectivity_limit": 80,
                "change_start_ns": str(max(timeline_start, instant - 120_000_000_000)), "change_limit": 100,
            }

        def execute(body):
            with svc.revision_scope(revision.revision_id):
                return session.temporal_provider.for_revision(revision.revision_id, svc).query(body)

        lazy_body = request(600_800_000_000)
        measure("first_followed_topology", lambda: execute(lazy_body), response=True, request=lazy_body)
        for round_number in range(2):
            cases = helpers.CASES if round_number == 0 else tuple(reversed(helpers.CASES))
            for case_id, offset, _ in cases:
                body = request(offset)
                first_sha = None
                for occurrence in ("first", "exact_repeat"):
                    _, row = measure("followed_topology", lambda: execute(body), response=True,
                        round=round_number, case_id=case_id, offset_ns=offset, occurrence=occurrence, request=body)
                    if first_sha is None:
                        first_sha = row["sha256"]
                    else:
                        row["repeat_matches"] = row["sha256"] == first_sha
                        assert row["repeat_matches"], "Exact-repeat output changed"
                    flush()

        body = request(600_750_000_000)
        profile = cProfile.Profile()
        profile.enable()
        value = execute(body)
        profile.disable()
        profile.dump_stats(str(OUT / "followed_topology.pstats"))
        with (OUT / "followed_topology-profile.txt").open("w", encoding="utf-8") as stream:
            pstats.Stats(profile, stream=stream).sort_stats("cumulative").print_stats(100)
        digest, json_bytes = response_digest(value)
        records.append({"ordinal": len(records), "name": "followed_topology", "profile_only": True,
            "request": body, "offset_ns": 600_750_000_000, "sha256": digest, "json_bytes": json_bytes})
        flush()

    timed = [row for row in records if "round" in row]
    cross_round = [row["sha256"] == next(other["sha256"] for other in timed
        if other["round"] == 1 and (other["case_id"], other["occurrence"]) == (row["case_id"], row["occurrence"]))
        for row in timed if row["round"] == 0]
    assert all(cross_round), "Cross-round output changed"
    profile_matches = any(row["sha256"] == digest and row["offset_ns"] == 600_750_000_000 for row in timed)
    assert profile_matches, "Profile output differs from uninstrumented query"
    verification = []
    for digest in sorted({row["sha256"] for row in records if "sha256" in row}):
        encoded = gzip.decompress((OUT / "responses" / f"{digest}.json.gz").read_bytes())
        assert hashlib.sha256(encoded).hexdigest() == digest
        json.loads(encoded)
        verification.append({"sha256": digest, "uncompressed_bytes": len(encoded), "verified": True})
    summary = {
        "timed_occurrences": len(timed), "exact_repeat_pairs": sum(row.get("repeat_matches", False) for row in timed),
        "cross_round_pairs": len(cross_round), "cross_round_matches": sum(cross_round), "profile_output_matches": profile_matches,
        "full_response_archives_verified": len(verification),
        "timings": {occurrence: {"count": len(rows), "wall_median": statistics.median(row["seconds"] for row in rows),
            "cpu_median": statistics.median(row["cpu_seconds"] for row in rows), "wall_min": min(row["seconds"] for row in rows),
            "wall_max": max(row["seconds"] for row in rows)}
            for occurrence in ("first", "exact_repeat") if (rows := [row for row in timed if row["occurrence"] == occurrence])},
        "largest_boundary_rss_gib": max(row[field]["rss"] for row in records for field in ("memory_before", "memory_after") if field in row) / 2**30,
        "largest_boundary_private_gib": max(row[field]["private"] for row in records for field in ("memory_before", "memory_after") if field in row) / 2**30,
    }
    (OUT / "response-verification.json").write_text(json.dumps(verification, indent=2), encoding="utf-8")
    (OUT / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2), flush=True)


if __name__ == "__main__":
    main()
