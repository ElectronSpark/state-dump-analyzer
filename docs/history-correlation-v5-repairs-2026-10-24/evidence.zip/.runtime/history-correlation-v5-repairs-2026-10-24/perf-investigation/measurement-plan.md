# Round-five repair: cursor investigation and measurement plan

Prepared 2026-10-24. Product code is unchanged by this investigation. Do not run either workload while the browser audit, frontend suite, demo requests, or another benchmark is active. The root agent coordinates the quiet interval.

## Verified fixture and runtime

- Python: `C:/Users/82046/anaconda3/envs/router-dump-analyzer-demo/python.exe`, CPython 3.12.13, conda-forge. `fastapi` and `uvicorn` resolve inside this environment; `router_dump_analyzer` and `rsl_demo_plugin` resolve to this checkout.
- Fixture: `demo/fixtures/router-state-lab-history-correlation-2026-10-23.tgz`, 286,504,605 bytes, SHA256 `5f204e5836be8966f148ae14671f9488007970619cff094cc9bda60c71892105` (rehash during preparation).
- PE-A has 1,250,005 events and 7,510 resources in the retained prior run; the new harness verifies its current loaded counts.

## Exact runs

From the repository root, sequentially in separate PowerShell invocations:

```powershell
powershell -NoProfile -File .runtime/history-correlation-v5-repairs-2026-10-24/perf-investigation/run-1m.ps1
powershell -NoProfile -File .runtime/history-correlation-v5-repairs-2026-10-24/perf-investigation/run-cursor.ps1
powershell -NoProfile -File .runtime/history-correlation-v5-repairs-2026-10-24/perf-investigation/run-topology.ps1
```

The wrappers call the existing v2 benchmark and component profiler unchanged. Both refuse to overwrite a completed result. The 1M run explicitly uses `PYTHONHASHSEED=random`, matching the latest recorded baseline; the cursor profile uses fixed seed 0, matching its separate baseline. Fresh processes and separate task-local search-cache/temp locations are used; OS file caches are not flushed. After the path diagnostic below, temp/cache roots use the short `.runtime/h5perf-t` tree. The comparable 1M output is `after-1m-sqlite-quiet/result.json`, compared in `comparison-sqlite.json`. The 1M harness samples the child every 100ms and records process lifetime counters. The cursor harness records query-boundary snapshots only. Neither measures browser/GPU memory.

The 1M comparison baseline is `.runtime/history-correlation-repairs-v4-2026-10-23/after-1m-quiet/result.json`: loaded RSS 2.175423 GiB, lifetime peak RSS 2.254967 GiB, lifetime peak private commit 2.248951 GiB, measured-phase CPU 187.546875s, elapsed 196.750s, and sidecar 75,038,720 bytes. The full comparator preserves every repeated phase occurrence and checks 52 ordered phase results, 35 page digests, and five ordered invariant groups. Historical timing comparisons are descriptive, not controlled causal A/B evidence.

The cursor comparison baseline is `.runtime/history-correlation-repairs-v4-2026-10-23/cursor-components/all-results.json`. The fresh run repeats eight native cursor offsets with 500-row DTE pages, empty and active search, a focused correlation graph, and both default-open live dashboards. It has 128 uninstrumented query occurrences in two reversed query-order rounds. cProfile runs occur separately. Exact-repeat, cross-round and instrumented/uninstrumented full-response equality are verified; every compressed response is rehashed and parsed. Fresh timestamp cases clear only the existing timestamp search-document cache, preserving warm temporal histories. This measures at most one observed cache snapshot, not LRU eviction.

The separately added followed-topology stage uses the same PE-A timestamps in two rounds (second reverses timestamp order), 32 uninstrumented queries plus a separately recorded first lazy query and cProfile query. It creates the production request-owned temporal service for every call. Its request matches current frontend defaults: `plugin.resource-association`, `data-bridge-layer`, `node-a`, absolute UTC field containing the native cursor number exactly as the current follow UI sends it, `best_effort`, resource/connectivity limits 80, change limit 100, and a preceding 120-second history window with all four includes. The actual requests and resolved node times are recorded, with complete output digests and verified response archives. It uses a fresh process and separate cache location, retains existing lazy histories between calls, and makes no product cache changes. This adds an isolated measurement of the previously unmeasured component; it is not an exact replay of PE-D's audit, an HTTP/UI latency measurement, or a reason to sum component medians into refresh latency.

## Existing evidence and source-level causes

### Excluded initial run: diagnosed Windows SQLite path limit

The first completed run (`after-1m-quiet/result.json`, `comparison.json`, `1m-run.log`) is retained but excluded from comparable measurements: the nested evidence directory caused SQLite sidecar construction to fall back to `memory-scan`, with a zero-byte sidecar. It completed all 52 phases and preserved all 35 page hashes, but cache-mode invariants differed and process RSS rose to approximately 3.97 GiB. This is a setup deviation, not a valid regression comparison with the preceding SQLite run.

The tiny controlled `probe_sidecar_path.py` reproduces the exact failure using the production private build method and one synthetic document. The normal 228-character target generates a 272-character SQLite temporary filename; `sqlite3.connect` raises `OperationalError: unable to open database file`, wrapped as `_SidecarUnavailable`. A short filename in the same directory (223-character temporary path) succeeds, as does the original-length filename under a shorter task-local root (178-character temporary path). `sidecar-path-probe.json` records each path, exception chain and successful build. The parent authorized a shorter `.runtime/h5perf-t` temp/cache tree, and the original child exited before the fresh rerun. The comparable run verified `sqlite-zlib-blocks-v1`, 75,038,720-byte sidecar, and all cache invariants. No product code was altered to force or conceal the backend.

The latest live browser audit establishes substantial composed cursor work (roughly 6–9.5 process CPU seconds across selected cursor workflows), but its 14–25 second observation gaps are not request completion timings. The source schedules resources, dashboards, the correlation graph, and followed topology separately. A failure-event jump can additionally refresh a lane and event detail. The prior component run did not include followed topology, HTTP queues, serialization, or UI rendering, so its component timings cannot explain the full composed latency by subtraction.

The prior isolated search median was 1.622s wall / 1.586s CPU at a fresh searched timestamp versus 3.1ms wall for an exact repeat. Empty-search page reconstruction was about 97ms wall / 94ms CPU; ordinary focused graph queries about 27ms wall / 31ms CPU. Default-open live dashboards were 1.215s wall / 1.156s CPU and repeat on every call. The first lazy searched cursor cost 7.096s wall / 6.828s CPU and increased RSS by approximately 600MiB; allocation ownership was not profiled.

Source and separate cProfile evidence explain these costs:

- `resources_at` projects client-safe search documents across all 7,510 resources before kind/page filtering. Global matching counts and disclosure semantics require preserving this behavior; a visible page of 500 does not bound the work. `resource_search_text` repeatedly traverses declared fields and applies publication policy. The prior instrumented search made 1,252,040 interval checks and 16.7 million calls.
- `dashboard_query` independently reconstructs 7,125 relevant resource states and redacts them. The prior instrumented case made 1,250,200 interval checks; its actual dashboard aggregation took only 44ms of the 3.485s instrumented total.
- `_active_intervals` linearly filters each resource's histories; `_active_state_interval` also handles overlapping perspective-qualified and malformed state intervals. Generic binary search must not replace those semantics without proving a sorted/disjoint representation.
- High-fanout focused graphs can reach 500 nodes and make about 504,120 relationship-presence checks; ordinary small graphs are much cheaper.
- The existing two-timestamp search cache builds under an RLock. Duplicate/concurrent wait costs have not been profiled. No permanent stall, memory leak, or cancellation failure follows from this evidence.

## Smallest candidate and why no incidental product change is proposed

`dashboard_query` already has its dataset and runtime, but calls public `resource_state_at` for each selected row, repeating dataset and descriptor lookup. Reusing that existing request context and calling the existing state-view/redaction helpers would avoid approximately 0.160s cumulative dataset lookup and 0.079s descriptor lookup in the prior 3.485s instrumented call. These nested times are not additive and are not a measured uninstrumented speedup. This is likely a small gain, not a fix for multi-second composed updates, and is left unchanged pending fresh evidence.

Material future candidates are a proven ordered/disjoint interval lookup for the scale runtime and reusable disclosure projection plans. Both require preservation of historical boundaries, perspective ambiguity, nested fields, source redaction, and memory bounds; neither is introduced as an unmeasured incidental change to the three functional fixes. The current task first reruns the direct service profiles on the corrected code and reports the remaining cost honestly.

Documentation drift check for this subtask: only ignored runtime diagnostics and evidence are created. No public plug-in or author-facing behavior changes.
