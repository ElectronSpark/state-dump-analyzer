$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath ([IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..\..')))
$taskOutput = Join-Path $PSScriptRoot 'after-1m-sqlite-quiet'
if (Test-Path -LiteralPath (Join-Path $taskOutput 'result.json')) { throw 'Measurement result already exists; retain it and choose a new output directory.' }
$taskTemp = Join-Path (Get-Location).Path '.runtime/h5perf-t/1m'
New-Item -ItemType Directory -Force -Path $taskTemp | Out-Null
$env:TEMP = $taskTemp
$env:TMP = $taskTemp
$env:PYTHONHASHSEED = 'random'
$env:PYTHONUTF8 = '1'
$env:PYTHONIOENCODING = 'utf-8'
& 'C:/Users/82046/anaconda3/envs/router-dump-analyzer-demo/python.exe' -B -X utf8 '.runtime/history-correlation-repairs-v2-2026-10-23/measure.py' --archive 'demo/fixtures/router-state-lab-history-correlation-2026-10-23.tgz' --output $taskOutput --dense-term success --repeats 5
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
& 'C:/Users/82046/anaconda3/envs/router-dump-analyzer-demo/python.exe' -B -X utf8 '.runtime/history-correlation-repairs-v2-2026-10-23/compare_results.py' --baseline '.runtime/history-correlation-repairs-v4-2026-10-23/after-1m-quiet/result.json' --after (Join-Path $taskOutput 'result.json') --output (Join-Path $PSScriptRoot 'comparison-sqlite.json')
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

