"""Explain the excluded long-path fallback with tiny controlled SQLite writes."""
import json
from pathlib import Path
import sqlite3
import sys

HERE = Path(__file__).parent
ROOT = HERE.parents[2]
sys.path.insert(0, str(ROOT / "src"))
from router_dump_analyzer.history_search_core import HistorySearchCorpus

result = json.loads((HERE / "after-1m-quiet/result.json").read_text(encoding="utf-8"))
long_root = Path(result["search_cache"])
short_root = ROOT / ".runtime/h5perf-t/path-probe"
name = "000-node-a-" + "abcd" * 6 + ".history-search.sqlite3"
rows = []
original_connect = sqlite3.connect
for label, target in (
    ("same_long_root_same_length_basename", long_root / name),
    ("same_long_root_short_basename", long_root / "p.sqlite3"),
    ("short_root_same_length_basename", short_root / name),
):
    row = {"arm": label, "target": str(target), "target_characters": len(str(target))}
    target.parent.mkdir(parents=True, exist_ok=True)
    def traced_connect(database, *args, **kwargs):
        row.setdefault("connect_paths", []).append({"path": str(database), "characters": len(str(database))})
        return original_connect(database, *args, **kwargs)
    sqlite3.connect = traced_connect
    corpus = HistorySearchCorpus(sidecar_path=target, identity="task-local-path-probe", eager_validate_sidecar=False)
    try:
        row["build_result"] = corpus._build_sidecar(lambda: iter(["synthetic safe path probe"]))
        row["success"] = True
    except Exception as error:
        row.update(success=False, error_type=type(error).__name__, error=str(error),
            cause_type=type(error.__cause__).__name__ if error.__cause__ else None,
            cause=str(error.__cause__) if error.__cause__ else None)
    finally:
        sqlite3.connect = original_connect
        corpus.close()
    rows.append(row)
(HERE / "sidecar-path-probe.json").write_text(json.dumps(rows, indent=2), encoding="utf-8")
print(json.dumps(rows, indent=2))
