$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath ([IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..\..')))
$taskOutput = Join-Path $PSScriptRoot 'cursor-components'
if (Test-Path -LiteralPath (Join-Path $taskOutput 'all-results.json')) { throw 'Component result already exists; retain it and choose a new output directory.' }
$taskTemp = Join-Path (Get-Location).Path '.runtime/h5perf-t/cursor'
New-Item -ItemType Directory -Force -Path $taskTemp | Out-Null
$env:TEMP = $taskTemp
$env:TMP = $taskTemp
$env:PYTHONHASHSEED = '0'
$env:ROUTER_DUMP_SEARCH_CACHE_DIR = Join-Path (Get-Location).Path '.runtime/h5perf-t/cursor-search'
$env:PYTHONUTF8 = '1'
$env:PYTHONIOENCODING = 'utf-8'
& 'C:/Users/82046/anaconda3/envs/router-dump-analyzer-demo/python.exe' -B -X utf8 '.runtime/history-correlation-repairs-v2-2026-10-23/profile_cursor_components.py' --fixture 'demo/fixtures/router-state-lab-history-correlation-2026-10-23.tgz' --out $taskOutput --stage all --rounds 2
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
& 'C:/Users/82046/anaconda3/envs/router-dump-analyzer-demo/python.exe' -B -X utf8 (Join-Path $PSScriptRoot 'summarize_cursor_components.py')
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
& 'C:/Users/82046/anaconda3/envs/router-dump-analyzer-demo/python.exe' -B -X utf8 (Join-Path $PSScriptRoot 'compare_cursor.py')
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

