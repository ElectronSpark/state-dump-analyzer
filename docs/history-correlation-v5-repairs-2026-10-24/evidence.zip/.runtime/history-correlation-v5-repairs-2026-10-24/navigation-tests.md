# H5-1 / H5-2 navigation validation

Validated on 2026-10-24 from `C:\Users\82046\OneDrive\文档\state dump analyzer`.

## Root cause and repair

- **H5-1:** node startup used the requested fabric UTC timestamp directly as a native node cursor. The existing core projection selector and clock resolver now return `node_snapshot.resolved_time`; startup uses its `local_time_ns`. The original UTC request remains separate. Both generated and fallback links keep UTC as the absolute selector domain.
- **H5-2:** relative navigation retained the offset in the URL but initialized at capture time. The same resolver now applies the offset to the selected projection/perspective watermark. It does not substitute the dump capture for a declared projection watermark.
- The workspace accepts optional `revision_id` and rejects a stale revision with HTTP 409. Existing selector validation rejects foreign/unknown projections and invalid clocks. Untrusted or expired `context_id` and client-supplied local timestamps do not supply the cursor: the server resolves the original request afresh.
- Metadata resolution reuses `_select_node_projections` and `_resolve_time`; it does not run topology projections. Plain member workspaces with no explicit time basis do not require topology support. Missing mappings remain unresolved instead of treating UTC as native time.
- No plug-in hook, manifest, parser, or resource identity contract changed. The core HTTP response addition and optional revision selector are documented by the parent task.

## Focused frontend command

From the repository `frontend` directory:

```powershell
node --test tests/node_navigation_basis.test.mjs tests/node_startup_progressive.test.mjs
```

**Result:** 15 passed, 0 failed; 119.7284 ms reported by Node.

New regressions exercised:

1. Both node link paths preserve the requested UTC domain and exact time, including zero.
2. Both node link paths retain relative projection selection without adding an absolute time.
3. Workspace bootstrap forwards revision and original basis, never a client resolved time.
4. Navigation banner distinguishes resolved native time, unresolved requests, and ordinary capture.
5. Member startup uses resolved native time for UTC and relative selectors, including zero.
6. Unresolved member time cannot fall back to raw UTC as native time.

The other nine startup regressions passed unchanged, covering progressive loading, deferred selection, optional requests, late incident protection, cursor synchronization, and retry behavior.

## Focused Python command

Run from the repository root with the installed demo environment. This successful run used execution outside the sandbox to permit Starlette's local Windows loopback socket pair.

```powershell
$testTemp = Join-Path (Get-Location) '.runtime/h5-navigation-tests'
New-Item -ItemType Directory -Force -Path $testTemp | Out-Null
$env:TEMP = $testTemp
$env:TMP = $testTemp
& 'C:/Users/82046/anaconda3/envs/router-dump-analyzer-demo/python.exe' -m unittest -v `
  tests.test_multi_node_topology.MultiNodeTopologyTests.test_node_workspace_resolves_utc_through_member_clock_without_projection `
  tests.test_multi_node_topology.MultiNodeTopologyTests.test_node_workspace_rejects_stale_revision_and_foreign_projection `
  tests.test_multi_node_topology.MultiNodeTopologyTests.test_node_navigation_without_clock_preserves_unresolved_state `
  tests.test_multi_node_topology.MultiNodeTopologyTests.test_relative_node_deep_link_round_trips_without_absolute_time `
  tests.test_multi_node_topology.MultiNodeTopologyTests.test_absolute_node_deep_link_round_trips_without_relative_offset `
  tests.test_multi_node_topology.MultiNodeTopologyTests.test_declared_local_watermark_does_not_require_node_clock `
  tests.test_node_workspace_regressions.NodeWorkspaceRegressionTests.test_node_workspace_http_preserves_plugin_vocabulary_and_disclosure `
  tests.test_load_progress.AnalysisLoadProgressTests.test_node_workspace_cold_load_is_tracked_before_store_lookup `
  tests.test_demo_app.DemoAppTests.test_node_workspace_basis_selector_is_unambiguous
```

**Result:** 9 passed, 0 failed; 12.344 seconds.

Coverage includes unequal clocks on node-a/node-b/node-d, the audited PE-D boundary UTC `1759680179993000000`, relative projection watermarks without a usable absolute clock, unresolved/strict behavior, stale revisions, unknown members, invalid selectors, untrusted context/timestamp parameters, compatibility without topology support, and load tracking.

After strengthening the no-projection assertion from an instance patch to a class-level patch of `MultiNodeTopologyService.query`, reran:

```powershell
& 'C:/Users/82046/anaconda3/envs/router-dump-analyzer-demo/python.exe' -m unittest -v tests.test_multi_node_topology.MultiNodeTopologyTests.test_node_workspace_resolves_utc_through_member_clock_without_projection
```

**Result:** 1 passed, 0 failed; 8.554 seconds. The same workspace TEMP/TMP settings and loopback execution permission applied.

## Environment blocker and resolution

1. The first Python attempt could not create the fixture lock under the sandbox-managed temporary directory (`PermissionError`). Pointing TEMP/TMP at `.runtime/h5-navigation-tests` resolved that filesystem issue.
2. The next attempt stalled before test execution in `MultiNodeTopologyTests.setUpClass`, while entering `Starlette TestClient`. A 30-second `faulthandler.dump_traceback_later` showed the worker blocked in `socket.accept` via `_fallback_socketpair` and `asyncio.windows_events` while the main thread waited for `anyio.start_blocking_portal`.
3. Stopped the stalled attempts. Running the same tests with sandbox escalation for local loopback completed successfully. This was a test-environment block, not a navigation request or application deadlock.

`git diff --check` passed. Parent-reported broader checks: frontend suite **648 passed**; type-stub export checks **149 passed**. Browser validation and 1M measurements are recorded separately by the parent task.
