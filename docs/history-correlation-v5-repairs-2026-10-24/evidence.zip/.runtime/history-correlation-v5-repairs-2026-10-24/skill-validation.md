# H5 skill maintenance

Updated only existing paragraphs in the author skill, validation skill and API validation map:

- Preserve the original UTC/relative request separately from the validated member-local instant used by node startup. Validate event-boundary navigation, nonzero relative offsets against the selected projection watermark, and stale/unresolved context.
- Settle intentional focus reveal before clipping dismissal for route service strips as well as timeline targets. Exercise native Tab then immediate Enter/Space, distinguish first activation from second-press recovery, and preserve passive focus/pointer controls.
- Keep sampled CPU/coverage separate from action-to-follow-up observation gaps.

Validation used `C:/Users/82046/anaconda3/envs/router-dump-analyzer-demo/python.exe` with `-B -X utf8`:

1. `C:/Users/82046/.codex/skills/.system/skill-creator/scripts/quick_validate.py .agents/skills/router-plugin-author` — `Skill is valid!`
2. `C:/Users/82046/.codex/skills/.system/skill-creator/scripts/quick_validate.py .agents/skills/router-plugin-validate` — `Skill is valid!`
3. `scripts/check_plugin_conformance.py --list` — passed, all eight inventory groups listed. This is inventory validation, not behavioral conformance.
4. Scoped `git diff --check` — passed.

Final SHA-256:

| File | SHA-256 |
| --- | --- |
| `.agents/skills/router-plugin-author/SKILL.md` | `0f26914e2b715bd614a87d27c5c53672fb232bb127e60140fd7ca634cb51eaca` |
| `.agents/skills/router-plugin-validate/SKILL.md` | `b987e746631cc586d5ad91542efac483813619e19ec660f3d5a04ecc64bb9146` |
| `docs/plugin-api-validation.md` | `26a2825b7eeaa6846df8581779a1d5018b098575e260498cf733e75376685dcd` |

No product, fixture, normative contract, runnable example, browser, server, or benchmark changes were made by this subtask. No protected-file escalation was needed. Skill validation checks structure, not behavioral quality; the parent owns implementation regressions and browser validation.

Documentation drift check for this subtask: these are maintenance and validation instructions for existing core responsibilities, not a new plug-in hook, signature, capability or author command. No quickstart/example change is required by these edits. The parent must complete the overall drift check once the workspace API implementation is final.
