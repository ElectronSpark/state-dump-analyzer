# Route service-context keyboard validation

Scope: source and existing tests only. No browser, server, benchmarks, prior reports, runtime artifacts, other agents' outputs or parent check logs were read. Logs created by this trial were read only to establish its own results.

Skill SHA256: B987E746631CC586D5AD91542EFAC483813619E19EC660F3D5A04ECC64BB9146
API map SHA256: 26A2825B7EEAA6846DF8581779A1D5018B098575E260498CF733E75376685DCD

## Result

No reproducible product regression found within the permitted source/test evidence. Native keyboard interaction is not fully validated: the skill and map explicitly require native Tab followed by immediate Enter/Space while focus scrolling settles, and warn that synthetic rectangles alone do not establish that ordering. Browser use was prohibited for this trial, so that required evidence remains unavailable.

The production focus handler in frontend/assets/topology.js (bindRoutePresentationElements) synchronously reveals fully clipped service triggers, compensates sticky-header occlusion, then opens a passive preview. Its keydown handler handles Enter and Space, prevents native duplicate activation, pins the context and transfers focus to the close control. Explicit close restores trigger focus with preview suppression. Passive re-entry preserves pinned details and external focus. Route changes clear obsolete previews.

Existing frontend/tests/route_audit_regressions.test.mjs covers Enter/Space above/below the viewport and behind the sticky header, visible and partially visible controls, passive focus restoration, clipped/detached anchors, narrow placement, scroll preservation, resize-only redraw, and trace/direction replacement. These handlers execute against modeled DOM rectangles; the test named native focus reveal does not use actual native Tab or asynchronous browser focus scrolling. Passing it cannot establish the native first-activation requirement.

## Checks

- node --test frontend/tests/route_audit_regressions.test.mjs: 23 pass, 0 fail, 0 skip; route-tests.txt.
- Configured Python: C:/Users/82046/anaconda3/envs/router-dump-analyzer-demo/python.exe; router_dump_analyzer, rsl_demo_plugin, fastapi and httpx imports pass.
- Configured Python -B scripts/check_plugin_conformance.py --list: exit 0; inventory.txt. Inventory only; not a behavioral conformance claim.
- Initial system Python C:/Python312/python.exe lacked router_dump_analyzer; switched to the configured environment before inventory validation.

## Stewardship

Only trial findings/logs were written. No product or plug-in boundary behavior changed. Plug-in documentation drift check completed; no author-documentation update required.