from pathlib import Path
import hashlib
import json
import zipfile

root = Path(__file__).resolve().parents[2]
runtime = Path(__file__).resolve().parent
report = root / 'docs/history-correlation-v5-repairs-2026-10-24'
shortlist = json.loads((runtime / 'perf-investigation/evidence-files.json').read_text(encoding='utf-8-sig'))
files = set()
for item in shortlist['files']:
    path = root / item['path']
    data = path.read_bytes()
    assert len(data) == item['bytes']
    assert hashlib.sha256(data).hexdigest() == item['sha256'], path
    files.add(path)
for path in runtime.iterdir():
    if path.is_file() and path.suffix in {'.json', '.txt', '.md', '.png', '.patch', '.py', '.log'}:
        files.add(path)
for folder in ['browser', 'skill-popup-trial']:
    files.update(path for path in (runtime / folder).rglob('*') if path.is_file())
files.add(runtime / 'perf-investigation/evidence-files.json')
files.add(runtime / 'perf-investigation/evidence-files.txt')
files.add(root / 'frontend/tests/node_navigation_basis.test.mjs')
records = []
archive = report / 'evidence.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as bundle:
    for path in sorted(files):
        name = path.relative_to(root).as_posix()
        data = path.read_bytes()
        bundle.writestr(name, data)
        records.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
with zipfile.ZipFile(archive) as bundle:
    assert len(bundle.namelist()) == len(records)
    assert bundle.testzip() is None
    for record in records:
        data = bundle.read(record['path'])
        assert hashlib.sha256(data).hexdigest() == record['sha256']
manifest = {'archive': archive.name, 'bytes': archive.stat().st_size,
            'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
            'file_count': len(records), 'files': records}
(report / 'evidence-sha256.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
print(json.dumps({key: value for key, value in manifest.items() if key != 'files'}))
