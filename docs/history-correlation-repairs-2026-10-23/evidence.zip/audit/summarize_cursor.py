from pathlib import Path
import json, statistics

root = Path(__file__).parent
before = json.loads((root/'cursor-before.json').read_text())
after = json.loads((root/'cursor-after.json').read_text())
assert len(before) == len(after) == 42
assert all(a['name'] == b['name'] and a.get('sha256') == b.get('sha256') for a,b in zip(before,after))
report = {'equivalent_complete_response_count': 40,
          'preliminary_note': 'Generated-fixture suites may have overlapped. Use quiet paired run for final request timing. Initial first-search samples also include lazy interval construction.'}
for label, rows in [('before',before), ('after',after)]:
    fresh = [row for row in rows if row['name'].startswith('1:dte')][:4]
    report[label] = {'fresh_median_seconds': statistics.median(r['seconds'] for r in fresh),
                     'fresh_median_cpu_seconds': statistics.median(r['cpu_seconds'] for r in fresh),
                     'first_search_seconds': next(r['seconds'] for r in rows if r['name'] == '0:dte-000000:599999999999')}
paired_path = root/'cursor-paired.json'
if paired_path.exists():
    rows = json.loads(paired_path.read_text())[3:]
    assert len(rows) == 32
    pairs = {}
    for row in rows:
        key,label = row['name'].rsplit(':',1)
        pairs.setdefault(key,{})[label] = row
    assert all(value['before']['sha256'] == value['after']['sha256'] for value in pairs.values())
    report['paired'] = {'equivalent_complete_response_pairs': len(pairs)}
    for label in ('before','after'):
        report['paired'][label] = {}
        for term in ('dte-000000','empty'):
            selected = [r for r in rows if r['name'].endswith(':'+term+':'+label)]
            report['paired'][label][term] = {
                'count': len(selected), 'median_seconds': statistics.median(r['seconds'] for r in selected),
                'median_cpu_seconds': statistics.median(r['cpu_seconds'] for r in selected),
                'min_seconds': min(r['seconds'] for r in selected), 'max_seconds': max(r['seconds'] for r in selected),
                'rss_deltas': [r['rss_after']-r['rss_before'] for r in selected]}
(root/'cursor-comparison.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report,indent=2))
