"""Direct production resource query timings; profiling is a separate occurrence."""
from __future__ import annotations
import cProfile, gc, hashlib, json, os, pstats, sys, time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).parent
sys.path[:0] = [str(ROOT / 'src'), str(ROOT / 'demo'), str(ROOT / 'state-dump-generator/src')]
os.environ.setdefault('ROUTER_DUMP_SEARCH_CACHE_DIR', str(OUT / 'search-cache'))
from rsl_demo_plugin.session import runtime
from router_dump_analyzer.normalized_data import NormalizedDataService

label = sys.argv[1]
records = []
def measure(name, fn):
    start, cpu = time.perf_counter(), time.process_time()
    value = fn()
    row = dict(name=name, seconds=time.perf_counter()-start, cpu_seconds=time.process_time()-cpu)
    if isinstance(value, dict) and 'matched_count' in value:
        encoded = json.dumps(value, sort_keys=True, ensure_ascii=True).encode()
        row.update(count=value['matched_count'], returned=value['returned_count'], sha256=hashlib.sha256(encoded).hexdigest())
    records.append(row)
    (OUT / f'cursor-{label}.json').write_text(json.dumps(records, indent=2), encoding='utf-8')
    print(json.dumps(row), flush=True)
    return value

with runtime.open(ROOT / 'demo/fixtures/router-state-lab-algorithms-2026-10-02.tgz') as session:
    svc = NormalizedDataService(session.data_source, session.data_policy)
    revisions = measure('archive_preparation', lambda: session.revision_store.assembly.revisions)
    ds = measure('node_a_load', lambda: svc.load_dataset(revisions[0].revision_id))
    idx = svc.history_runtime(ds)
    print(json.dumps({'resources': len(idx.resources), 'events': len(idx.events)}), flush=True)
    origin = 1759679999996000000
    # Identical timestamp sequence and alternate order; snapshot clearing is only
    # an experimental control, not a modification to the query implementation.
    offsets = [599999999999, 600075000000, 600749999999, 600800000000]
    for attempt in range(2):
        for query in (('', 'dte-000000') if attempt == 0 else ('dte-000000', '')):
            idx.resource_search._documents.clear()
            for ns in offsets + offsets[-1:]:
                measure(f'{attempt}:{query or "empty"}:{ns}', lambda ns=ns, query=query: svc.resources_at(origin+ns, kinds={'DTE'}, search=query, limit=200))
    idx.resource_search._documents.clear()
    profile = cProfile.Profile()
    profile.enable()
    svc.resources_at(origin+offsets[2], kinds={'DTE'}, search='dte-000000', limit=200)
    profile.disable()
    profile.dump_stats(str(OUT / f'cursor-{label}.pstats'))
    with (OUT / f'cursor-{label}-profile.txt').open('w', encoding='utf-8') as output:
        pstats.Stats(profile, stream=output).sort_stats('cumulative').print_stats(55)
    # Complete safe outputs for result equivalence, beyond the narrow audit term.
    for name, args in [('dynamic', {'search':'fallback'}), ('status', {'search':'down'}), ('layer', {'search':'up', 'layers':{'data-bridge-layer'}}), ('page', {'search':'dte', 'kinds':{'DTE'}, 'limit':7, 'offset':13})]:
        for ns in (119999999999, 120000000000, 360037500000, 480037500000, 600750000000):
            measure(f'oracle:{name}:{ns}', lambda ns=ns, args=args: svc.resources_at(origin+ns, **args))
