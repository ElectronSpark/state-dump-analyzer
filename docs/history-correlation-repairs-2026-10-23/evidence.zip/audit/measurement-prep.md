# Final measurement preparation

Prepared 2026-10-23. No heavy measurement has been run by this preparation task.

## Exact harness and comparison baseline

The authoritative latest quiet baseline is
`.runtime/vpn-popup-repairs-2026-10-23/after-1m-quiet/result.json`, preserved as
`measurements/result.json` in `docs/vpn-popup-repairs-2026-10-23/evidence.zip`.
Do not accidentally use that report's older comparison baseline under
`.runtime/audit-repairs-2026-10-23/performance/after-1m` or its non-quiet first
VPN rerun under `after-1m`.

This prep directory contains byte-exact copies extracted from the evidence zip:

- `measure.py`: 18,298 bytes, SHA-256
  `05a586a092289fe65a10462bba61e79f988bc8588d121bad727df1eed752a92a`.
- `baseline-1m-quiet-result.json`: 71,163 bytes, SHA-256
  `3f545c619707fa5199fa3227d6d4e6395e0f54c3983c7cbdc58cbcedccacefbb`.

The live original `.runtime/audit-repairs-2026-10-23/performance/measure.py`
has the same hash. Keep the harness unchanged for a comparable 52-phase run.
It already creates a fresh process, a fresh search cache, and a dedicated
pycache. Its 100 ms Windows sampler records current and lifetime RSS/commit.
Guards stop at less than 6 GiB host-available RAM, more than 32 GiB child-private
memory, or 30 minutes. It measures the child Python workload, not the browser.

Baseline values:

| Metric | Latest quiet baseline |
| --- | ---: |
| Loaded RSS (end of `node_a_cold_load`) | 2.1756477356 GiB |
| Lifetime peak RSS | 2.2544136047 GiB |
| Lifetime peak private commit | 2.2495918274 GiB |
| Sum of all 52 phase CPU occurrences | 168.265625 s |
| Harness elapsed | 172.984 s |
| Sidecar size | 75,038,720 bytes |
| Full page SHA-256 values | 35 |

The fixture is `demo/fixtures/router-state-lab-algorithms-2026-10-02.tgz`,
286,496,584 bytes, SHA-256
`4cea20db78aa3fede9dc79a89a9277c5a9a72905fbff76a5f8436efd1c4aec30`.
It includes PE-A with 1,250,005 events and 7,510 resources. The harness loads
PE-A, searches/pages/density/locates, retires it, loads another full node, and
returns to PE-A for sidecar/shared-result validation and new-term search.

## Prerequisites and final command

1. Finish edits, regression tests, profiler trials, and browser interaction
   first. Keep browser and other workloads idle for this run; do not run tests
   concurrently. OS cache is not flushed, so report this as a historical
   comparison rather than evidence of speedup by itself.
2. Use the same interpreter:
   `C:/Users/82046/anaconda3/envs/router-dump-analyzer-demo/python.exe`.
   Its checked version is CPython 3.12.13, conda-forge, Windows AMD64. Editable
   core/demo/generator packages and FastAPI/Uvicorn resolve successfully.
3. The output directory must not already exist. Use a fresh name on any retry,
   and preserve failed attempts and their reasons. A denied local filesystem
   path/process capability is an environment limitation, not a product failure.
4. Set `RSL_MEASURE_SOURCE_ROOT` explicitly: this is essential because this
   copied harness's fallback `parents[2]` would otherwise select `.runtime`.

From the repository root:

```powershell
$measureRoot = Join-Path (Get-Location).Path '.runtime/history-correlation-repairs-2026-10-23'
$measureTemp = Join-Path $measureRoot 'measurement-final-temp'
New-Item -ItemType Directory -Path $measureTemp -Force | Out-Null
$env:TEMP = $measureTemp
$env:TMP = $measureTemp
$env:PYTHONUTF8 = '1'
$env:PYTHONIOENCODING = 'utf-8'
$env:PYTHONHASHSEED = '0'
$env:RSL_MEASURE_SOURCE_ROOT = (Get-Location).Path
& 'C:/Users/82046/anaconda3/envs/router-dump-analyzer-demo/python.exe' `
  (Join-Path $measureRoot 'measure.py') `
  --archive 'demo/fixtures/router-state-lab-algorithms-2026-10-02.tgz' `
  --output (Join-Path $measureRoot 'after-1m-quiet') `
  *> (Join-Path $measureRoot 'measurement-final.log')
$LASTEXITCODE
```

Run with the terminal tool's normal bounded yield, then poll the returned
session while keeping the user informed. The previous quiet run took about
three minutes. Do not launch another measurement while this child is active.

After completion, use the adjacent `compare_results.py`:

```powershell
& 'C:/Users/82046/anaconda3/envs/router-dump-analyzer-demo/python.exe' -B -X utf8 `
  (Join-Path $measureRoot 'compare_results.py') `
  --baseline (Join-Path $measureRoot 'baseline-1m-quiet-result.json') `
  --after (Join-Path $measureRoot 'after-1m-quiet/result.json') `
  --output (Join-Path $measureRoot 'comparison.json')
```

The comparator preserves repeated phase occurrences and compares complete
phase results, ordered page hashes, retirement/shared-cache/validation-cache
invariants, return codes and guards. Any difference must be reviewed. A count
of 52 names is insufficient: the repeated layer page names occur twice each.
The harness only hashes six measured core modules; separately capture all
changed backend/demo source hashes for reproducibility, especially
`multi_node_route.py`, `multi_node_topology.py` and `typed_topology.py`.

The search/cursor fix needs an additional matched before/after profiling trial:
this standard navigation workload does not call `resources_at(search=...)` at
the audited cursor sequence. Keep attribution profiling separate from the
quiet uninstrumented benchmark; record selected timestamp, kind, search,
limits, result equality, call counts, CPU and memory independently.

## Author documentation stewardship implications (recommendations only)

HC-02 restores an already explicit contract. `docs/plugin-contract.md` at the
topology section says the host supplies each invocation's reconstructed
`ResourceStateView`, the plug-in may only read it through `ReadOnlyWorld`, and
time-varying topology must not be frozen in constructor state. The normalized
replay section already specifies no-op failed updates, existence/status
separation, ordering, and half-open validity. The implementation should honor
these existing rules rather than introduce another plug-in API.

HC-01 restores time-bound query intent, but `docs/api-contract.md` section 5.5
does not spell out row-validity handling. A short clarification can state that
the table and executable candidate use the frozen resolved basis; future or
expired row evidence cannot establish reachability. Keep uncertainty and
unknown-time wording aligned with the actual fix/tests, not an invented policy.
The route consumer must not promote omission from the table into reachability
through a separate trace candidate path.

Minimal update plan:

- Validation skill/API map: add exact before/at/after validity probes, typed
  carrier down/restored correspondence with the local node, failed update
  controls, and settled searched/empty cursor timing with matched cache state.
- Add a brief normative clarification only where tests exercise the same
  boundary. Existing topology semantics already prohibit the frozen state bug.
- Keep the quickstart linear and its teaching parser small. If this repair is
  judged a new author-visible contract, AGENTS.md requires a same-change
  quickstart/contract/example update; use a small test-backed note/link to the
  temporal conformance example, not an unexercised topology hook in the basic
  status parser. Otherwise report it as restoring documented behavior and avoid
  unrelated maintained-document churn.
- Run `python scripts/check_plugin_conformance.py --list`; relevant executable
  modules are `tests.test_multi_node_route`, `tests.test_multi_node_route_regressions`,
  `tests.test_fixed_fixture_topology`, `tests.test_demo_vpn_topology`,
  `tests.test_multi_node_topology`, and `tests.test_reconstruction_truth`.
  If maintained teaching materials change, rerun their exact documented smoke
  block through `tests.test_plugin_authoring_docs` and the demo golden tests.

No documents or product files were edited by this preparation task.
