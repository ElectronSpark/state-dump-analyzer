# Exact-cursor resource search investigation

Fixture: existing `demo/fixtures/router-state-lab-algorithms-2026-10-02.tgz`,
PE-A with 1,250,005 events and 7,510 resources. Interpreter:
`C:/Users/82046/anaconda3/envs/router-dump-analyzer-demo/python.exe`.

## Attribution and correction

The real `NormalizedDataService.resources_at` query was timed directly at native
offsets 599.999999999, 600.075, 600.749999999 and 600.8 s. DTE kind, 200-row limit,
no layer restriction; compare empty search and `dte-000000`. The first searched
call also lazily materializes state/lifecycle histories. Subsequent fresh-cursor
queries still need searchable states for all resources: `counts_by_kind` spans
matching resources before the selected-kind filter. Moving that filter earlier
would silently change the API response. The bounded search cache is keyed to
exact timestamps; a new cursor cannot hit it just because its DTE row is unchanged.

The core used to publish a complete client view for each resource, including
non-searchable state, then project that view a second time for search. It also
reloaded the dataset and rebuilt descriptor lookup per resource. The fix shares
the existing reconstruction in a private helper and lets the existing search
projection publish only searchable data. The public state query still performs
the original full projection. Compiled property-trie child traversal also avoids
redundant generic Mapping checks. No plugin API, result cache, state index or
retention bound was added or changed.

Separate cProfile samples (not latency measurements) show:

| Work | Before | After |
| --- | ---: | ---: |
| Total calls | 31,971,995 | 16,698,626 |
| Full/search view projections | 15,021 | 7,511 |
| Dataset loads in query | 7,512 | 2 |
| Timestamp containment checks | 1,252,040 | 1,252,040 |
| Instrumented duration | 9.073 s | 5.118 s |

Fresh timestamps still scan resource history and project all searchable states.
This correction removes redundant publication work rather than inventing a
larger cache or compromising cross-kind counts. The remaining interval scans and
search projection account for the residual cost. Initial lazy history construction
also remains; this is why first search and later uncached cursors are reported
separately.

## Evidence and limits

`profile_cursor.py` produced `cursor-before.json` / `cursor-after.json` and their
separate `.pstats` and `-profile.txt` attribution records. All 40 complete-response
SHA-256 digests agree, including dynamic next hops, status search, layer filtering,
paging and boundary times. These initial timings may overlap separate generated
fixture test setup and use different hash-seed settings; treat them as preliminary.

`paired_cursor.py` performs the final quiet comparison in one process with
PYTHONHASHSEED=0. The exact pre-change HEAD module is retained as
`normalized_before.py` and loaded under a separate private module name. Both
service implementations share one fixed dataset and warmed temporal histories;
search snapshots are cleared identically before each implementation and order is
reversed in the second round. This times changed cursor behavior without repeated
cold import/archive/loading variability. `cursor-paired.json` / `.log` retain all
occurrences. `cursor-comparison.json` summarizes them and verifies complete paired
outputs. Direct request timings do not include browser work or the other graph,
dashboard and topology queries triggered by selecting a cursor.

The quiet paired run completed with eight matched uncached searched cursors per
version: median wall time **2.7967 s → 1.5514 s** (44.5% lower), median process CPU
**2.7500 s → 1.5391 s** (44.0% lower). Empty-search medians were 38.94 ms → 36.36 ms.
All sixteen complete searched/empty response pairs matched. Query RSS deltas were
zero after initial allocator warmup; that does not establish a process peak.

`cursor-tests.log`: 40 focused tests passed. New coverage compares the search
projection with full-public-view search over 144 timestamp/needle/layer cases,
including half-open endpoints, missing lifecycle evidence, history gaps,
overlapping perspectives, Unicode, nested/literal dotted fields, secrets,
cross-kind counts and paging. A work-bound assertion ensures unmatched,
non-searchable nested state is not traversed or published. Returned nested values
are independently owned. The existing hidden-key test now enters the real indexed
resource reconstruction instead of mocking its state result.

The two-snapshot cache is unchanged and no new persistent metadata is retained.
Paired per-query RSS samples are observations, not peak-memory measurements;
the parent task's separate 1M benchmark establishes the broader memory/CPU result.
No author-visible API behavior changed in this optimization, so its documentation
drift check requires no maintained authoring-guide/contract/example update.
