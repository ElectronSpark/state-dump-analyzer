"""Paired quiet direct-query comparison after one shared interval warmup."""
from __future__ import annotations
import ctypes, hashlib, importlib.util, json, os, sys, time
from ctypes import wintypes
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).parent
sys.path[:0] = [str(ROOT / 'src'), str(ROOT / 'demo'), str(ROOT / 'state-dump-generator/src')]
os.environ.setdefault('ROUTER_DUMP_SEARCH_CACHE_DIR', str(OUT / 'search-cache'))
from rsl_demo_plugin.session import runtime
from router_dump_analyzer.normalized_data import NormalizedDataService

spec = importlib.util.spec_from_file_location('router_dump_analyzer._cursor_baseline', OUT / 'normalized_before.py')
baseline = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = baseline
spec.loader.exec_module(baseline)
records = []
class ProcessMemory(ctypes.Structure):
    _fields_ = [('cb', wintypes.DWORD), ('PageFaultCount', wintypes.DWORD)] + [
        (name, ctypes.c_size_t) for name in ['PeakWorkingSetSize', 'WorkingSetSize',
        'QuotaPeakPagedPoolUsage', 'QuotaPagedPoolUsage', 'QuotaPeakNonPagedPoolUsage',
        'QuotaNonPagedPoolUsage', 'PagefileUsage', 'PeakPagefileUsage', 'PrivateUsage']]
kernel = ctypes.WinDLL('kernel32', use_last_error=True)
psapi = ctypes.WinDLL('psapi', use_last_error=True)
kernel.GetCurrentProcess.restype = wintypes.HANDLE
psapi.GetProcessMemoryInfo.argtypes = [wintypes.HANDLE, ctypes.POINTER(ProcessMemory), wintypes.DWORD]
def rss():
    value = ProcessMemory(); value.cb = ctypes.sizeof(value)
    if not psapi.GetProcessMemoryInfo(kernel.GetCurrentProcess(), ctypes.byref(value), value.cb):
        raise ctypes.WinError(ctypes.get_last_error())
    return value.WorkingSetSize
def measure(name, fn):
    mem_before = rss()
    start, cpu = time.perf_counter(), time.process_time()
    value = fn()
    row = dict(name=name, seconds=time.perf_counter()-start, cpu_seconds=time.process_time()-cpu,
               rss_before=mem_before, rss_after=rss(), at=time.time())
    if isinstance(value, dict) and 'matched_count' in value:
        encoded = json.dumps(value, sort_keys=True, ensure_ascii=True).encode()
        row.update(count=value['matched_count'], returned=value['returned_count'], sha256=hashlib.sha256(encoded).hexdigest())
    records.append(row)
    (OUT / 'cursor-paired.json').write_text(json.dumps(records, indent=2), encoding='utf-8')
    print(json.dumps(row), flush=True)
    return value

with runtime.open(ROOT / 'demo/fixtures/router-state-lab-algorithms-2026-10-02.tgz') as session:
    fixed = NormalizedDataService(session.data_source, session.data_policy)
    old = baseline.NormalizedDataService(session.data_source, session.data_policy)
    revisions = measure('archive_preparation', lambda: session.revision_store.assembly.revisions)
    ds = measure('node_a_load', lambda: fixed.load_dataset(revisions[0].revision_id))
    idx = fixed.history_runtime(ds)
    origin = 1759679999996000000
    measure('shared_history_warmup', lambda: fixed.resources_at(origin+600800000000, search='dte-000000'))
    for repeat in range(2):
        for ns in (599999999999, 600075000000, 600749999999, 600800000000):
            for label, svc in ((('before', old), ('after', fixed)) if repeat == 0 else (('after', fixed), ('before', old))):
                idx.resource_search._documents.clear()
                for term in ('dte-000000', ''):
                    measure(f'{repeat}:{ns}:{term or "empty"}:{label}',
                            lambda svc=svc, ns=ns, term=term: svc.resources_at(origin+ns, kinds={'DTE'}, search=term, limit=200))
    print(json.dumps({'snapshot_count': len(idx.resource_search._documents),
                      'document_count': sum(map(len, idx.resource_search._documents.values())),
                      'before_source_sha256': hashlib.sha256((OUT/'normalized_before.py').read_bytes()).hexdigest(),
                      'after_source_sha256': hashlib.sha256((ROOT/'src/router_dump_analyzer/normalized_data.py').read_bytes()).hexdigest(),
                      'pythonhashseed': os.environ.get('PYTHONHASHSEED', 'random')}), flush=True)
