from __future__ import annotations

import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import zipfile

root = Path(__file__).resolve().parents[2]
run = Path(__file__).resolve().parent
out = root / 'docs/history-correlation-repairs-2026-10-23'
out.mkdir(exist_ok=True)
sources = [
    'src/router_dump_analyzer/multi_node_route.py',
    'src/router_dump_analyzer/multi_node_route.pyi',
    'src/router_dump_analyzer/normalized_data.py',
    'demo/rsl_demo_plugin/typed_topology.py',
    'demo/rsl_demo_plugin/typed_topology.pyi',
    'frontend/assets/app.js', 'frontend/assets/topology.js',
    'frontend/tests/correlation_list_recovery.test.mjs',
    'tests/test_route_history_validity.py',
    'tests/test_resource_cursor_search.py',
    'tests/test_generated_assembly_api_integration.py',
    '.agents/skills/router-plugin-validate/SKILL.md',
    'docs/plugin-api-validation.md', 'docs/plugin-contract.md',
    'docs/api-contract.md', 'docs/plugin-author-quickstart.md',
    'docs/plugin-author-guide.md', 'README.md', 'demo/README.md',
]
metadata = {
    'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
    'branch': subprocess.check_output(['git', 'branch', '--show-current'], cwd=root, text=True).strip(),
    'source_sha256': {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in sources},
    'scope': 'Includes pre-existing uncommitted VPN popup repairs; no commit or push performed.',
}
(run / 'source-metadata.json').write_text(json.dumps(metadata, indent=2) + '\n', encoding='utf-8')
(run / 'working-tree.patch').write_bytes(subprocess.check_output(['git', 'diff', '--no-ext-diff'], cwd=root))
members = []
for p in sorted(run.iterdir()):
    if p.is_file() and p.suffix in {'.json', '.log', '.txt', '.md', '.py', '.png', '.pstats', '.patch'}:
        members.append((p, 'audit/' + p.name))
for p in sorted((run / 'after-1m-quiet').rglob('*')):
    if p.is_file() and p.suffix in {'.json', '.jsonl', '.log', '.txt'}:
        members.append((p, 'measurements/' + p.relative_to(run / 'after-1m-quiet').as_posix()))
for name in ('focused-final.log', 'focused-host.log', 'focused-sandbox.log',
             'boundaries-final.log', 'boundaries-head.log', 'stubs-final.log',
             'ruff-final.log', 'unit-final.log'):
    members.append((root / '.runtime/historical-route-repairs' / name, 'backend/' + name))
archive = out / 'evidence.zip'
entries = []
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as z:
    for p, name in members:
        data = p.read_bytes()
        z.writestr(name, data)
        entries.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert all(hashlib.sha256(z.read(row['path'])).hexdigest() == row['sha256'] for row in entries)
for p in run.glob('*.png'):
    shutil.copyfile(p, out / p.name)
for name in ('browser-checks.json', 'comparison.json', 'cursor-comparison.json', 'source-metadata.json'):
    shutil.copyfile(run / name, out / name)
manifest = {'archive': {'path': archive.name, 'bytes': archive.stat().st_size,
                       'sha256': hashlib.sha256(archive.read_bytes()).hexdigest()}, 'entries': entries}
(out / 'evidence-sha256.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'files': len(entries), 'archive_bytes': archive.stat().st_size,
                  'archive_sha256': manifest['archive']['sha256']}, indent=2))
