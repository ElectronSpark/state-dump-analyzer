"""Read-only counters for one explicitly identified demo-server process."""
import argparse
import ctypes
from ctypes import wintypes
from datetime import datetime, timezone
import json
from pathlib import Path
import time

parser = argparse.ArgumentParser()
parser.add_argument('--pid', type=int, required=True)
parser.add_argument('--executable', type=Path, required=True)
parser.add_argument('--access-log', type=Path, required=True)
parser.add_argument('--error-log', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--interval', type=float, default=2)
parser.add_argument('--maximum-seconds', type=float, default=7200)
args = parser.parse_args()
out = args.output.resolve()
out.mkdir(parents=True, exist_ok=False)
kernel = ctypes.WinDLL('kernel32', use_last_error=True)
psapi = ctypes.WinDLL('psapi', use_last_error=True)
kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
kernel.OpenProcess.restype = wintypes.HANDLE
kernel.CloseHandle.argtypes = [wintypes.HANDLE]
kernel.GetProcessTimes.argtypes = [wintypes.HANDLE] + [ctypes.POINTER(wintypes.FILETIME)] * 4
kernel.GetExitCodeProcess.argtypes = [wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD)]
kernel.QueryFullProcessImageNameW.argtypes = [wintypes.HANDLE, wintypes.DWORD, wintypes.LPWSTR, ctypes.POINTER(wintypes.DWORD)]


class Memory(ctypes.Structure):
    _fields_ = [('cb', wintypes.DWORD), ('PageFaultCount', wintypes.DWORD)] + [
        (name, ctypes.c_size_t) for name in [
            'PeakWorkingSetSize', 'WorkingSetSize', 'QuotaPeakPagedPoolUsage',
            'QuotaPagedPoolUsage', 'QuotaPeakNonPagedPoolUsage', 'QuotaNonPagedPoolUsage',
            'PagefileUsage', 'PeakPagefileUsage', 'PrivateUsage']]


psapi.GetProcessMemoryInfo.argtypes = [wintypes.HANDLE, ctypes.POINTER(Memory), wintypes.DWORD]
handle = kernel.OpenProcess(0x0400 | 0x0010, False, args.pid)
if not handle:
    raise ctypes.WinError(ctypes.get_last_error())


def stamp():
    return datetime.now(timezone.utc).isoformat()


def integer_filetime(value):
    return (value.dwHighDateTime << 32) | value.dwLowDateTime


def counters():
    creation, exit_time, kernel_time, user_time = (wintypes.FILETIME() for _ in range(4))
    if not kernel.GetProcessTimes(handle, ctypes.byref(creation), ctypes.byref(exit_time), ctypes.byref(kernel_time), ctypes.byref(user_time)):
        raise ctypes.WinError(ctypes.get_last_error())
    memory = Memory()
    memory.cb = ctypes.sizeof(memory)
    if not psapi.GetProcessMemoryInfo(handle, ctypes.byref(memory), memory.cb):
        raise ctypes.WinError(ctypes.get_last_error())
    access, errors = args.access_log.stat(), args.error_log.stat()
    return {'at_utc': stamp(), 'monotonic_seconds': time.monotonic(), 'pid': args.pid,
            'process_creation_filetime': integer_filetime(creation),
            'cpu_seconds': (integer_filetime(kernel_time)+integer_filetime(user_time))/10_000_000,
            'rss_bytes': memory.WorkingSetSize, 'private_bytes': memory.PrivateUsage,
            'process_lifetime_peak_rss_bytes': memory.PeakWorkingSetSize,
            'process_lifetime_peak_commit_bytes': memory.PeakPagefileUsage,
            'access_log_bytes': access.st_size, 'access_log_modified_ns': access.st_mtime_ns,
            'error_log_bytes': errors.st_size, 'error_log_modified_ns': errors.st_mtime_ns}


records = []
reason = None


def save_summary():
    if not records:
        return
    first, last = records[0], records[-1]
    wall = last['monotonic_seconds']-first['monotonic_seconds']
    cpu = last['cpu_seconds']-first['cpu_seconds']
    result = {'pid': args.pid, 'executable': str(args.executable.resolve()),
              'access_log': str(args.access_log.resolve()), 'error_log': str(args.error_log.resolve()),
              'first_sample': first, 'last_sample': last, 'sample_count': len(records),
              'nominal_interval_seconds': args.interval, 'complete': reason is not None,
              'stop_reason': reason, 'wall_seconds': wall, 'cpu_delta_seconds': cpu,
              'mean_logical_core_equivalents': cpu/wall if wall else None,
              'sampled_rss_min_bytes': min(row['rss_bytes'] for row in records),
              'sampled_rss_max_bytes': max(row['rss_bytes'] for row in records),
              'access_log_growth_bytes': last['access_log_bytes']-first['access_log_bytes'],
              'error_log_growth_bytes': last['error_log_bytes']-first['error_log_bytes'],
              'limits': 'Passive process-wide counters and log-file sizes only; no API requests or browser actions. CPU time is not browser latency. Sampling can miss brief memory peaks. Lifetime memory peaks predate the audit. Log growth is not a request count. Correlate time windows with parent UI-action evidence before attribution.'}
    (out/'summary.json').write_text(json.dumps(result, indent=2), encoding='utf-8')


try:
    length = wintypes.DWORD(32768)
    buffer = ctypes.create_unicode_buffer(length.value)
    if not kernel.QueryFullProcessImageNameW(handle, 0, buffer, ctypes.byref(length)):
        raise ctypes.WinError(ctypes.get_last_error())
    if Path(buffer.value).resolve() != args.executable.resolve():
        raise RuntimeError('Target executable no longer matches verified server identity')
    started = time.monotonic()
    with (out/'samples.jsonl').open('w', encoding='utf-8') as stream:
        while True:
            exit_code = wintypes.DWORD()
            if not kernel.GetExitCodeProcess(handle, ctypes.byref(exit_code)) or exit_code.value != 259:
                reason = 'target_process_exited'
                break
            sample = counters()
            if records:
                prior = records[-1]
                sample['interval_wall_seconds'] = sample['monotonic_seconds']-prior['monotonic_seconds']
                sample['interval_cpu_seconds'] = sample['cpu_seconds']-prior['cpu_seconds']
                sample['interval_logical_core_equivalents'] = sample['interval_cpu_seconds']/sample['interval_wall_seconds']
            records.append(sample)
            stream.write(json.dumps(sample)+'\n')
            stream.flush()
            save_summary()
            if len(records) == 1:
                print(json.dumps({'kind': 'baseline', **sample}), flush=True)
            if (out/'STOP').exists():
                reason = 'parent_stop_signal'
                break
            if time.monotonic()-started >= args.maximum_seconds:
                reason = 'maximum_observation_duration'
                break
            time.sleep(args.interval)
except BaseException as error:
    reason = 'observer_error'
    (out/'error.json').write_text(json.dumps({'at_utc': stamp(), 'error': repr(error)}, indent=2), encoding='utf-8')
    raise
finally:
    save_summary()
    kernel.CloseHandle(handle)
    print(json.dumps({'kind': 'observation_finished', 'reason': reason, 'samples': len(records)}), flush=True)
