$ErrorActionPreference = 'Stop'
$auditDirectory = Join-Path $PSScriptRoot '.'
$auditRawLines = Get-Content -LiteralPath (Join-Path $auditDirectory 'results.jsonl')
$auditLatest = @{}
$auditLatestLines = @{}
for ($auditIndex = 0; $auditIndex -lt $auditRawLines.Count; $auditIndex++) {
    $auditRow = $auditRawLines[$auditIndex] | ConvertFrom-Json
    if ($auditRow.id) { $auditLatest[$auditRow.id] = $auditRow; $auditLatestLines[$auditRow.id] = $auditIndex + 1 }
}
$auditPlans = (Get-Content -Raw -LiteralPath (Join-Path $auditDirectory 'remaining-original-cases.json') | ConvertFrom-Json).cases
$auditOutput = [ordered]@{}
if (Test-Path -LiteralPath (Join-Path $auditDirectory 'adjudications.json')) {
    $auditExisting = Get-Content -Raw -LiteralPath (Join-Path $auditDirectory 'adjudications.json') | ConvertFrom-Json
    foreach ($auditProperty in $auditExisting.PSObject.Properties) {
        if ($auditProperty.Name -notmatch '^M(27[1-9]|28[0-9]|29[0-9]|300)$') { $auditOutput[$auditProperty.Name] = $auditProperty.Value }
    }
}
function Audit-Equal($Left, $Right) { ($Left | ConvertTo-Json -Depth 30 -Compress) -ceq ($Right | ConvertTo-Json -Depth 30 -Compress) }
function Audit-Control($Observation, $Id) { $Observation.controls | Where-Object id -eq $Id | Select-Object -First 1 }
function Audit-Busy($Observation) {
    if ($Observation.PSObject.Properties.Name -contains 'busy') { return $Observation.busy }
    return $Observation.runDisabled
}
function Audit-Observation($Entry, $Label) { $Entry.observations | Where-Object label -eq $Label | Select-Object -Last 1 }
function Audit-Query($Url) {
    $auditMap = [ordered]@{}
    if (-not $Url) { return $auditMap }
    $auditUri = [uri]::new([uri]'http://127.0.0.1:8883/', [string]$Url)
    foreach ($auditPair in $auditUri.Query.TrimStart('?').Split('&')) {
        if (-not $auditPair) { continue }
        $auditParts = $auditPair.Split('=', 2)
        $auditMap[[uri]::UnescapeDataString($auditParts[0])] = if ($auditParts.Count -gt 1) { [uri]::UnescapeDataString($auditParts[1]) } else { '' }
    }
    return $auditMap
}
foreach ($auditNumber in 271..300) {
    $auditId = 'M' + $auditNumber
    $auditEntry = $auditLatest[$auditId]
    if (-not $auditEntry) { continue }
    $auditPlan = $auditPlans | Where-Object id -eq $auditId
    $auditBaseline = Audit-Observation $auditEntry 'baseline'
    if (-not $auditBaseline) { $auditBaseline = Audit-Observation $auditEntry 'baseline trace' }
    $auditFinal = @($auditEntry.observations)[-1]
    $auditChecks = [ordered]@{}
    $auditLimits = [System.Collections.Generic.List[string]]::new()
    $auditConclusions = [System.Collections.Generic.List[string]]::new()
    $auditOutcome = 'passed_with_limits'
    $auditBaselineQuery = Audit-Query $auditBaseline.url
    if ($auditBaselineQuery.clock_policy -and $auditBaselineQuery.clock_policy -ne 'strict') {
        $auditLimits.Add('Recorded reconstruction uses clock_policy=' + $auditBaselineQuery.clock_policy + ', not the original B0 Strict clock baseline. Route missing-hop policy is a separate control. Conclusions apply to the recorded reconstruction only.')
    }
    $auditCaseKind = ($auditNumber - 271) % 6
    switch ($auditCaseKind) {
        0 {
            $auditBefore = Audit-Observation $auditEntry 'before reload'
            $auditReload = Audit-Observation $auditEntry 'reloaded before explicit trace'
            $auditImmediate = Audit-Observation $auditEntry 'explicit trace after reload immediate'
            $auditChecks['exact_controls_preserved_on_reload'] = Audit-Equal $auditBefore.controls $auditReload.controls
            $auditChecks['exact_url_preserved_on_reload'] = $auditBefore.url -ceq $auditReload.url
            $auditChecks['no_trace_before_explicit_submission'] = $auditReload.contentHidden -eq $true -and $auditReload.emptyHidden -eq $false -and -not $auditReload.comparison
            $auditChecks['explicit_submission_entered_busy'] = (Audit-Busy $auditImmediate) -eq $true
            $auditChecks['explicit_submission_settled'] = (Audit-Busy $auditFinal) -eq $false -and $auditFinal.emptyHidden -eq $true -and -not $auditFinal.error
            foreach ($auditField in @('comparison', 'paths', 'nodes', 'overview', 'membership', 'revision')) {
                if ($auditBefore.PSObject.Properties.Name -contains $auditField) { $auditChecks['restored_' + $auditField] = Audit-Equal $auditBefore.$auditField $auditFinal.$auditField }
            }
            $auditConclusions.Add('Reload preserves URL-supported configuration; explicit retrace restores the recorded outcome and path/overview state. Hidden selected-path content in unpinned All paths mode is intentional, not a failed trace.')
            if ($auditEntry.status -eq 'needs_review') { $auditConclusions.Add('Correct raw needs_review: the prior predicate incorrectly required selected-path content to be visible in All paths mode.') }
            $auditLimits.Add('The recorded fields establish configuration and result recovery, not viewport settling or a request-level absence of all background work.')
            if ($auditFinal.PSObject.Properties.Name -notcontains 'comparisonHidden') { $auditLimits.Add('Earlier sampler omits outcome visibility; recovery is supported by emptyHidden=true, enabled run, matching outcome/path/node content, and the reviewed intentional All-mode rendering branch.') }
        }
        1 {
            $auditChanges = [System.Collections.Generic.List[string]]::new()
            $auditHistoryObservations = @($auditEntry.observations | Where-Object { $_.label -notmatch '^baseline trace' })
            foreach ($auditObservation in $auditHistoryObservations) {
                foreach ($auditField in @('controls', 'comparison', 'nodes', 'overview', 'paths', 'membership', 'revision', 'summary', 'contentHidden', 'comparisonHidden', 'emptyHidden')) {
                    if ($auditBaseline.PSObject.Properties.Name -contains $auditField) {
                        if (-not (Audit-Equal $auditBaseline.$auditField $auditObservation.$auditField)) { $auditChanges.Add($auditObservation.label + ':' + $auditField) }
                    }
                }
            }
            $auditChecks['recorded_route_state_unchanged'] = $auditChanges.Count -eq 0
            $auditChecks['state_differences'] = @($auditChanges)
            $auditChecks['observed_hash_sequence'] = @($auditHistoryObservations | ForEach-Object { ([uri]$_.url).Fragment })
            $auditConclusions.Add('Recorded controls, current outcome, path/graph state and context remain identical through section navigation and native Back/Forward.')
            $auditLimits.Add('No viewport position/settling observation; this establishes fragment and route-state preservation only.')
            if ($auditId -eq 'M296') { $auditLimits.Add('Baseline URL has an empty fragment. Back restores that actual baseline (not #route-trace), then explicit Route trace sets #route-trace; this is consistent native history behavior.') }
        }
        2 {
            $auditNodeCandidates = @($auditEntry.observations | Where-Object { $_.context -and $_.url -match '/node\?' })
            if (-not $auditNodeCandidates.Count) { $auditNodeCandidates = @($auditEntry.observations | Where-Object { $_.label -in @('node member loaded', 'transit member load completed') }) }
            $auditNode = $auditNodeCandidates[-1]
            $auditHop = @($auditEntry.observations | Where-Object { $_.label -in @('hop selected', 'hop chosen') })[-1]
            $auditNodeQuery = Audit-Query $auditNode.url
            $auditReturnedQuery = Audit-Query $auditFinal.url
            $auditOriginalQuery = Audit-Query $auditBaseline.url
            $auditChecks['node_context_banner_recorded'] = [bool]$auditNode.context
            $auditChecks['node_identity'] = [ordered]@{ node_id=$auditNodeQuery.node_id; member_id=$auditNodeQuery.member_id; revision_id=$auditNodeQuery.revision_id; plugin_set_id=$auditNodeQuery.plugin_set_id; context_id=$auditNodeQuery.context_id; basis_kind=$auditNodeQuery.basis_kind; basis_offset_ns=$auditNodeQuery.basis_offset_ns }
            $auditChecks['scenario_restored'] = (Audit-Control $auditFinal 'mn-route-scenario').value -ceq (Audit-Control $auditBaseline 'mn-route-scenario').value
            $auditChecks['context_id_restored'] = $auditReturnedQuery.context_id -ceq $auditOriginalQuery.context_id
            $auditChecks['clock_policy_restored'] = $auditReturnedQuery.clock_policy -ceq $auditOriginalQuery.clock_policy
            $auditChecks['outcome_restored'] = Audit-Equal $auditFinal.comparison $auditBaseline.comparison
            $auditChecks['final_trace_settled'] = (Audit-Busy $auditFinal) -eq $false -and $auditFinal.emptyHidden -eq $true -and -not $auditFinal.error
            if ($auditNode.backHref) {
                $auditBackQuery = Audit-Query $auditNode.backHref
                $auditChecks['advertised_return_scenario_matches_baseline'] = $auditBackQuery.route_scenario -ceq $auditOriginalQuery.route_scenario
                $auditChecks['advertised_return_context_matches_baseline'] = $auditBackQuery.context_id -ceq $auditOriginalQuery.context_id
            }
            if ($auditHop.openHref) { $auditChecks['advertised_node_url_matches_destination'] = $auditHop.openHref -ceq $auditNode.url }
            else { $auditLimits.Add('Pre-navigation advertised node-link href was not captured separately; destination URL/banner provide the effective navigation identity.') }
            $auditLimits.Add('Selected-device detail contents and exact resolved numeric capture time are not recorded; only member/revision/context and relative basis are evidenced.')
            if ($auditId -eq 'M279') { $auditLimits.Add('Both node observations already say revision loaded and omit data-ready state; their timestamp gap does not establish full 1M load duration. Use independent passive timing/readiness evidence for a performance claim.') }
            if ($auditId -eq 'M291' -and -not $auditChecks['scenario_restored']) {
                $auditOutcome = 'inconclusive'
                $auditConclusions.Add('Raw passed claim is contradicted: node member loaded has generic title and no banner/backHref, return lands on bare /, and retrace uses single-active-primary/default/MPLS with best_effort instead of the requested EVPN mismatch context.')
                $auditConclusions.Add('Advertised/opened node URL retains the correct return_to. The claimed loaded sample is only 17 ms after navigation-requested sample; early readiness/return activation is the leading harness explanation, not a confirmed app context-loss defect.')
                $auditLimits.Add('Must rerun while waiting for an actual member banner and capture the advertised Back href before activation. Current attempt does not validate a completed node roundtrip.')
            } else {
                $auditConclusions.Add('Actual member destination/banner and explicit return retrace preserve the recorded scenario/context/outcome.')
                if ($auditId -in @('M291', 'M297')) { $auditConclusions.Add('This replay supersedes the earlier premature readiness attempt; actual loaded member context and populated Back href are recorded before return.') }
            }
        }
        3 {
            $auditMtuSelected = Audit-Observation $auditEntry 'MTU selected before trace'
            $auditMtu = Audit-Observation $auditEntry 'MTU trace'
            $auditOriginalSelected = Audit-Observation $auditEntry 'original selected before trace'
            $auditChecks['mtu_scenario_selected'] = (Audit-Control $auditMtuSelected 'mn-route-scenario').value -ceq 'packet-mtu-drop'
            $auditChecks['mtu_context'] = @($auditMtuSelected.controls | Where-Object { $_.id -in @('mn-route-start', 'mn-route-source', 'mn-route-destination', 'mn-route-vrf', 'mn-route-family', 'mn-route-type') })
            $auditChecks['restored_context'] = @($auditOriginalSelected.controls | Where-Object { $_.id -in @('mn-route-start', 'mn-route-source', 'mn-route-destination', 'mn-route-vrf', 'mn-route-family', 'mn-route-type') })
            $auditChecks['mtu_fails_both_directions'] = $auditMtu.comparison -match 'Both directions fail'
            $auditChecks['original_scenario_restored'] = (Audit-Control $auditFinal 'mn-route-scenario').value -ceq (Audit-Control $auditBaseline 'mn-route-scenario').value
            $auditChecks['outcome_restored'] = Audit-Equal $auditFinal.comparison $auditBaseline.comparison
            $auditChecks['details_retired_between_scenarios'] = $auditMtuSelected.contentHidden -eq $true -and $auditOriginalSelected.contentHidden -eq $true
            if ($auditMtuSelected.PSObject.Properties.Name -contains 'comparisonHidden') { $auditChecks['verdict_retired_between_scenarios'] = $auditMtuSelected.comparisonHidden -eq $true -and $auditOriginalSelected.comparisonHidden -eq $true }
            else { $auditLimits.Add('Immediate verdict visibility is not captured; retained comparison text alone cannot establish whether an obsolete verdict was visible.') }
            $auditConclusions.Add('Scenario replacement uses recorded declared endpoint/context defaults; explicit MTU failure and original-scenario recovery are supported.')
            $auditLimits.Add('Findings and packet-inspector visibility/content were not separately captured for immediate invalidation; do not claim every stale-detail surface was observed.')
            if ($auditId -eq 'M298' -and -not $auditMtuSelected) {
                $auditOutcome = 'inconclusive'
                $auditChecks.Clear()
                $auditChecks['final_nested_vpn_result_present'] = (Audit-Control $auditFinal 'mn-route-scenario').value -ceq 'packet-vpn-over-vpn' -and $auditFinal.emptyHidden -eq $true -and $auditFinal.comparisonHidden -eq $false -and (Audit-Busy $auditFinal) -eq $false -and -not $auditFinal.error
                $auditChecks['unobserved_required_steps'] = @('baseline trace', 'MTU selected before trace', 'MTU trace', 'original selected before trace', 'original recovered')
                $auditConclusions.Clear()
                $auditConclusions.Add('Only the final nested-VPN result is recorded. The passed note does not supply the missing MTU selection, intermediate failed trace or original-context restoration observations.')
                $auditLimits.Add('Single after automation timeout sample cannot verify the planned scenario roundtrip. The rolling checkpoint has advanced; attach preserved intermediate evidence or repeat the sequence.')
                $auditLimits.Add('Final URL uses best_effort reconstruction; no original B0 Strict-clock baseline is established by this attempt.')
            }
        }
        4 {
            $auditInvalid = Audit-Observation $auditEntry 'empty destination validation'
            if (-not $auditInvalid) { $auditInvalid = Audit-Observation $auditEntry 'empty destination validation captured' }
            $auditImmediate = Audit-Observation $auditEntry 'restored destination immediate'
            $auditChecks['empty_destination_rejected'] = (Audit-Control $auditInvalid 'mn-route-destination').value -ceq '' -and $auditInvalid.error -ceq 'Enter a destination to trace.'
            $auditChecks['exact_destination_restored'] = (Audit-Control $auditFinal 'mn-route-destination').value -ceq (Audit-Control $auditBaseline 'mn-route-destination').value
            $auditChecks['fresh_trace_busy_then_settled'] = (Audit-Busy $auditImmediate) -eq $true -and (Audit-Busy $auditFinal) -eq $false -and $auditFinal.emptyHidden -eq $true -and -not $auditFinal.error
            $auditChecks['outcome_restored'] = Audit-Equal $auditFinal.comparison $auditBaseline.comparison
            $auditChecks['invalid_details_hidden'] = $auditInvalid.contentHidden -eq $true
            if ($auditInvalid.PSObject.Properties.Name -contains 'comparisonHidden') { $auditChecks['invalid_verdict_hidden'] = $auditInvalid.comparisonHidden -eq $true }
            else { $auditLimits.Add('Invalid-state outcome visibility is not recorded, though selected-path details are hidden.') }
            $auditConclusions.Add('Empty destination validation and exact-value restoration followed by a fresh successful recovery trace are supported.')
            $auditLimits.Add('Packet-inspector/findings visibility is not separately recorded during validation; this is not exhaustive stale-detail coverage.')
        }
        5 {
            $auditReturn = Audit-Observation $auditEntry 'return only'
            $auditInvalid = Audit-Observation $auditEntry 'empty start validation'
            $auditImmediate = Audit-Observation $auditEntry 'restored exact start immediate'
            $auditChecks['return_only_trace_completed'] = (Audit-Control $auditReturn 'mn-route-validation').value -ceq 'reverse' -and (Audit-Busy $auditReturn) -eq $false -and $auditReturn.emptyHidden -eq $true -and -not $auditReturn.error
            $auditChecks['empty_forward_start_rejected'] = (Audit-Control $auditInvalid 'mn-route-validation').value -ceq 'forward' -and (Audit-Control $auditInvalid 'mn-route-start').value -ceq '' -and $auditInvalid.error -ceq 'Choose where forward tracing starts.'
            $auditChecks['exact_start_restored'] = (Audit-Control $auditFinal 'mn-route-start').value -ceq (Audit-Control $auditBaseline 'mn-route-start').value
            $auditChecks['forward_trace_busy_then_settled'] = (Audit-Busy $auditImmediate) -eq $true -and (Audit-Busy $auditFinal) -eq $false -and $auditFinal.emptyHidden -eq $true -and -not $auditFinal.error
            $auditChecks['final_direction_forward'] = (Audit-Control $auditFinal 'mn-route-validation').value -ceq 'forward'
            if ($auditInvalid.PSObject.Properties.Name -contains 'comparisonHidden') { $auditChecks['invalid_verdict_hidden'] = $auditInvalid.comparisonHidden -eq $true }
            $auditConclusions.Add('Return-only submission, empty forward-start validation and exact start restoration with a fresh forward trace are supported.')
            $auditLimits.Add('Unused-start snapshot omits disabled/ARIA/usage/help state, and Return-only still carries a nonempty start. It does not prove the start is optional or verify the unused-field presentation.')
            $auditLimits.Add('Packet-inspector/findings visibility is not separately recorded during validation.')
        }
    }
    $auditFalseChecks = @($auditChecks.GetEnumerator() | Where-Object { $_.Value -is [bool] -and -not $_.Value } | ForEach-Object Key)
    if ($auditFalseChecks.Count -and $auditOutcome -ne 'inconclusive') {
        $auditOutcome = 'needs_review'
        $auditLimits.Add('Computed checks requiring review: ' + ($auditFalseChecks -join ', '))
    }
    $auditSha = [System.Security.Cryptography.SHA256]::Create()
    $auditHash = [Convert]::ToHexString($auditSha.ComputeHash([Text.Encoding]::UTF8.GetBytes($auditRawLines[$auditLatestLines[$auditId] - 1]))).ToLowerInvariant()
    $auditSha.Dispose()
    $auditOutput[$auditId] = [ordered]@{
        outcome=$auditOutcome
        functional_failure_confirmed=$false
        raw_status=$auditEntry.status
        title=$auditPlan.title
        source=[ordered]@{ path='results.jsonl'; line=$auditLatestLines[$auditId]; raw_record_sha256=$auditHash; observation_labels=@($auditEntry.observations | ForEach-Object label); final_observation_utc=$auditFinal.utc }
        verified_checks=$auditChecks
        conclusions=@($auditConclusions)
        evidence_limits=@($auditLimits)
    }
}
$auditOutput | ConvertTo-Json -Depth 35 | Set-Content -LiteralPath (Join-Path $auditDirectory 'adjudications.json') -Encoding utf8
$auditOutput.GetEnumerator() | ForEach-Object { [pscustomobject]@{ id=$_.Key; outcome=$_.Value.outcome; raw_status=$_.Value.raw_status; line=$_.Value.source.line; false_checks=@($_.Value.verified_checks.GetEnumerator() | Where-Object { $_.Value -is [bool] -and -not $_.Value } | ForEach-Object Key) } } | ConvertTo-Json -Depth 5
