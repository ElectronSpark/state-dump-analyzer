$ErrorActionPreference = 'Stop'
$auditRaw = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'results.jsonl')
$auditLatest = @{}
$auditLines = @{}
for ($auditIndex = 0; $auditIndex -lt $auditRaw.Count; $auditIndex++) {
    $auditRow = $auditRaw[$auditIndex] | ConvertFrom-Json
    if ($auditRow.id) { $auditLatest[$auditRow.id] = $auditRow; $auditLines[$auditRow.id] = $auditIndex + 1 }
}
$auditPlans = (Get-Content -Raw -LiteralPath (Join-Path $PSScriptRoot 'supplemental-36-proposed.json') | ConvertFrom-Json).cases
$auditOutput = [ordered]@{}
function Audit-Obs($Entry, $Label) { $Entry.observations | Where-Object label -eq $Label | Select-Object -Last 1 }
function Audit-Same($Left, $Right) { ($Left | ConvertTo-Json -Depth 20 -Compress) -ceq ($Right | ConvertTo-Json -Depth 20 -Compress) }
function Audit-Attr($Markup, $Name) { [Net.WebUtility]::HtmlDecode([regex]::Match([string]$Markup, [regex]::Escape($Name) + '="([^"]*)"').Groups[1].Value) }
function Audit-RootIds($Observation) { @($Observation.lanes | Where-Object { $_.key -like 'root:*' -and $_.key -notlike '*>*' } | ForEach-Object id | Sort-Object) }
function Audit-Sources($Observation) { @($Observation.lanes | Where-Object source | ForEach-Object source) }
foreach ($auditId in (1..36 | ForEach-Object { 'C' + $_.ToString('000') })) {
    $auditEntry = $auditLatest[$auditId]
    $auditPlan = $auditPlans | Where-Object id -eq $auditId
    if (-not $auditEntry) {
        $auditOutput[$auditId] = [ordered]@{ outcome='not_recorded'; functional_failure_confirmed=$false; raw_status=$null; title=$auditPlan.title; source=$null; verified_checks=@{}; conclusions=@('No completed raw record for this ID at review time.'); evidence_limits=@('No execution or success claim can be assessed.'); review_scope='Latest recorded attempt only; no browser actions by reviewer.' }
        continue
    }
    $auditChecks = [ordered]@{}
    $auditConclusions = [System.Collections.Generic.List[string]]::new()
    $auditLimits = [System.Collections.Generic.List[string]]::new()
    $auditOutcome = 'passed_with_limits'
    $auditAdditionalSources = @()
    $auditFinal = @($auditEntry.observations)[-1]
    switch ($auditId) {
        'C001' {
            $auditIdentity = Audit-Obs $auditEntry 'stable singleton target'
            $auditBefore = Audit-Obs $auditEntry 'before cycles'
            $auditChecks['exact_uid_time_instance_stable'] = @($auditEntry.observations | Where-Object active | Where-Object { (Audit-Attr $_.active 'data-event-uid') -cne $auditIdentity.uid -or (Audit-Attr $_.active 'data-hover-key') -cne $auditIdentity.key -or (Audit-Attr $_.active 'data-time-ns') -cne '1759680119996000000' }).Count -eq 0
            $auditChecks['target_popup_open_all_activations'] = @($auditEntry.observations | Where-Object active | Where-Object { $_.popup.hidden -ne $false -or $_.popup.text -notmatch 'peer-00000' }).Count -eq 0
            foreach ($auditCycle in 0..1) {
                $auditRemoved = Audit-Obs $auditEntry ('same event after removal ' + $auditCycle)
                $auditRestored = Audit-Obs $auditEntry ('same event after restoration ' + $auditCycle)
                $auditExpectedRemaining = @(Audit-RootIds $auditBefore | Where-Object { $_ -cne $auditIdentity.preceding })
                $auditChecks['cycle_' + $auditCycle + '_only_preceding_lane_removed'] = Audit-Same (Audit-RootIds $auditRemoved) $auditExpectedRemaining
                $auditChecks['cycle_' + $auditCycle + '_all_root_lanes_restored'] = Audit-Same (Audit-RootIds $auditRestored) (Audit-RootIds $auditBefore)
            }
            $auditConclusions.Add('Both removal/restoration cycles preserve exact neighbor occurrence, UID/time and popup resource; full unrelated root-lane sets are preserved.')
            $auditLimits.Add('No intermediate picker-open/popup-dismissed snapshot; that note is not directly evidenced by these post-reopen observations.')
            $auditLimits.Add('No marker rectangle is captured alongside card bounds; exact popup-to-marker attachment geometry is not independently measured.')
            $auditLimits.Add('Superseded cluster replacement is consistent with global glyph-budget rebinning; immutable event UID is the appropriate identity for this replay.')
        }
        'C002' {
            $auditIdentity = Audit-Obs $auditEntry 'anchor identity'
            $auditRemoved = Audit-Obs $auditEntry 'own anchor lane removed'
            $auditRestored = Audit-Obs $auditEntry 'restored lane no activation'
            $auditChecks['own_lane_absent_after_removal'] = $auditIdentity.resource -notin (Audit-RootIds $auditRemoved)
            $auditChecks['own_lane_present_after_restoration'] = $auditIdentity.resource -in (Audit-RootIds $auditRestored)
            $auditChecks['dismissed_during_removal_scroll_and_restoration'] = @($auditEntry.observations | Where-Object { $_.label -in @('own anchor lane removed','removed anchor scroll away','removed anchor scroll back','restored lane no activation') } | Where-Object { $_.popup.hidden -ne $true }).Count -eq 0
            $auditChecks['explicit_activation_opens_same_resource'] = $auditFinal.popup.hidden -eq $false -and (Audit-Attr $auditFinal.active 'data-hover-key').Contains('root:' + $auditIdentity.resource + ':')
            $auditConclusions.Add('Own-lane removal dismisses the card; snapshots after scroll/restoration remain dismissed until explicit activation of the restored resource.')
            $auditLimits.Add('Exact cluster membership/key may change with shared-budget allocation; this case verifies restored resource identity rather than permanent aggregate identity.')
            $auditLimits.Add('Rapid away/back samples establish captured hidden states, not every intermediate smooth-scroll frame.')
        }
        'C003' {
            $auditActivated = @($auditEntry.observations | Where-Object { $_.label -like 'activated occurrence *' })
            $auditChecks['two_distinct_instance_keys'] = @($auditActivated | ForEach-Object { Audit-Attr $_.active 'data-hover-key' } | Select-Object -Unique).Count -eq 2
            $auditChecks['same_event_uid_in_both_occurrences'] = @($auditActivated | Where-Object { (Audit-Attr $_.active 'data-event-uid') -cne 'node-a/scale-event-00000000' }).Count -eq 0
            $auditChecks['both_popup_resources_are_dte'] = @($auditActivated | Where-Object { $_.popup.hidden -ne $false -or $_.popup.text -notmatch 'Resource\s+dte-000000' }).Count -eq 0
            $auditChecks['focused_log_uid_matches'] = (Audit-Attr (Audit-Obs $auditEntry 'same event in log after parent collapse').active 'data-event-uid') -ceq 'node-a/scale-event-00000000'
            $auditChecks['parent_reexpanded'] = (Audit-Attr $auditFinal.active 'aria-expanded') -ceq 'true'
            $auditConclusions.Add('Canonical DTE event opens correctly in two distinct occurrence paths, survives log navigation, and its parent re-expands.')
            $auditLimits.Add('Executed variant is one root occurrence and one next_hop child, not two independently expanded relationship parents requested by the plan.')
            $auditLimits.Add('Unrelated expanded parent preservation is not established; event popup shows canonical event facts, not a separately asserted relationship-inspector context.')
            $auditLimits.Add('Log representative popup may show another effect resource for the same multi-resource event; recorded UID remains the same. Focus is not batch selection.')
        }
        'C004' {
            $auditNative = Audit-Obs $auditEntry 'native source reveal'
            $auditChecks['source_uid_and_exact_time'] = (Audit-Attr $auditNative.active 'data-source-record-uid') -ceq 'source-ctf-unmatched-000000' -and (Audit-Attr $auditNative.active 'data-time-ns') -ceq '1759680029996200000'
            foreach ($auditCycle in 0..1) {
                $auditOn = Audit-Obs $auditEntry ('source preset on ' + $auditCycle)
                $auditOff = Audit-Obs $auditEntry ('source preset off ' + $auditCycle)
                $auditChecks['preset_cycle_' + $auditCycle] = 'plugin-unmatched-ctf' -in (Audit-Sources $auditOn) -and 'plugin-unmatched-ctf' -notin (Audit-Sources $auditOff) -and 'jump-record-1' -in (Audit-Sources $auditOn) -and 'jump-record-1' -in (Audit-Sources $auditOff)
            }
            $auditRepeat = Audit-Obs $auditEntry 'same source revealed again'
            $auditChecks['one_jump_lane_on_repeat'] = @(Audit-Sources $auditRepeat | Where-Object { $_ -like 'jump-record-*' }).Count -eq 1
            $auditChecks['temporary_removed_matching_preset_retained'] = @(Audit-Sources $auditFinal | Where-Object { $_ -like 'jump-record-*' }).Count -eq 0 -and 'plugin-unmatched-ctf' -in (Audit-Sources $auditFinal)
            $auditConclusions.Add('Source UID/time and a single temporary lane survive preset cycles; removing the temporary lane retains the independent CTF preset.')
            $auditLimits.Add('Final preset lane exists, but no final marker UID/rectangle proves the exact record is rendered within that preset after temporary-lane removal.')
            $auditLimits.Add('Repeat-reveal snapshot retains log focus, not settled timeline activation; it proves no extra jump lane at that observation, not final target viewport visibility.')
            $auditLimits.Add('Reported one-off pointer-checkbox failure has no event-delivery/target evidence in this record; keyboard recovery alone neither confirms nor disproves a functional defect.')
        }
        'C005' {
            $auditDeep = Audit-Obs $auditEntry 'deep child expanded'
            $auditCollapsed = Audit-Obs $auditEntry 'parent collapsed'
            $auditExpanded = Audit-Obs $auditEntry 'parent reexpanded'
            $auditClosed = Audit-Obs $auditEntry 'owning root closed by keyboard'
            $auditChildPrefix = 'root:node-a/control-plane/IP_ROUTING/blue>node-a/data-bridge-layer/DTE/blue/dte-000000|next_hop|node-a/control-plane/IP_ROUTING/blue>'
            $auditChecks['deep_disclosure_survives_parent_roundtrip'] = @($auditDeep.lanes | Where-Object { $_.key -and $_.key.StartsWith($auditChildPrefix) }).Count -gt 0 -and @($auditExpanded.lanes | Where-Object { $_.key -and $_.key.StartsWith($auditChildPrefix) }).Count -gt 0
            $auditChecks['parent_collapse_state_recorded'] = (Audit-Attr $auditCollapsed.active 'aria-expanded') -ceq 'false'
            $auditChecks['close_uses_visible_container_fallback'] = (Audit-Attr $auditClosed.active 'id') -ceq 'timeline-scroll'
            $auditChecks['owning_root_removed_and_restored'] = 'node-a/control-plane/IP_ROUTING/blue' -notin (Audit-RootIds $auditClosed) -and 'node-a/control-plane/IP_ROUTING/blue' -in (Audit-RootIds $auditFinal)
            $auditChecks['no_popup_stranded'] = @($auditEntry.observations | Where-Object { $_.popup.hidden -ne $true }).Count -eq 0
            $auditConclusions.Add('Deep disclosure survives parent collapse/re-expand; keyboard root removal uses timeline-container focus fallback and exact owning root is restored.')
            $auditLimits.Add('Child has no independent close control; owning-root close is an explicitly narrower variant of the requested child-lane operation.')
            $auditLimits.Add('Final restored Resources-checkbox focus and focus-control rectangle are not recorded.')
        }
        'C006' {
            $auditZero = Audit-Obs $auditEntry 'zero-resource-lanes'
            $auditSource = Audit-Obs $auditEntry 'source-with-zero-resources'
            $auditReview = Audit-Obs $auditEntry 'review-with-zero-resources'
            $auditRestored = Audit-Obs $auditEntry 'associated-resource-restored'
            $auditChecks['zero_resource_lanes_during_source_and_review_activation'] = @(Audit-RootIds $auditZero).Count -eq 0 -and @(Audit-RootIds $auditSource).Count -eq 0 -and @(Audit-RootIds $auditReview).Count -eq 0
            $auditChecks['exact_source_activates'] = (Audit-Attr $auditSource.active 'data-source-record-uid') -ceq 'source-ctf-unmatched-000000' -and $auditSource.popup.hidden -eq $false
            $auditChecks['exact_review_event_activates'] = (Audit-Attr $auditReview.active 'data-hover-key') -ceq 'review-marker:event:node-a/scenario/node-a-route-create' -and $auditReview.popup.hidden -eq $false
            $auditChecks['associated_resource_added_through_checkbox'] = (Audit-Attr $auditRestored.active 'data-lane-toggle') -ceq 'node-a/control-plane/IP_ROUTE/route:blue:198.51.100.0/30' -and 'node-a/control-plane/IP_ROUTE/route:blue:198.51.100.0/30' -in (Audit-RootIds $auditRestored)
            $auditChecks['source_lanes_retained_after_resource_add'] = Audit-Same (Audit-Sources $auditZero) (Audit-Sources $auditRestored)
            $auditConclusions.Add('Source and exact local review-event glyphs activate with zero resource lanes; adding the exact associated IP_ROUTE through Resources preserves all recorded source lanes.')
            $auditLimits.Add('Sampler does not enumerate review glyphs or review list. Review-marker retention after resource add and actual cleanup are asserted only by labels/notes, not direct before/after marker identities or counts.')
            $auditLimits.Add('Exact marker viewport geometry is not recorded at every step.')
        }
        'C007' {
            $auditCards = @($auditEntry.observations | Where-Object { $_.label -like 'timeline card *' })
            $auditLogs = @($auditEntry.observations | Where-Object { $_.label -like 'same event focused in log *' })
            $auditChecks['three_exact_timeline_activations'] = $auditCards.Count -eq 3 -and @($auditCards | Where-Object { (Audit-Attr $_.active 'data-event-uid') -cne 'node-a/scale-event-00000000' -or (Audit-Attr $_.active 'data-hover-key') -cne 'event:root:node-a/data-bridge-layer/DTE/blue/dte-000000:node-a/scale-event-00000000' -or $_.popup.hidden -ne $false }).Count -eq 0
            $auditChecks['three_exact_log_focus_returns'] = $auditLogs.Count -eq 3 -and @($auditLogs | Where-Object { (Audit-Attr $_.active 'data-event-uid') -cne 'node-a/scale-event-00000000' }).Count -eq 0
            $auditConclusions.Add('Three explicit timeline-card activations and log-focus returns keep the same normalized UID; timeline occurrence is the root DTE path.')
            $auditLimits.Add('Reveal snapshots are still at the log with timeline offscreen. Later explicit marker activation demonstrates usable recovery but does not prove reveal itself finished scrolling correctly.')
            $auditLimits.Add('Marker rectangle is not captured. Focused/selected log-row rectangles are visible, but exact two-axis marker visibility and every settled transition are unverified.')
            $auditLimits.Add('Unpinned popup can follow pointer hover over a different visible log row while keyboard focus remains on the target; popup text alone is not selection identity.')
        }
        'C008' {
            $auditInitial = Audit-Obs $auditEntry 'source initial reveal'
            $auditLog = Audit-Obs $auditEntry 'source back to log'
            $auditOff = Audit-Obs $auditEntry 'source inclusion off'
            $auditChecks['same_source_uid_timeline_and_log'] = (Audit-Attr $auditInitial.active 'data-source-record-uid') -ceq 'source-ctf-unmatched-000000' -and (Audit-Attr $auditLog.active 'data-source-record-uid') -ceq 'source-ctf-unmatched-000000' -and (Audit-Attr $auditFinal.active 'data-source-record-uid') -ceq 'source-ctf-unmatched-000000'
            $auditChecks['source_exact_time_retained'] = (Audit-Attr $auditInitial.active 'data-time-ns') -ceq '1759680029996200000' -and $auditFinal.popup.text -match '1759680029996200000'
            $auditChecks['single_same_jump_lane_retained'] = (Audit-Same (Audit-Sources $auditInitial) (Audit-Sources $auditFinal)) -and @(Audit-Sources $auditFinal | Where-Object { $_ -like 'jump-record-*' }).Count -eq 1
            $auditChecks['source_semantics_unmatched'] = $auditFinal.popup.text -match 'UNMATCHED SOURCE RECORD' -and $auditFinal.popup.text -match 'Linked events\s+none'
            $auditConclusions.Add('Source UID/exact time and unmatched semantics survive stream restoration with one existing jump lane.')
            $auditLimits.Add('Source-off snapshot is still loading and checkbox checked property is not captured; it does not establish a settled excluded stream.')
            $auditLimits.Add('Final restored snapshot is focused on the source log row, not a settled repeated timeline reveal. Final timeline visibility remains unobserved.')
        }
        'C009' {
            $auditBaseline = Audit-Obs $auditEntry 'matched source baseline'
            $auditCluster = Audit-Obs $auditEntry 'matched effect cluster card'
            $auditChecks['matched_row_declares_create_uid'] = $auditBaseline.row -match 'MATCHED' -and $auditBaseline.row -match 'node-a/scenario/node-a-route-create'
            $auditChecks['exact_ip_route_cluster_and_create_record'] = (Audit-Attr $auditCluster.active 'data-hover-key').StartsWith('cluster:root:node-a/control-plane/IP_ROUTE/route:blue:198.51.100.0/30:') -and $auditCluster.popup.hidden -eq $false -and $auditCluster.popup.text -match 'Scenario Resource Upsert'
            $auditChecks['normalized_create_uid_focused'] = (Audit-Attr $auditFinal.active 'data-event-uid') -ceq 'node-a/scenario/node-a-route-create'
            $auditConclusions.Add('Matched-source row names the normalized create UID; exact IP_ROUTE cluster contains its create record; normalized-log navigation focuses that UID.')
            $auditLimits.Add('Only baseline layer toggles are captured, all ON. No direct OFF-before-reveal or ON-after-reveal snapshot verifies automatic layer recovery or unrelated layer preservation.')
            $auditLimits.Add('Baseline source UID is not directly captured as an attribute; its visible matched-row facts support linkage but not the exact source000000 ID in the note.')
            $auditLimits.Add('Final focus is normalized create, but visible unpinned popup is unmatched source. Popup y478.5 is exactly 10px below that visible source row bottom468.5; ordinary pointer hover is plausible. Missing pointer/hover-target evidence prevents a stale-popup defect claim.')
        }
        'C010' {
            $auditOutcome = 'inconclusive'
            $auditFirst = Audit-Obs $auditEntry 'first history view'
            $auditSecond = Audit-Obs $auditEntry 'second history view'
            $auditChecks['two_selected_range_inputs_recorded'] = $auditFirst.range.start -ceq '350' -and $auditFirst.range.end -ceq '400' -and $auditSecond.range.start -ceq '500' -and $auditSecond.range.end -ceq '550'
            $auditChecks['explicit_recovery_activates_exact_event'] = (Audit-Attr $auditFinal.active 'data-event-uid') -ceq 'node-a/scenario/node-a-route-create' -and $auditFinal.popup.hidden -eq $false
            $auditConclusions.Add('Selected-range inputs and a later explicit exact-event recovery are recorded; no failed latest-action ownership is demonstrated.')
            $auditLimits.Add('No observed pending reveal/Back overlap; race assertion remains unexercised.')
            $auditLimits.Add('Range form fields are not the visible time window. No window-readout/zoom snapshot proves actual Back-restored viewport bounds.')
        }
        'C011' {
            $auditOutcome = 'inconclusive'
            $auditChecks['A_exact_marker_recorded'] = (Audit-Attr $auditEntry.observations[0].active 'data-event-uid') -ceq 'node-a/scenario/node-a-route-create'
            $auditChecks['B_log_row_focused'] = (Audit-Attr $auditFinal.active 'data-event-uid') -ceq 'node-a/scenario/node-a-route-delete'
            $auditChecks['final_popup_hidden'] = $auditFinal.popup.hidden -eq $true
            $auditChecks['final_cursor_is_still_A_time'] = $auditFinal.cursor -ceq '+30.000 s'
            $auditConclusions.Add('A marker and later B log focus are recorded, but B owning a visible timeline card/target is not established.')
            $auditLimits.Add('Final B latest reveal settled snapshot is an unselected log row with hidden popup and offscreen timeline, still at cursor +30 s. The note claiming latest selected cluster/card is unsupported.')
            $auditLimits.Add('No observed pending overlap or later settled B target; neither the race nor sequential final reveal success is verified. This does not distinguish missed activation, in-flight work or application failure.')
        }
        'C012' {
            $auditOutcome = 'inconclusive'
            $auditHidden = Audit-Obs $auditEntry 'newer hide settled'
            $auditTarget = 'node-a/control-plane/IP_ROUTE/route:blue:198.51.100.0/30'
            $auditChecks['target_absent_after_hide'] = $auditTarget -notin (Audit-RootIds $auditHidden)
            $auditChecks['single_target_restored'] = @(Audit-RootIds $auditFinal | Where-Object { $_ -ceq $auditTarget }).Count -eq 1
            $auditChecks['explicit_recovery_opens_target_cluster'] = (Audit-Attr $auditFinal.active 'data-hover-key').StartsWith('cluster:root:' + $auditTarget + ':') -and $auditFinal.popup.hidden -eq $false -and $auditFinal.popup.text -match 'Scenario Resource Upsert'
            $auditConclusions.Add('Recorded hide state contains no target lane, and later explicit recovery restores one correct IP_ROUTE cluster.')
            $auditLimits.Add('No observed pending allocation/reveal overlap; newer-hide-wins race is unexercised.')
            $auditLimits.Add('Initial immediate snapshot still lacks the target lane; the snapshot sequence alone does not prove a completed initial add before hide.')
        }
        'C013' {
            $auditTarget = Audit-Obs $auditEntry 'initial-target'
            $auditActivations = @($auditEntry.observations | Where-Object { $_.label -like 'activation-*' })
            $auditPicker = Audit-Obs $auditEntry 'picker-open'
            $auditChecks['initial_target_below_viewport'] = $auditTarget.rect.top -gt $auditTarget.height
            $auditChecks['four_same_cluster_pinned_activations'] = $auditActivations.Count -eq 4 -and @($auditActivations | Where-Object { (Audit-Attr $_.active 'data-hover-key') -cne $auditTarget.key -or $_.popup.hidden -ne $false -or $_.popup.cls -notmatch 'pinned' }).Count -eq 0
            $auditChecks['clipped_target_dismissed'] = (Audit-Obs $auditEntry 'anchor-fully-clipped').popup.hidden -eq $true
            $auditChecks['picker_open_then_closed'] = $auditPicker.picker.hidden -eq $false -and $auditPicker.picker.aria -ceq 'true' -and $auditFinal.picker.hidden -eq $true
            $auditChecks['final_card_is_different_unpinned_resource'] = $auditFinal.popup.cls -notmatch 'pinned' -and $auditFinal.popup.text -match '^RESOURCE STATUS' -and $auditFinal.popup.text -match 'Resource\s+backup'
            $auditConclusions.Add('Four explicit activations reopen the same cluster; clipping dismisses it and Lanes opens successfully. Scrollback shows a different unpinned backup-status hover, not revival of the original pinned cluster.')
            $auditLimits.Add('Only the first activation begins with the target below viewport. Marker rectangles after activation are not captured, so exact placement and two repeated below-viewport traversals are not established.')
            $auditLimits.Add('The final popup is visible: the no-reactivation note must refer only to the original pinned cluster, not blanket absence of all hover cards.')
        }
        'C014' {
            $auditClip = Audit-Obs $auditEntry 'first-clipping-step'
            $auditSliver = Audit-Obs $auditEntry 'positive-sliver'
            $auditChecks['exact_source_activated_enter_and_space'] = @($auditEntry.observations | Where-Object { $_.label -in @('source-Enter','source-Space') } | Where-Object { (Audit-Attr $_.active 'data-source-record-uid') -cne 'source-ctf-unmatched-000000' -or (Audit-Attr $_.active 'data-time-ns') -cne '1759680029996200000' -or $_.popup.hidden -ne $false }).Count -eq 0
            $auditChecks['full_header_clip_dismissed'] = $auditClip.anchor.bottom -lt $auditClip.header.bottom -and $auditClip.card.hidden -eq $true
            $auditChecks['positive_sliver_retains_card'] = $auditSliver.anchor.top -lt $auditSliver.header.bottom -and $auditSliver.anchor.bottom -gt $auditSliver.header.bottom -and $auditSliver.cardHidden -eq $false
            $auditChecks['visible_sliver_pixels'] = $auditSliver.anchor.bottom - $auditSliver.header.bottom
            $auditChecks['subsequent_full_clip_and_scrollbacks_hidden'] = @($auditEntry.observations | Where-Object { $_.label -in @('scrollback-after-full-clip','full-clip','return-no-revival') } | Where-Object { $_.popup.hidden -ne $true }).Count -eq 0
            $auditConclusions.Add('Exact source activation works; the measured 9.57 px positive sliver retains the card, full header clipping dismisses it, and captured scrollbacks remain dismissed.')
            $auditLimits.Add('Initial keyboard traversal from controls above the source is not recorded. Positive-sliver snapshot records visibility rather than a simultaneous complete card placement rectangle.')
        }
        'C015' {
            $auditOutcome = 'inconclusive'
            $auditInitial = Audit-Obs $auditEntry 'density-focused'
            $auditAway = Audit-Obs $auditEntry 'density-wheel-away'
            $auditStable = Audit-Obs $auditEntry 'passive-stability'
            $auditChecks['same_density_key_at_return'] = (Audit-Attr $auditInitial.active 'data-hover-key') -ceq (Audit-Attr $auditFinal.active 'data-hover-key')
            $auditChecks['away_and_passive_card_hidden'] = $auditAway.popup.hidden -eq $true -and $auditStable.hidden -eq $true
            $auditChecks['passive_document_and_nested_scroll_unchanged'] = $auditStable.window -eq $auditAway.window.y -and $auditStable.scroll -eq ($auditAway.scrolls | Where-Object id -eq 'timeline-scroll').top
            $auditChecks['explicit_return_opens_card'] = $auditFinal.popup.hidden -eq $false
            $auditConclusions.Add('Captured wheel-away/passive states remain dismissed without scroll movement, and explicit activation reopens the same density key.')
            $auditLimits.Add('No density-row replacement or reconstruction provenance is captured, so the replacement-specific assertion remains unexercised. These snapshots do not prove all intervening frames stayed unchanged.')
        }
        'C016' {
            $auditOutcome = 'inconclusive'
            $auditInitial = Audit-Obs $auditEntry 'immediate-resource-activation'
            $auditAway = Audit-Obs $auditEntry 'resource-wheel-away'
            $auditStable = Audit-Obs $auditEntry 'after-detail-settle'
            $auditChecks['same_exact_recreate_uid'] = (Audit-Attr $auditInitial.active 'data-event-uid') -ceq 'node-a/scenario/node-a-route-recreate' -and (Audit-Attr $auditFinal.active 'data-event-uid') -ceq 'node-a/scenario/node-a-route-recreate'
            $auditChecks['away_and_passive_card_hidden'] = $auditAway.popup.hidden -eq $true -and $auditStable.cardHidden -eq $true
            $auditChecks['passive_document_and_nested_scroll_unchanged'] = $auditStable.window -eq $auditAway.window.y -and $auditStable.scroll -eq ($auditAway.scrolls | Where-Object id -eq 'timeline-scroll').top
            $auditChecks['explicit_return_opens_card'] = $auditFinal.popup.hidden -eq $false
            $auditConclusions.Add('Exact recreate event survives scroll-away and deliberate return; the captured passive state does not reopen its card or move either scroll position.')
            $auditLimits.Add('No initial pending graph/detail request or subsequent row replacement is observed. An empty pending array at the last passive snapshot does not establish completion of previously pending work.')
        }
        'C017' {
            $auditInitial = Audit-Obs $auditEntry 'source-row-pointer-card'
            $auditClipped = Audit-Obs $auditEntry 'log-fully-clipped'
            $auditLog = $auditInitial.scrolls | Where-Object id -eq 'event-log-scroll'
            $auditClippedRow = $auditClipped.logRows | Where-Object source -eq 'source-ctf-matched-000000'
            $auditChecks['initial_matched_source_hover'] = $auditInitial.popup.hidden -eq $false -and $auditInitial.popup.text -match '^MATCHED SOURCE RECORD' -and $auditInitial.popup.text -match 'node-a/scenario/node-a-route-create'
            $auditChecks['no_horizontal_overflow'] = $auditLog.width -eq $auditLog.scrollWidth
            $auditChecks['original_source_row_fully_outside_log_view'] = ($auditClippedRow.rect.y + $auditClippedRow.rect.h) -lt ($auditClipped.scrolls | Where-Object id -eq 'event-log-scroll').rect.y
            $auditChecks['captured_cards_all_unpinned'] = @($auditEntry.observations | Where-Object { $_.popup.cls -match 'pinned' }).Count -eq 0
            $auditChecks['scrollback_restores_log_top'] = ($auditFinal.scrolls | Where-Object id -eq 'event-log-scroll').top -eq 0
            $auditConclusions.Add('Vertical log movement and current-row hover cards are observed; the original matched-source row becomes fully clipped, and scrollback returns the log to top.')
            $auditLimits.Add('All captured cards are unpinned and change to other hovered rows during scrolling. No hidden-card snapshot or stable same-anchor positive-sliver sample establishes pinned dismissal/no-revival behavior.')
            $auditLimits.Add('Horizontal scrollWidth equals clientWidth at 1158 px; horizontal overflow/clipping is unexercised. Sticky log-header rectangle is not captured for exact partial-visibility adjudication.')
            $auditLimits.Add('Final explicit reopen shows the normalized linked event, not the original matched-source card; identity claims must distinguish those two records.')
        }
        'C018' {
            $auditOld = Audit-Obs $auditEntry 'pageable-cluster'
            $auditInitial = Audit-Obs $auditEntry 'initial-exact-page'
            $auditLoaded = Audit-Obs $auditEntry 'second-page-loaded'
            $auditPicker = Audit-Obs $auditEntry 'picker-dismisses-loaded-card'
            $auditNew = Audit-Obs $auditEntry 'new-layout-cluster'
            $auditReloaded = Audit-Obs $auditEntry 'layout-new-page-loaded'
            $auditChecks['initial_100_then_107_unique_exact_events'] = $auditInitial.popup.text -match '100 of 107 exact events loaded' -and $auditLoaded.progress -ceq '107 of 107 exact events loaded' -and @($auditLoaded.ids | Select-Object -Unique).Count -eq 107 -and $auditLoaded.hidden -eq $false -and $auditLoaded.scroll -gt 0
            $auditChecks['picker_intentionally_dismisses_loaded_card'] = $auditPicker.popup.hidden -eq $true -and $auditPicker.picker.hidden -eq $false
            $auditChecks['same_occurrence_new_cluster_model'] = ($auditOld.key -split '::server-v2::')[0] -ceq ($auditNew.key -split '::server-v2::')[0] -and $auditOld.key -cne $auditNew.key -and $auditNew.n -eq 104
            $auditChecks['new_104_exact_rows_are_prefix_of_old_page'] = $auditReloaded.progress -ceq '104 of 104 exact events loaded' -and (Audit-Same @($auditLoaded.ids | Select-Object -First 104) @($auditReloaded.rows | ForEach-Object id))
            $auditChecks['reopen_uses_new_model_with_loaded_pages'] = (Audit-Attr $auditFinal.active 'data-hover-key') -ceq $auditNew.key -and $auditFinal.popup.hidden -eq $false -and $auditFinal.popup.text -match '104 of 104 exact events loaded'
            $auditConclusions.Add('107 exact events load with nonzero detail scroll. Picker dismissal separates the old card from the new 104-event model on the same occurrence; its loaded rows are the matching old-page prefix, and explicit reopen retains all 104.')
            $auditLimits.Add('No focus/scroll preservation is claimed across intentional dismissal or changed aggregation model. Initial loaded-page focus is the Close button, not the removed pagination control; simultaneous marker/card placement rectangles are not captured.')
            $auditLimits.Add('The new model first-page count of 100 is stated in the action note, but no intermediate new-model 100-row snapshot was saved; the final 104-row result is directly verified.')
        }
        'C019' {
            $auditInitial = Audit-Obs $auditEntry 'initial-paged-cluster'
            $auditPartial = Audit-Obs $auditEntry 'partial-range'
            $auditClear = Audit-Obs $auditEntry 'clear-range'
            $auditOutside = Audit-Obs $auditEntry 'outside-range'
            $auditChecks['104_uid_time_pairs_preserved_all_updates'] = @($auditEntry.observations | Where-Object rows | Where-Object { $_.progress -cne '104 of 104 exact events loaded' -or -not (Audit-Same @($_.rows | Select-Object id,time) @($auditInitial.rows | Select-Object id,time)) }).Count -eq 0
            $auditChecks['partial_membership_matches_exact_timestamp'] = @($auditPartial.rows | Where-Object { $auditHit=([decimal]$_.time -ge [decimal]'1759680239996000000' -and [decimal]$_.time -le [decimal]'1759680242996000000'); (($_.cls -match '(^| )in-range( |$)') -ne $auditHit) -or (($_.text -match ' / in selected range') -ne $auditHit) }).Count -eq 0
            $auditChecks['clear_removes_all_membership_labels'] = @($auditClear.rows | Where-Object { $_.cls -match 'in-range|out-of-range' -or $_.text -match 'selected range' }).Count -eq 0
            $auditChecks['outside_labels_correct_before_and_after_reopen'] = @(@($auditOutside.rows) + @($auditFinal.rows) | Where-Object { $_.text -notmatch ' / outside selected range' -or $_.cls -match '(^| )in-range( |$)' }).Count -eq 0 -and $auditFinal.hidden -eq $false
            $auditChecks['initial_positive_scroll_and_later_dismissal'] = (Audit-Obs $auditEntry 'loaded-scroll-baseline').scroll -gt 0 -and $auditPartial.hidden -eq $true -and $auditPartial.scroll -eq 0
            $auditConclusions.Add('All 104 exact UID/time pairs and loaded-page count survive partial/Clear/outside updates. Partial membership matches each exact timestamp, and reopened outside-range text remains correct.')
            $auditLimits.Add('Range controls dismiss the initial card; continuous-open focus/scroll preservation is unexercised. The partial/outside samples before reopen are hidden retained DOM.')
            $auditLimits.Add('In-place outside rows have out-of-range classes; reopening emits plain cluster-event with the correct outside suffix. app.js:4892 emits only in-range, while the updater toggles out-of-range. No observed visible failure is established because cluster-specific styling targets in-range, but exact class equality must not be claimed.')
        }
        'C020' {
            $auditInitial = Audit-Obs $auditEntry 'source-cluster-open'
            $auditOutside = Audit-Obs $auditEntry 'range-700'
            $auditInside = Audit-Obs $auditEntry 'range-119'
            $auditClear = Audit-Obs $auditEntry 'cleared'
            $auditAvailability = Audit-Obs $auditEntry 'clear-repeat-availability'
            $auditChecks['source_cluster_initial_and_reopened_same'] = (Audit-Attr $auditInitial.active 'data-hover-key') -ceq (Audit-Attr $auditFinal.active 'data-hover-key') -and $auditFinal.popup.hidden -eq $false
            $auditChecks['outside_summary_zero'] = $auditOutside.range.start -ceq '700' -and $auditOutside.range.end -ceq '710' -and $auditOutside.range.facts -match '^0 events'
            $auditChecks['inside_hidden_dom_has_36_membership_suffixes'] = [regex]::Matches($auditInside.popup.text, 'in selected range').Count -eq 36
            $auditChecks['clear_removes_membership_suffixes'] = -not $auditClear.range.start -and -not $auditClear.range.end -and $auditFinal.popup.text -notmatch 'in selected range' -and $auditFinal.popup.text -match '36 records'
            $auditChecks['repeat_clear_hidden'] = $auditAvailability.hidden -eq $true
            $auditConclusions.Add('Outside/inside range summaries update, hidden source-card DOM receives 36 in-range suffixes, and reopening after Clear shows the same 36-record cluster without suffixes.')
            $auditLimits.Add('Original card is dismissed during range-control scrolling, so continuous-open placement, focus, scroll preservation and a second full outside/inside/Clear cycle are unexercised.')
            $auditLimits.Add('Repeat Clear is hidden, not disabled: recorded disabled=false and hidden=true. Hidden card text is retained DOM evidence, not visible UI.')
        }
        'C021' {
            $auditGrouped = Audit-Obs $auditEntry 'grouped-review-card'
            $auditBack = Audit-Obs $auditEntry 'review-after-back'
            $auditNormalized = Audit-Obs $auditEntry 'review-normalized-to-log'
            $auditSource = Audit-Obs $auditEntry 'review-source-to-log'
            $auditChecks['grouped_card_names_both_exact_marks'] = $auditGrouped.popup.hidden -eq $false -and $auditGrouped.popup.text -match 'event:node-a/scenario/node-a-route-create' -and $auditGrouped.popup.text -match 'source:source-ctf-unmatched-000000'
            $auditChecks['after_back_visible_mark_is_normalized'] = $auditBack.marks.Count -eq 1 -and $auditBack.marks[0].id -ceq 'event:node-a/scenario/node-a-route-create'
            $auditChecks['exact_annotation_children_focused'] = (Audit-Attr $auditNormalized.active 'data-annotation-entry-id') -ceq 'event:node-a/scenario/node-a-route-create' -and (Audit-Attr $auditSource.active 'data-annotation-entry-id') -ceq 'source:source-ctf-unmatched-000000'
            $auditChecks['applied_one_ns_range_preserved'] = $auditNormalized.range.start -ceq '30' -and $auditNormalized.range.end -ceq '30.000000001' -and (Audit-Same $auditNormalized.range $auditSource.range)
            $auditChecks['original_cleanup_marker_count'] = (Audit-Obs $auditEntry 'cleanup-review').markers
            $auditClarificationRaw = @(Get-Content -LiteralPath (Join-Path $PSScriptRoot 'supplement-clarifications.jsonl'))
            $auditCleanup = $auditClarificationRaw | ForEach-Object { $_ | ConvertFrom-Json } | Where-Object { $_.id -ceq 'C021' -and $_.label -ceq 'cleanup-retry' } | Select-Object -Last 1
            for ($auditClarificationIndex=0; $auditClarificationIndex -lt $auditClarificationRaw.Count; $auditClarificationIndex++) {
                $auditClarification = $auditClarificationRaw[$auditClarificationIndex] | ConvertFrom-Json
                if ($auditClarification.id -ceq 'C021' -and $auditClarification.label -ceq 'cleanup-retry' -and $auditClarification.utc -ceq $auditCleanup.utc) {
                    $auditCleanupSha = [Security.Cryptography.SHA256]::Create()
                    $auditCleanupDigest = [Convert]::ToHexString($auditCleanupSha.ComputeHash([Text.Encoding]::UTF8.GetBytes($auditClarificationRaw[$auditClarificationIndex]))).ToLowerInvariant()
                    $auditCleanupSha.Dispose()
                    $auditAdditionalSources = @([ordered]@{path='supplement-clarifications.jsonl';line=$auditClarificationIndex+1;raw_record_sha256=$auditCleanupDigest;label=$auditCleanup.label;utc=$auditCleanup.utc})
                }
            }
            $auditChecks['later_cleanup_has_no_review_marks'] = $null -ne $auditCleanup -and @($auditCleanup.review).Count -eq 0
            $auditChecks['cleanup_retry_utc'] = $auditCleanup.utc
            $auditConclusions.Add('Both exact review identities are retained in the grouped card; the zoomed Back view contains the normalized mark and preserves its 1 ns selected range. Later supplemental cleanup records no review marks.')
            $auditConclusions.Add('No log-jump defect is established: frontend/assets/app.js:5072-5083 annotation child handlers call selectEvent/selectSourceRecord with moveCursor=true and do not implement modifier-key log navigation.')
            $auditLimits.Add('Common snapshots omit inspector text and round both 30 s and 30.0002 s cursor values to +30.000 s. Exact cursor movement and inspector selection are source-supported behavior, not independently verified browser outcomes here.')
            $auditLimits.Add('Requested review-to-log roundtrip and hidden underlying-mark flags are not exercised. Source outside the zoomed visible window is not evidence that its local review mark was deleted.')
            $auditLimits.Add('Original cleanup-review records one remaining mark; final cleanup evidence is separate supplement-clarifications.jsonl C021 cleanup-retry at ' + $auditCleanup.utc + '. Toolbar still has one selected row, which is distinct from a retained review mark.')
        }
        'C022' {
            $auditInitial = Audit-Obs $auditEntry 'valid-card-baseline'
            $auditInvalid = Audit-Obs $auditEntry 'invalid-range-facts'
            $auditRecovery = Audit-Obs $auditEntry 'recovered-card'
            $auditChecks['invalid_draft_rejected_old_applied_scope_retained'] = $auditInvalid.start -ceq 'not-a-time' -and $auditInvalid.error -match 'up to 9 decimal places' -and $auditInvalid.facts -ceq $auditInitial.range.facts -and $auditInvalid.title -ceq $auditInitial.range.title
            $auditChecks['recovery_same_cluster_with_ten_selected_rows'] = (Audit-Attr $auditInitial.active 'data-hover-key') -ceq (Audit-Attr $auditRecovery.active 'data-hover-key') -and $auditRecovery.popup.hidden -eq $false -and $auditRecovery.range.start -ceq '120' -and $auditRecovery.range.end -ceq '121' -and [regex]::Matches($auditRecovery.popup.text, 'in selected range').Count -eq 10
            $auditChecks['clear_updates_visible_card'] = $auditFinal.popup.hidden -eq $false -and $auditFinal.popup.text -notmatch 'in selected range' -and -not $auditFinal.range.start -and -not $auditFinal.range.end
            $auditConclusions.Add('Malformed draft leaves the applied 119-160 s range and facts intact. Valid 120-121 s recovery marks the first ten source rows, and Clear removes suffixes while the reopened card remains visible.')
            $auditLimits.Add('The original card is dismissed during invalid-draft form scrolling; preservation of an already open card through malformed submission is not established.')
        }
        'C023' {
            $auditExact = Audit-Obs $auditEntry 'exact-range-inputs'
            $auditReopened = Audit-Obs $auditEntry 'same-source-reopened'
            $auditChecks['one_ns_inputs_retained_at_zoom_fit_back'] = @($auditEntry.observations | Where-Object { $_.label -in @('one-nanosecond-range-zoom','fit-retains-range','back-retains-range') } | Where-Object { $_.range.start -cne '30.0002' -or $_.range.end -cne '30.000200001' -or $_.range.title -notmatch '1 ns$' }).Count -eq 0
            $auditChecks['exact_source_uid_ns_and_in_range_class'] = (Audit-Attr $auditReopened.active 'data-source-record-uid') -ceq 'source-ctf-unmatched-000000' -and (Audit-Attr $auditReopened.active 'data-time-ns') -ceq '1759680029996200000' -and $auditReopened.active -match ' in-range' -and $auditReopened.popup.hidden -eq $false
            $auditChecks['exact_final_input_end_minus_start_is_one_ns'] = ([decimal]$auditExact.end - [decimal]$auditExact.start) -eq [decimal]'0.000000001'
            $auditConclusions.Add('A 1 ns range beginning exactly at the source timestamp survives Fit/Back, and the same exact source UID/time reopens with in-range styling.')
            $auditLimits.Add('The source is at +30 s within a 720 s capture, not at a capture endpoint. Exact viewport bounds before/after Fit/Back and subpixel geometry are not captured by common range-input snapshots.')
        }
        'C024' {
            $auditInitial = Audit-Obs $auditEntry 'scope-baseline'
            $auditOff = Audit-Obs $auditEntry 'ctf-off'
            $auditSearch = Audit-Obs $auditEntry 'exact-source-search'
            $auditRestored = Audit-Obs $auditEntry 'search-cleared'
            $auditChecks['selected_period_changes_three_to_one_log_records'] = $auditInitial.rows -match '3 matching records' -and $auditOff.rows -match '1 matching record' -and $auditInitial.log -match '^1,252,505 ' -and $auditOff.log -match '^1,250,005 '
            $auditChecks['range_facts_unchanged_across_log_filters'] = $auditInitial.range -ceq $auditOff.range -and $auditInitial.range -ceq $auditSearch.range.facts -and $auditInitial.range -ceq $auditRestored.range.facts
            $auditChecks['search_yields_exact_source_only'] = @($auditSearch.logRows).Count -eq 1 -and $auditSearch.logRows[0].source -ceq 'source-ctf-unmatched-000000' -and $auditSearch.logStatus -match '^1 matching records'
            $auditChecks['source_and_normalized_restored'] = 'source-ctf-unmatched-000000' -in @($auditRestored.logRows | ForEach-Object source) -and 'node-a/scenario/node-a-route-create' -in @($auditRestored.logRows | ForEach-Object event) -and $auditRestored.logStatus -ceq $auditInitial.log
            $auditChecks['clear_removes_range_without_stale_selection'] = -not $auditFinal.range.start -and -not $auditFinal.range.end -and -not $auditFinal.range.facts -and $auditFinal.selectionCount -ceq 'No rows selected' -and $auditFinal.logStatus -ceq $auditInitial.log
            $auditConclusions.Add('CTF exclusion changes selected-period log rows from three to one and the total from 1,252,505 to 1,250,005, while normalized-event range facts stay constant. Exact search, stream restoration and Clear preserve expected identities and leave no selected-row toolbar state.')
            $auditLimits.Add('Checkbox checked properties are not captured, so stream inclusion is verified through settled counts and returned records. Final Clear snapshot has the log offscreen; it verifies DOM state rather than final log viewport visibility.')
        }
        'C025' {
            $auditTarget='node-a/control-plane/NEIGHBOR/blue/peer-00000'
            foreach($auditCycle in 0..3) {
                $auditToggle=Audit-Obs $auditEntry ('checkbox-'+$auditCycle)
                $auditExpected=($auditCycle % 2)-eq 1
                $auditChecks['checkbox_'+$auditCycle+'_identity_presence_focus'] = $auditToggle.checked -eq $auditExpected -and (($auditTarget -in @($auditToggle.roots)) -eq $auditExpected) -and (Audit-Attr $auditToggle.active 'data-lane-toggle') -ceq $auditTarget
                $auditChecks['checkbox_'+$auditCycle+'_lane_count'] = $auditToggle.lanes -ceq $(if($auditExpected){'Lanes 14 / 7,510 · 3 logs'}else{'Lanes 13 / 7,510 · 3 logs'})
            }
            $auditChecks['picker_checked_and_same_dashboard_resource_focused'] = (Audit-Obs $auditEntry 'picker-checkbox').checked -eq $true -and (Audit-Attr $auditFinal.active 'data-dashboard-resource-id') -ceq $auditTarget
            $auditConclusions.Add('Two off/on cycles preserve exact checkbox focus and agree with target lane presence and 13/14 counts; picker and dashboard action identify the same canonical resource.')
            $auditLimits.Add('Toggle samples capture only the target root, not all unrelated lane identities. Dashboard focus identifies its activated link; selected-resource inspector state is not separately sampled.')
        }
        'C026' {
            $auditInitial=Audit-Obs $auditEntry 'child-detail-capture'
            $auditHome=Audit-Obs $auditEntry 'home-bundle'
            $auditRestore=Audit-Obs $auditEntry 'child-through-parent-restored'
            $auditBody=-join @($auditRestore.PSObject.Properties | Where-Object Name -match '^\d+$' | Sort-Object {[int]$_.Name} | ForEach-Object Value)
            $auditChecks['initial_and_restored_child_canonical_owns_facts'] = @($auditInitial.body,$auditBody | Where-Object { $_ -notmatch 'RESOURCE ID\s+node-a/data-bridge-layer/ETE/etg-000000/backup' -or $_ -notmatch 'RELATIONSHIP\s+owns' -or $_ -notmatch 'STATUS\s+standby' -or $_ -notmatch 'KEY · PARENT RESOURCE ID\s+node-a/data-bridge-layer/ETG/blue/etg-000000' }).Count -eq 0
            $auditChecks['home_honest_empty_population'] = $auditHome.cursor -ceq '+0.000 s' -and $auditHome.body -ceq 'No active resource bundles match this moment and search.'
            $auditChecks['final_flat_ete_tab_at_capture'] = (Audit-Attr $auditFinal.active 'data-kind') -ceq 'ETE' -and (Audit-Attr $auditFinal.active 'aria-selected') -ceq 'true' -and $auditFinal.cursor -ceq 'capture'
            $auditConclusions.Add('Backup ETE detail retains its canonical child identity, standby state and owns relationship; Home reports no active bundles and the final flat ETE tab is selected at capture time.')
            $auditLimits.Add('Restored body was accidentally spread into numeric character properties; review reconstructs it by numeric order. That observation lacks an explicit cursor and focused disclosure control. Final flat-table row/inspector identity is not captured.')
        }
        'C027' {
            $auditInitial=Audit-Obs $auditEntry 'dashboard-baseline'
            $auditSelect=Audit-Obs $auditEntry 'dashboard-DTE-selected'
            $auditReveal=Audit-Obs $auditEntry 'related-event-reveal'
            $auditChecks['dashboard_canonical_dte_activated'] = (Audit-Attr $auditSelect.active 'data-dashboard-resource-id') -ceq 'node-a/data-bridge-layer/DTE/blue/dte-000000'
            $auditChecks['exact_related_event_activated_at_120'] = (Audit-Attr $auditReveal.active 'data-event-uid') -ceq 'node-a/scale-event-00000000' -and $auditReveal.cursor -ceq '+120.000 s'
            $auditChecks['archive_metrics_keep_explicit_scope'] = @($auditInitial.body,$auditFinal.body | Where-Object { $_ -notmatch 'Dte\s+1,875\s+Plug-in-precomputed archive metric · not point-in-time' }).Count -eq 0
            $auditChecks['population_labels_follow_changed_cursor'] = $auditInitial.status -ceq 'authoritative population at +720.000 s' -and $auditFinal.status -ceq 'authoritative population at +120.000 s' -and $auditFinal.body -match '3 resources · authoritative population'
            $auditConclusions.Add('The dashboard DTE action and exact related event UID are recorded. Returning at the event time shows a three-resource point-in-time population while archive metric DTE=1,875 keeps its explicit non-point-in-time label.')
            $auditLimits.Add('Event activation occurs on the canonical primary NEIGHBOR occurrence; DTE effect linkage and selected inspector are not explicitly sampled in this case. Actual population changes with cursor, so baseline and return totals are not supposed to be equal.')
        }
        'C028' {
            $auditInitial=Audit-Obs $auditEntry 'baseline'
            $auditChecks['four_registered_modules_through_cycles'] = @($auditEntry.observations | Where-Object { @($_.index).Count -ne 4 -or -not (Audit-Same @($_.index.id | Sort-Object) @($auditInitial.index.id | Sort-Object)) }).Count -eq 0
            $auditChecks['open_count_agrees_rendered_modules'] = @($auditEntry.observations | Where-Object { @($_.index | Where-Object open -eq 'true').Count -ne @($_.modules).Count }).Count -eq 0
            $auditChecks['closed_cycles_two_open_restored_three_open'] = @((Audit-Obs $auditEntry 'closed-reordered-home').modules).Count -eq 2 -and @((Audit-Obs $auditEntry 'keyboard-closed-home').modules).Count -eq 2 -and @($auditFinal.modules).Count -eq 3
            $auditChecks['home_and_end_attribution_recorded'] = (Audit-Obs $auditEntry 'reopened-home').status -ceq 'authoritative population at +0.000 s' -and $auditFinal.status -ceq 'authoritative population at +720.000 s'
            $auditChecks['final_order'] = @($auditFinal.index | ForEach-Object id)
            $auditConclusions.Add('Both cycles keep four registered modules with coherent two/three open counts and honest Home/End population labels.')
            $auditLimits.Add('Exact original ordering is not restored: baseline scale-overview, forwarding-population, event-phases, neighbor-health; final scale-overview, neighbor-health, forwarding-population, event-phases. This may reflect the performed Move operations; no ignored-action defect is demonstrated.')
            $auditLimits.Add('Original cursor +120 s becomes capture End +720 s, not exact cursor restoration. Snapshots do not separately prove keyboard versus pointer event delivery or focus recovery.')
        }
        'C029' {
            $auditOutcome='inconclusive'
            $auditInitial=Audit-Obs $auditEntry 'authoritative-baseline'
            $auditFiltered=Audit-Obs $auditEntry 'no-match-reopen'
            $auditKinds=Audit-Obs $auditEntry 'filtered-kind-availability'
            $auditChecks['dashboard_body_and_scope_unchanged'] = $auditInitial.body -ceq $auditFiltered.body -and $auditInitial.body -ceq $auditFinal.body -and $auditInitial.status -ceq $auditFinal.status
            $auditChecks['no_match_only_selected_kind_available'] = $auditKinds.body -ceq 'No resources match this view.' -and (Audit-Same @($auditKinds.kinds) @('NEIGHBOR'))
            $auditConclusions.Add('No-match resource state coexists with unchanged dashboard body and +30 s attribution; only NEIGHBOR is exposed as a kind during the filter.')
            $auditLimits.Add('Planned kind switch while no-match is not performed. The final snapshot is dashboard-only, so subsequent DTE recovery is stated in the note but not directly captured.')
            $auditLimits.Add('Baseline point-in-time populations are already zero. This does not establish preservation of a nonempty authoritative population under resource filtering; archive metrics remain unchanged and explicitly labelled.')
        }
        'C030' {
            $auditOutcome='inconclusive'
            $auditMissing=Audit-Obs $auditEntry 'unavailable-dashboard-target'
            $auditNeighbor=Audit-Obs $auditEntry 'latest-neighbor'
            $auditChecks['home_target_unavailable_at_30s'] = $auditMissing.cursor -ceq '+30.000 s' -and $auditMissing.status -ceq 'authoritative population at +30.000 s'
            $auditChecks['two_exact_dashboard_links_activated_at_capture'] = (Audit-Attr $auditNeighbor.active 'data-dashboard-resource-id') -ceq 'node-a/control-plane/NEIGHBOR/blue/peer-00000' -and (Audit-Attr $auditFinal.active 'data-dashboard-resource-id') -ceq 'node-a/data-bridge-layer/DTE/blue/dte-000000' -and $auditFinal.cursor -ceq 'capture'
            $auditConclusions.Add('At capture time the exact NEIGHBOR and DTE dashboard links are focused in sequence; the earlier +30 s target absence is consistent with recorded point-in-time population.')
            $auditLimits.Add('No actual overlapping resource query/pending state, returned resource rows, schema or inspector identity is captured. Link focus alone does not verify final query ownership; race remains unexercised.')
        }
        'C031' {
            $auditHome=Audit-Obs $auditEntry 'follow-home-immediate'
            $auditEnd=Audit-Obs $auditEntry 'follow-end-immediate'
            $auditDisabled=Audit-Obs $auditEntry 'follow-disabled'
            $auditChecks['follow_home_and_end_drafts_change'] = $auditHome.follow -eq $true -and $auditEnd.follow -eq $true -and $auditHome.absolute -ceq '1759679999996000000' -and $auditEnd.absolute -ceq '1759680719996000000'
            $auditChecks['disabled_follow_unsent_draft_does_not_relabel_result'] = $auditFinal.follow -eq $false -and $auditFinal.absolute -ceq '1759680000996000000' -and $auditFinal.summary -ceq $auditDisabled.summary -and $auditFinal.times -ceq $auditDisabled.times -and $auditFinal.summary -match '1759680719996000000 ns'
            $auditConclusions.Add('Follow toggles update Home/End draft times, and after follow is disabled an unsent +1 s draft leaves the returned capture-End attribution unchanged.')
            $auditLimits.Add('Sampler omits pending/busy state and explicit applied-versus-draft chrome. Immediate samples show the prior result summary beside new draft fields, but do not establish stale-result misattribution or actual overlapping requests. No later idle result-ownership observation is recorded.')
        }
        'C032' {
            $auditInitial=Audit-Obs $auditEntry 'explicit-relative-result'
            $auditJump=Audit-Obs $auditEntry 'after-log-jump'
            $auditChecks['explicit_relative_follow_off_through_jump_and_resubmit'] = @($auditEntry.observations | Where-Object { $_.follow -ne $false -or $_.basis -cne 'relative_to_watermark' -or $_.relative -cne '-5' -or $_.summary -cne $auditInitial.summary -or $_.times -cne $auditInitial.times }).Count -eq 0
            $auditChecks['cursor_changes_independently'] = $auditInitial.cursor -ceq 'capture' -and $auditJump.cursor -ceq '+30.000 s' -and $auditFinal.cursor -ceq '+30.000 s'
            $auditConclusions.Add('Explicit -5 s relative topology and exact returned layer times remain unchanged while the timeline moves from capture End to +30 s, including the recorded resubmission outcome.')
            $auditLimits.Add('Submit busy transition/request identity is not captured; identical final attribution verifies retained/resolved scope but cannot alone prove a fresh backend request. Exact log-event identity is outside this topology-only sampler.')
        }
        'C033' {
            $auditInvalid=Audit-Obs $auditEntry 'invalid-relative-draft'
            $auditRecovery=Audit-Obs $auditEntry 'recovered-across-sections'
            $auditChecks['invalid_draft_rejected_previous_result_retained'] = $auditInvalid.relative -ceq 'bad-time' -and $auditInvalid.error -match 'signed seconds with up to 9 decimal places' -and $auditInvalid.summary -match '-5.000 s'
            $auditChecks['valid_recovery_and_repeat_coherent'] = @($auditRecovery,$auditFinal | Where-Object { $_.relative -cne '-10' -or $_.projection -cne 'plugin.underlay-connectivity' -or $_.perspective -cne 'control-plane' -or $_.error -or $_.summary -notmatch '-10.000 s' -or $_.times -notmatch 'node-a-control-plane-raw' }).Count -eq 0 -and $auditRecovery.times -ceq $auditFinal.times
            $auditConclusions.Add('Invalid relative draft produces precise validation while retaining the old -5 s result. Recovery and repeat show the requested -10 s underlay/control-plane result with cleared error and matching layer times.')
            $auditLimits.Add('Section navigation and request pending transitions are described in actions but not independently sampled; final returned attribution is directly captured.')
        }
        'C034' {
            $auditInitial=Audit-Obs $auditEntry 'route-first'
            $auditTopology=Audit-Obs $auditEntry 'unrelated-selection-and-query'
            $auditChecks['same_advertised_route_and_returned_result'] = $auditInitial.choice -ceq 'node-a/route/all-active-ecmp' -and $auditFinal.choice -ceq $auditInitial.choice -and $auditFinal.result -ceq $auditInitial.result -and $auditFinal.attribution -ceq $auditInitial.attribution
            $auditChecks['node_local_observed_capture_scope'] = $auditFinal.result -match 'Observed Capture Vector' -and $auditFinal.result -match 'returned for \+610.001 s' -and $auditFinal.result -match 'observed_capture_vector / exact / resolved'
            $auditChecks['intervening_explicit_topology_scope'] = $auditTopology.follow -eq $false -and $auditTopology.relative -ceq '-10' -and $auditTopology.projection -ceq 'plugin.underlay-connectivity'
            $auditConclusions.Add('The same advertised node-local ECMP route returns identical two-next-hop resolution and observed-capture attribution around the explicit topology operation.')
            $auditLimits.Add('Intermediate sample omits the advertised unrelated dashboard resource identity/selection. No route pending transition or request identity is captured; identical result alone does not verify two fresh submissions. Cursor was moved to End, while declared route observed-capture time remains +610.001 s.')
        }
        'C035' {
            $auditInitial = $auditEntry.observations[0]
            $auditReturn = Audit-Obs $auditEntry 'Return context restored before trace'
            $auditChecks['controls_restored_before_explicit_trace'] = Audit-Same $auditInitial.controls $auditReturn.controls
            $auditChecks['final_controls_exact'] = Audit-Same $auditInitial.controls $auditFinal.controls
            $auditChecks['final_url_exact'] = $auditInitial.url -ceq $auditFinal.url
            $auditChecks['outcome_and_paths_restored'] = $auditInitial.comparison -ceq $auditFinal.comparison -and $auditInitial.paths -ceq $auditFinal.paths
            $auditChecks['final_trace_settled'] = $auditFinal.busy -eq $false -and $auditFinal.comparisonHidden -eq $false -and $auditFinal.emptyHidden -eq $true -and -not $auditFinal.error
            $auditConclusions.Add('Recorded fabric Return configuration/outcome survives actual loaded-member Back navigation after node-local log selection and lane disclosure.')
            $auditLimits.Add('Node log snapshot does not capture a settled exact target glyph in the viewport; later lane work and context preservation are supported separately.')
            $auditLimits.Add('Return-before-trace is still initialization-busy but has no result; final explicit trace is settled. Reconstruction uses best_effort, not original Strict B0 baseline.')
        }
        'C036' {
            $auditInitial=Audit-Obs $auditEntry 'loop-baseline'
            $auditAfterIdle=Audit-Obs $auditEntry 'after-idle'
            $auditIdleStart=Audit-Obs $auditEntry 'idle-start'
            $auditIdleEnd=Audit-Obs $auditEntry 'idle-end'
            $auditTimed=@($auditEntry.observations | Where-Object {$_.PSObject.Properties.Name -contains 'actionToObservationMs'})
            foreach($auditCycle in 1..3) {
                $auditLog=Audit-Obs $auditEntry ('loop'+$auditCycle+'-timeline-to-log')
                $auditReveal=Audit-Obs $auditEntry ('loop'+$auditCycle+'-reveal')
                $auditHide=Audit-Obs $auditEntry ('loop'+$auditCycle+'-hide-lane')
                $auditRestore=Audit-Obs $auditEntry ('loop'+$auditCycle+'-restore-lane')
                $auditSettled=Audit-Obs $auditEntry ('loop'+$auditCycle+'-settled')
                $auditChecks['cycle_'+$auditCycle+'_same_exact_event_log_and_timeline'] = (Audit-Attr $auditLog.active 'data-event-uid') -ceq 'node-a/scale-event-00000000' -and (Audit-Attr $auditReveal.active 'data-event-uid') -ceq 'node-a/scale-event-00000000' -and (Audit-Attr $auditReveal.active 'data-time-ns') -ceq '1759680119996000000'
                $auditChecks['cycle_'+$auditCycle+'_lane_toggle_count_and_control'] = $auditHide.lanes -ceq 'Lanes 13 / 7,510 · 3 logs' -and $auditRestore.lanes -ceq 'Lanes 14 / 7,510 · 3 logs' -and (Audit-Attr $auditHide.active 'data-lane-toggle') -ceq 'node-a/control-plane/NEIGHBOR/blue/peer-00000' -and $auditHide.active -notmatch 'checked=' -and $auditRestore.active -match 'checked='
                $auditChecks['cycle_'+$auditCycle+'_all_original_roots_and_sources_retained'] = (Audit-Same (Audit-RootIds $auditInitial) (Audit-RootIds $auditSettled)) -and (Audit-Same (Audit-Sources $auditInitial) (Audit-Sources $auditSettled))
                $auditChecks['cycle_'+$auditCycle+'_settled_range_cursor_card'] = $auditSettled.cursor -ceq '+120.000 s' -and (Audit-Same $auditInitial.range $auditSettled.range) -and $auditSettled.popup.hidden -eq $true -and $auditSettled.logStatus -ceq '1,252,505 matching records · exact server-windowed history'
            }
            $auditBeforeIdle=Audit-Obs $auditEntry 'loop3-settled'
            $auditChecks['captured_actions_have_no_pending_indicators_and_one_popup_element'] = @($auditTimed|Where-Object {@($_.pending).Count -ne 0 -or @($_.popups).Count -ne 1}).Count -eq 0
            $auditChecks['captured_action_topology_scope_stays_explicit_minus_10'] = @($auditTimed|Where-Object {$_.topology -notmatch 'Relative capture vector; -10.000 s'}).Count -eq 0
            $auditChecks['idle_bracket_seconds'] = ([datetime]$auditIdleEnd.utc-[datetime]$auditIdleStart.utc).TotalSeconds
            $auditChecks['idle_exceeds_30_seconds'] = ([datetime]$auditIdleEnd.utc-[datetime]$auditIdleStart.utc).TotalSeconds -ge 30
            $auditChecks['after_idle_preserves_roots_sources_cursor_range_scrolls_and_hidden_card'] = (Audit-Same (Audit-RootIds $auditBeforeIdle) (Audit-RootIds $auditAfterIdle)) -and (Audit-Same (Audit-Sources $auditBeforeIdle) (Audit-Sources $auditAfterIdle)) -and $auditBeforeIdle.cursor -ceq $auditAfterIdle.cursor -and (Audit-Same $auditBeforeIdle.range $auditAfterIdle.range) -and (Audit-Same $auditBeforeIdle.scrolls $auditAfterIdle.scrolls) -and $auditAfterIdle.popup.hidden -eq $true
            $auditChecks['action_to_observation_samples'] = $auditTimed.Count
            $auditChecks['action_to_observation_ms_min'] = ($auditTimed|Measure-Object actionToObservationMs -Minimum).Minimum
            $auditChecks['action_to_observation_ms_max'] = ($auditTimed|Measure-Object actionToObservationMs -Maximum).Maximum
            $auditConclusions.Add('Three loops retain exact event UID/time across log and timeline, restore all 14 original root lanes and three source lanes, preserve empty selected range and explicit -10 s topology scope, and show no sampled pending indicators or duplicate popup elements.')
            $auditConclusions.Add('The saved idle bracket spans 59.618 seconds; its endpoint preserves cursor, lane identities, range, scrolls and dismissed popup state.')
            $auditLimits.Add('The 25 action-to-observation samples include automation waits and accessibility sampling. They are not browser-only latency, CPU/RSS measurements, request timing or evidence of a performance regression.')
            $auditLimits.Add('Idle has endpoint snapshots, not continuous observation of every frame or request. Common snapshots do not enumerate review-marker IDs, so final zero test marks is not independently established by this case; separate earlier cleanup evidence records zero.')
            $auditLimits.Add('Baseline cursor is capture End, then event navigation intentionally moves to +120 s; unchanged original cursor is not claimed. Empty selected range is preserved, not a nonempty-range scenario. Section action labels lack section DOM visibility fields, while event/control identity and state comparisons are directly recorded.')
        }
        default {
            $auditOutcome = 'not_reviewed'
            $auditLimits.Add('Raw record arrived after review setup and has no implemented case-specific adjudication; do not infer success from raw status.')
        }
    }
    $auditFalse = @($auditChecks.GetEnumerator() | Where-Object { $_.Value -is [bool] -and -not $_.Value } | ForEach-Object Key)
    if ($auditFalse.Count -and $auditOutcome -ne 'inconclusive') { $auditOutcome='needs_review'; $auditLimits.Add('Computed checks needing inspection: ' + ($auditFalse -join ', ')) }
    $auditSha=[Security.Cryptography.SHA256]::Create()
    $auditDigest=[Convert]::ToHexString($auditSha.ComputeHash([Text.Encoding]::UTF8.GetBytes($auditRaw[$auditLines[$auditId]-1]))).ToLowerInvariant()
    $auditSha.Dispose()
    $auditOutput[$auditId] = [ordered]@{ outcome=$auditOutcome; functional_failure_confirmed=$false; raw_status=$auditEntry.status; title=$auditPlan.title; source=[ordered]@{path='results.jsonl';line=$auditLines[$auditId];raw_record_sha256=$auditDigest;observation_labels=@($auditEntry.observations|ForEach-Object label);final_observation_utc=$auditFinal.utc}; additional_sources=$auditAdditionalSources; verified_checks=$auditChecks; conclusions=@($auditConclusions); evidence_limits=@($auditLimits); review_scope='Latest recorded attempt only; no browser actions by reviewer.' }
}
$auditOutput | ConvertTo-Json -Depth 30 | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'supplemental-adjudications.json') -Encoding utf8
$auditOutput.GetEnumerator() | ForEach-Object { [pscustomobject]@{id=$_.Key;outcome=$_.Value.outcome;line=$_.Value.source.line;false_checks=@($_.Value.verified_checks.GetEnumerator()|Where-Object{$_.Value-is[bool]-and-not$_.Value}|ForEach-Object Key)} } | ConvertTo-Json -Depth 5
