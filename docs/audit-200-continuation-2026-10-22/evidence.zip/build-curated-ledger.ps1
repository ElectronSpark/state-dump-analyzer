$ErrorActionPreference='Stop'
# Rebuilds a review layer from immutable raw attempts; it never changes results.jsonl.
# Case-specific adjudications must be refreshed separately after a new browser replay.
function Ledger-Hash([string]$Text) {
    $ledgerSha=[Security.Cryptography.SHA256]::Create()
    try { [Convert]::ToHexString($ledgerSha.ComputeHash([Text.Encoding]::UTF8.GetBytes($Text))).ToLowerInvariant() }
    finally { $ledgerSha.Dispose() }
}
function Ledger-Get($Object,[string]$Key) {
    if ($null -eq $Object) { return $null }
    if ($Object -is [System.Collections.IDictionary]) { return $Object[$Key] }
    return $Object.PSObject.Properties[$Key].Value
}
$ledgerOriginal=(Get-Content -Raw -LiteralPath (Join-Path $PSScriptRoot 'remaining-original-cases.json') | ConvertFrom-Json).cases
$ledgerSupplemental=(Get-Content -Raw -LiteralPath (Join-Path $PSScriptRoot 'supplemental-36-proposed.json') | ConvertFrom-Json).cases
$ledgerPlans=@($ledgerOriginal)+@($ledgerSupplemental)
if ($ledgerPlans.Count -ne 200 -or @($ledgerPlans.id | Select-Object -Unique).Count -ne 200) { throw 'Expected exactly 200 unique planned continuation IDs.' }
$ledgerPlanIds=@($ledgerPlans.id)
$ledgerRaw=@(Get-Content -LiteralPath (Join-Path $PSScriptRoot 'results.jsonl'))
$ledgerLatest=@{}
$ledgerAttempts=@{}
$ledgerExcluded=[Collections.Generic.List[object]]::new()
for($ledgerIndex=0;$ledgerIndex -lt $ledgerRaw.Count;$ledgerIndex++) {
    $ledgerParsed=$ledgerRaw[$ledgerIndex] | ConvertFrom-Json
    $ledgerRef=[ordered]@{path='results.jsonl';line=$ledgerIndex+1;raw_record_sha256=(Ledger-Hash $ledgerRaw[$ledgerIndex])}
    if (-not $ledgerParsed.id -or $ledgerParsed.id -notin $ledgerPlanIds) {
        $ledgerExcluded.Add([ordered]@{source=$ledgerRef;id=$ledgerParsed.id;reason='No planned continuation ID; not counted as case coverage.'})
        continue
    }
    if(-not $ledgerAttempts.ContainsKey($ledgerParsed.id)) { $ledgerAttempts[$ledgerParsed.id]=[Collections.Generic.List[object]]::new() }
    $ledgerAttempts[$ledgerParsed.id].Add($ledgerRef)
    $ledgerLatest[$ledgerParsed.id]=[ordered]@{record=$ledgerParsed;source=$ledgerRef}
}
$ledgerReviewFiles=@('original-evidence-adjudications.json','adjudications.json','supplemental-adjudications.json')
$ledgerReviews=@{}
$ledgerInputs=[Collections.Generic.List[object]]::new()
foreach($ledgerFile in @('remaining-original-cases.json','supplemental-36-proposed.json','results.jsonl','evidence-review.md','supplement-clarifications.jsonl')+$ledgerReviewFiles) {
    $ledgerPath=Join-Path $PSScriptRoot $ledgerFile
    if(Test-Path -LiteralPath $ledgerPath) {
        $ledgerInputs.Add([ordered]@{path=$ledgerFile;sha256=(Get-FileHash -LiteralPath $ledgerPath -Algorithm SHA256).Hash.ToLowerInvariant();bytes=(Get-Item -LiteralPath $ledgerPath).Length})
        if($ledgerFile -in $ledgerReviewFiles) {
            $ledgerReviewObject=Get-Content -Raw -LiteralPath $ledgerPath | ConvertFrom-Json
            foreach($ledgerProperty in $ledgerReviewObject.PSObject.Properties) {
                if($ledgerProperty.Name -in $ledgerPlanIds) { $ledgerReviews[$ledgerProperty.Name]=[ordered]@{file=$ledgerFile;review=$ledgerProperty.Value} }
            }
        }
    }
}
$ledgerCases=[ordered]@{}
$ledgerCsv=[Collections.Generic.List[object]]::new()
foreach($ledgerPlan in $ledgerPlans) {
    $ledgerId=$ledgerPlan.id
    $ledgerEntry=$ledgerLatest[$ledgerId]
    $ledgerReviewEnvelope=$ledgerReviews[$ledgerId]
    $ledgerReview=$ledgerReviewEnvelope.review
    $ledgerLimits=[Collections.Generic.List[string]]::new()
    $ledgerConclusions=@()
    $ledgerStatus='not_recorded'
    $ledgerConfirmed=$false
    $ledgerCurrent=$false
    if($ledgerEntry) {
        $ledgerStatus='not_reviewed'
        if($ledgerReview) {
            $ledgerReviewSource=$ledgerReview.source
            $ledgerReviewedLine=Ledger-Get $ledgerReviewSource 'line'
            if(-not $ledgerReviewedLine) { $ledgerReviewedLine=Ledger-Get $ledgerReview 'raw_line' }
            $ledgerReviewedHash=Ledger-Get $ledgerReviewSource 'raw_record_sha256'
            $ledgerCurrent=($ledgerReviewedLine -eq $ledgerEntry.source.line) -and (-not $ledgerReviewedHash -or $ledgerReviewedHash -ceq $ledgerEntry.source.raw_record_sha256)
            if($ledgerCurrent) {
                $ledgerStatus=$ledgerReview.outcome
                if($ledgerStatus -eq 'passed' -or $ledgerStatus -eq 'pass') { $ledgerStatus='passed_with_limits'; $ledgerLimits.Add('Raw success is scoped to saved observations; unobserved plan assertions are not counted as verified.') }
                $ledgerConfirmed=$ledgerReview.functional_failure_confirmed -eq $true
                $ledgerConclusions=@($ledgerReview.conclusions)
                foreach($ledgerLimit in @($ledgerReview.evidence_limits)) { if($ledgerLimit) { $ledgerLimits.Add([string]$ledgerLimit) } }
            } else {
                $ledgerLimits.Add('Latest raw attempt differs from the available adjudication. Refresh the case-specific review before claiming its outcome.')
            }
        } else {
            $ledgerLimits.Add('Latest raw attempt has not received case-specific independent adjudication; raw status is retained separately and is not promoted to a verified pass.')
        }
    } else {
        $ledgerLimits.Add('No completed raw record for this planned ID at build time; pending execution supplies no coverage.')
    }
    if($ledgerStatus -eq 'not_recorded' -and $ledgerEntry) { $ledgerStatus='not_reviewed'; $ledgerLimits.Add('A raw attempt now exists after the earlier not-recorded review; case requires adjudication.') }
    $ledgerObservations=@($ledgerEntry.record.observations)
    $ledgerDomain=if($ledgerPlan.domain){$ledgerPlan.domain}else{'supplemental'}
    $ledgerFamily=if($ledgerPlan.family){$ledgerPlan.family}else{$ledgerPlan.group}
    $ledgerPlanFile=if($ledgerPlan.kind -eq 'original_unexecuted'){'remaining-original-cases.json'}else{'supplemental-36-proposed.json'}
    $ledgerAllAttempts=@($ledgerAttempts[$ledgerId])
    if(-not $ledgerEntry){$ledgerAllAttempts=@()}
    $ledgerCases[$ledgerId]=[ordered]@{
        id=$ledgerId;title=$ledgerPlan.title;domain=$ledgerDomain;family=$ledgerFamily
        outcome=$ledgerStatus;functional_failure_confirmed=$ledgerConfirmed
        plan=[ordered]@{extracted_from=$ledgerPlanFile;source_plan=$ledgerPlan.source_plan;kind=$ledgerPlan.kind;setup=@($ledgerPlan.setup);parameters=$ledgerPlan.parameters;actions=@($ledgerPlan.actions);required_assertions=@($ledgerPlan.required_assertions)}
        raw_status=$ledgerEntry.record.status;raw_notes=$ledgerEntry.record.notes
        latest_raw_source=$ledgerEntry.source;all_attempt_sources=$ledgerAllAttempts
        superseded_attempt_count=[Math]::Max(0,$ledgerAllAttempts.Count-1)
        observation_labels=@($ledgerObservations | ForEach-Object label)
        first_observation_utc=if($ledgerObservations.Count){$ledgerObservations[0].utc}else{$null}
        final_observation_utc=if($ledgerObservations.Count){$ledgerObservations[-1].utc}else{$null}
        adjudication_source=if($ledgerReviewEnvelope){[ordered]@{path=$ledgerReviewEnvelope.file;key=$ledgerId;matches_latest_raw=$ledgerCurrent}}else{$null}
        verified_checks=if($ledgerCurrent){$ledgerReview.verified_checks}else{$null}
        additional_sources=if($ledgerCurrent){@($ledgerReview.additional_sources)}else{@()}
        conclusions=$ledgerConclusions;evidence_limits=@($ledgerLimits)
    }
    $ledgerCsv.Add([pscustomobject]@{id=$ledgerId;title=$ledgerPlan.title;domain=$ledgerDomain;family=$ledgerFamily;outcome=$ledgerStatus;raw_status=$ledgerEntry.record.status;raw_line=$ledgerEntry.source.line;superseded_attempts=[Math]::Max(0,$ledgerAllAttempts.Count-1);functional_failure_confirmed=$ledgerConfirmed;limits=(@($ledgerLimits)-join ' | ')})
}
$ledgerCounts=[ordered]@{}
foreach($ledgerStatusName in @('passed_with_limits','blocked','inconclusive','needs_review','finding','not_recorded','not_reviewed')) {
    $ledgerCounts[$ledgerStatusName]=@($ledgerCsv|Where-Object outcome -eq $ledgerStatusName).Count
}
$ledgerObserved=@($ledgerCsv|Where-Object raw_line).Count
$ledgerReviewed=@($ledgerCases.Values|Where-Object{$_.adjudication_source.matches_latest_raw}).Count
$ledgerSummary=[ordered]@{
    planned=200;original_planned=$ledgerOriginal.Count;supplemental_planned=$ledgerSupplemental.Count
    ids_with_raw_attempt=$ledgerObserved;ids_without_raw_attempt=200-$ledgerObserved
    independently_adjudicated_latest_attempts=$ledgerReviewed
    outcome_counts=$ledgerCounts
    confirmed_functional_findings=@($ledgerCsv|Where-Object functional_failure_confirmed).Count
    superseded_attempts=($ledgerCsv|Measure-Object -Property superseded_attempts -Sum).Sum
    excluded_unplanned_or_idless_attempts=$ledgerExcluded.Count
}
$ledgerDocument=[ordered]@{
    schema_version=1;generated_utc=[DateTime]::UtcNow.ToString('o')
    status=if($ledgerCounts.not_recorded -or $ledgerCounts.not_reviewed){'in_progress_with_evidence_limits'}else{'all_planned_ids_adjudicated_with_evidence_limits'}
    scope='164 previously unexecuted original cases plus 36 supplemental cases. Latest raw attempt per ID is authoritative; earlier attempts remain referenced but do not add case coverage.'
    interpretation='passed_with_limits means named recorded observations support a narrower outcome than all plan assertions. Blocked and inconclusive cases are not passes. This is a browser evidence ledger, not a CPU/RSS measurement or proof of absence of defects.'
    summary=$ledgerSummary;input_files=@($ledgerInputs);cases=$ledgerCases
    excluded_attempts=@($ledgerExcluded)
    global_evidence_limits=@(
        'DOM snapshots may include retained text of hidden elements; visibility and current-state predicates must be assessed separately.',
        'Common range inputs are selected-range fields, not timeline viewport bounds. Focused controls are not proof of selected inspector state.',
        'Pending overlap, request ownership, exact geometry, settled viewport and later asynchronous replacement require explicit evidence; rapid action order or final recovery alone does not prove them.',
        'Tool-wait durations and snapshot time gaps are not application latency or CPU/RSS measurements.',
        'Original-plan baseline variants and sampler gaps remain case-specific limits; later enriched cases do not retroactively repair earlier evidence.'
    )
}
$ledgerDocument|ConvertTo-Json -Depth 45|Set-Content -LiteralPath (Join-Path $PSScriptRoot 'curated-200-case-ledger.json') -Encoding utf8
$ledgerCsv|Export-Csv -LiteralPath (Join-Path $PSScriptRoot 'curated-200-case-index.csv') -NoTypeInformation -Encoding utf8
$ledgerSummary|ConvertTo-Json -Depth 8|Set-Content -LiteralPath (Join-Path $PSScriptRoot 'curated-200-case-summary.json') -Encoding utf8
$ledgerSummary|ConvertTo-Json -Depth 8
