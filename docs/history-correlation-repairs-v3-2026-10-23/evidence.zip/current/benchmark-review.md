# Independent review of repair v3 1M measurements

Reviewed the raw v3 and v2 result JSON independently of the existing comparator, then checked its reported comparison. No benchmark, server request, browser action, fixture decode, or heavy test was run during this review.

## Completeness and output equivalence

- Both processes returned0 with no guard/stop reason. V3 has exactly52 start records,52 end records, and one final complete record. V3 stderr is empty.
- All52 ordered phase occurrences match, including repeated phase names. Their complete `result` objects match the v2 baseline.
- All35 ordered complete-page SHA-256 values match. This comparison did not deduplicate repeated page phases.
- All five recorded invariant groups match: `search_before`, `returned_search_before`, `cache_retirement`, `shared_search_cache`, and `validation_cache`.
- The v3 environment record points at the repaired history-correlation fixture; the baseline uses the prior history-clock fixture. Harness arguments retain dense term`success` and5 repeats.
- The unchanged harness hash verified during preparation remains `05a586a092289fe65a10462bba61e79f988bc8588d121bad727df1eed752a92a`. The harness owns the fresh child, fresh search cache,100ms sampling, and lifetime memory counters.

## Metrics

| Metric | v2 quiet baseline | v3 repaired fixture | Change |
| --- | ---: | ---: | ---: |
| Loaded RSS |2.1749725GiB|2.1763802GiB|+0.0014076GiB (+0.0647%)|
| Lifetime peak RSS |2.2542686GiB|2.2547760GiB|+0.0005074GiB (+0.0225%)|
| Lifetime peak private commit |2.2492981GiB|2.2489052GiB|−0.0003929GiB (−0.0175%)|
| Sum of52 phase CPU durations |158.28125s|152.96875s|−5.3125s (−3.3564%)|
| Supervisor elapsed |161.813s|157.703s|−4.110s (−2.5400%)|
| Search sidecar |75,038,720bytes|75,038,720bytes|unchanged|

The largest positive per-phase CPU delta is31.25ms in runtime imports. The largest positive wall delta is1.608ms in runtime imports. Several smaller CPU deltas are15.625ms, consistent with the coarse Windows process CPU timer granularity. No material regression is demonstrated in this single paired run.

Do not claim an optimization speedup from the3.36% CPU reduction: this task changes generator correctness and frontend interaction, not the measured core search algorithms, and no repeated statistical sample was taken. The approximately1.44MiB loaded-RSS increase and0.52MiB lifetime-peak increase are small relative to the2.25GiB footprint and do not establish a memory regression.

## Interpretation limits

- This is one fresh-process, fresh-search-cache Windows comparison. OS caches were not flushed, and hardware/background variability is not eliminated.
- Browser and idle demo memory are excluded; the prior audit's3.037GiB process snapshot covered a different workload and is not a baseline for this52-phase measurement.
- The parent reports the measurement ran without simultaneous generation, tests, or browser operations. Raw benchmark records alone cannot independently prove system-wide quiescence.
- The regenerated archive has different bytes/identity and corrected relationship starts/event properties. Full measured result equality covers these52 phases, not every historical resource/relationship query. Planned browser exact-boundary tests establish the repaired semantics separately.
- Summed phase CPU excludes work outside explicitly timed phases; supervisor elapsed includes process/startup/monitor overhead. These are different quantities, not a CPU utilization calculation.
-100ms sampling may miss brief instantaneous peaks, while Windows lifetime counters cover this child process's lifetime peak working set/private commit. Neither metric is browser heap.

Fixture metadata records286,504,605bytes and SHA-256`5f204e5836be8966f148ae14671f9488007970619cff094cc9bda60c71892105`. This review trusted the parent's saved fixture hash rather than rereading a286MB archive during browser validation.
