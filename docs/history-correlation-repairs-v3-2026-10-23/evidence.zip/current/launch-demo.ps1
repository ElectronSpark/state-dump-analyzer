$ErrorActionPreference = 'Stop'
$repoRoot = (Resolve-Path (Join-Path $PSScriptRoot '../..')).Path
$fixture = Join-Path $repoRoot 'demo/fixtures/router-state-lab-history-correlation-2026-10-23.tgz'
if (-not (Test-Path -LiteralPath $fixture -PathType Leaf)) { throw 'Corrected fixture is not ready.' }
$listener = Get-NetTCPConnection -LocalPort 8883 -State Listen -ErrorAction SilentlyContinue
if ($listener) { throw 'Port 8883 is already occupied; inspect process identity before proceeding.' }
$serverTemp = Join-Path $PSScriptRoot 'server-temp'
New-Item -ItemType Directory -Force $serverTemp | Out-Null
$env:TEMP = $serverTemp
$env:TMP = $serverTemp
$env:PYTHONUTF8 = '1'
$env:PYTHONIOENCODING = 'utf-8'
$demoArguments = @('-B','-X','utf8','-m','router_dump_analyzer','--plugin','demo_router','--input','demo/fixtures/router-state-lab-history-correlation-2026-10-23.tgz','--host','127.0.0.1','--port','8883','--frontend-dir','frontend','--control-plane-dir','.runtime/manual-browser-2026-10-20/control-plane','--plugin-composition-deployment-module','rsl_demo_plugin.deployment:build_plugin_deployment','--private-analysis-deployment-module','rsl_demo_plugin.offline_analysis:build_offline_analysis_deployment','--trust-control-plane-headers','--no-browser')
$server = Start-Process -FilePath 'C:/Users/82046/anaconda3/envs/router-dump-analyzer-demo/python.exe' -ArgumentList $demoArguments -WorkingDirectory $repoRoot -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $PSScriptRoot 'server.stdout.log') -RedirectStandardError (Join-Path $PSScriptRoot 'server.stderr.log')
@{pid=$server.Id;arguments=$demoArguments;fixture=$fixture} | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'server.json') -Encoding utf8
Get-Content -LiteralPath (Join-Path $PSScriptRoot 'server.json')
