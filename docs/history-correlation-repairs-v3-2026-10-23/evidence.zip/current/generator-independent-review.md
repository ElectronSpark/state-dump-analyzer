# Independent review of generator repair

Reviewed the task-owned diff in `demo/rsl_demo_generator/_scale.py` and `tests/test_scale_generator_optimization.py`, the adjacent event producers, interval producer, and mutation producer. No heavy test, generation, or server work was run; generation session8629 was untouched. A small pure `_layout` import evaluated resource counts0,1,8,19,20,39,40,75,120.

## Result

No blocking correctness finding in the reviewed change.

- All five multihome interval starts that previously used the phase-wide start now use the actual per-service attachment time: ETG→backup `owns`, backup→next-hop `next_hop`, ETG→ES `member_of_es`, ES→primary `active_path`, and backup→VIF `egresses_via`.
- The remaining multihome ES→VIF `uses_interface` already uses the first service's exact per-ES timestamp. Its first-wave event condition matches the producer. No omitted phase-wide multihome interval start remains.
- Service withdrawal/restoration times continue using the existing helper offset by the ES wave; their half-open bounds are unchanged. The mutation producer agrees with those transition times.
- First single-home starts remain phase-wide. Those sources/targets are born at their own event, so lifecycle filtering masks the early raw bound; this is outside the audited shared-ES failure, which involved two endpoints already existing. It is not a newly exposed visible defect from this patch and does not require expanding the current change.
- `len(range(es_index, multi_home_service_count, es_count))` is constant-time and counts exact modulo assignments. The containing branch requires positive multihome count; current layout construction then guarantees positive ES count, so no zero-step range occurs. Small layouts below20 resources have no ES/multihome branch. Layout20 has counts[2];39 has[3];40 has[2,2];75 has[3,2,2];120 has six2s. The canonical750/375 layout yields2 per ES.

## Regression coverage assessment

- The new interval test compares stored starts to the actual event relationship effects, including `uses_interface`, across two small layouts and the canonical layout. It separately checks backup routing/egress starts. The shared-ES before/exact/after/backwards control targets the lifecycle-masking gap from the audit.
- Resource count75 gives an uneven ES distribution[3,2,2], so the affected-service test is not merely a constant2 assertion. Withdrawal and restore are both checked against independently counted `_es_index` assignments.
- Every chosen interval-test layout has a second-wave shared service (`multi_home_service_count > es_count`), so its ES0 boundary expectation is valid. The12,500-event input gives enough multihome events even for the750-service canonical case.
- The interval test's small local visibility predicate is not an integration test of core query filtering. The planned browser boundary checks and existing API tests remain necessary and complement it.

These are internal generator corrections, with no new plug-in API or hook. Regenerated fixture bytes and search-projection identity will change, including the affected-service property correction; performance comparison must distinguish intentional output changes from regressions.
