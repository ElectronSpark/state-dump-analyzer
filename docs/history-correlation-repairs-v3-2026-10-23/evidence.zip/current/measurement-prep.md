# Repair v3 measurement and fixture preparation

Read-only preparation, 2026-10-23. No generation, benchmark, server request, process termination, product edit, or restart was performed.

## Verified environment

- Python: `C:/Users/82046/anaconda3/envs/router-dump-analyzer-demo/python.exe`, Python 3.12.13.
- Imports succeeded from this checkout: `router_dump_analyzer`, `rsl_demo_generator`, `rsl_demo_plugin`, `pydantic`, `fastapi` 0.141.1, `uvicorn` 0.52.4, `httpx` 0.28.1, `pytest` 8.4.2.
- Canonical defaults imported from generator: 1,250,000 events, 7,500 resources, seed 20260725. Omitting node selectors builds all 10 canonical nodes.
- Initial optional probe included `aiohttp` and failed; that package is not a declared dependency and is not required. Correct project imports above passed.

## Exact prior measurement

- Harness: `.runtime/history-correlation-repairs-v2-2026-10-23/measure.py`.
- SHA-256: `05a586a092289fe65a10462bba61e79f988bc8588d121bad727df1eed752a92a` (verified).
- Baseline: `.runtime/history-correlation-repairs-v2-2026-10-23/after-1m-quiet/result.json`.
- Baseline command used default `--dense-term success --repeats 5`; 52 completed phases, returncode 0, no guard.
- Prior metrics: loaded RSS 2.1750 GiB; lifetime peak RSS 2.2543 GiB; peak private commit 2.2493 GiB; summed phase CPU 158.2813 s; elapsed 161.813 s; sidecar 75,038,720 bytes.
- Comparator: `.runtime/history-correlation-repairs-v2-2026-10-23/compare_results.py`. It retains repeated phase occurrences, 35 complete page hashes, search/cache/retirement invariants, and reports every changed result.

Use the unchanged v2 harness directly (its source-root default still resolves to this checkout); do not needlessly copy or modify it. Run only after generation/tests/browser work are idle, with a fresh output directory and workspace-local temporary path:

```powershell
$taskRoot = (Resolve-Path '.runtime/history-correlation-repairs-v3-2026-10-23').Path
$measureTemp = Join-Path $taskRoot 'measurement-temp'
New-Item -ItemType Directory -Force -Path $measureTemp | Out-Null
$env:TEMP = $measureTemp
$env:TMP = $measureTemp
$env:PYTHONUTF8 = '1'
$env:PYTHONIOENCODING = 'utf-8'
& 'C:/Users/82046/anaconda3/envs/router-dump-analyzer-demo/python.exe' -B -X utf8 `
  '.runtime/history-correlation-repairs-v2-2026-10-23/measure.py' `
  --archive 'demo/fixtures/router-state-lab-history-relations-2026-10-23.tgz' `
  --output '.runtime/history-correlation-repairs-v3-2026-10-23/after-1m-quiet' `
  --dense-term success --repeats 5
& 'C:/Users/82046/anaconda3/envs/router-dump-analyzer-demo/python.exe' -B -X utf8 `
  '.runtime/history-correlation-repairs-v2-2026-10-23/compare_results.py' `
  --baseline '.runtime/history-correlation-repairs-v2-2026-10-23/after-1m-quiet/result.json' `
  --after '.runtime/history-correlation-repairs-v3-2026-10-23/after-1m-quiet/result.json' `
  --output '.runtime/history-correlation-repairs-v3-2026-10-23/comparison.json'
```

The proposed new fixture filename is only a suggested output, not an existing artifact. Substitute the parent's actual chosen name consistently. Harness `--output` must not exist. It creates a fresh search-cache directory and child process, samples at 100 ms, retains lifetime counters, guards against host RAM below 6 GiB, child private memory above 32 GiB, or 30-minute runtime. It does not flush OS caches. The idle demo process and browser memory are excluded from the measured child. Browser audit RSS 3.037 GiB is a different workload and must not be used as the baseline for this harness. New fixture bytes/fingerprint differ; investigate any changed page hashes, rather than asserting all must remain identical without checking intentional data corrections.

## Fixture regeneration

The prior successful generation used canonical defaults. The exact CLI is documented in `demo/README.md:880–886`; default values were verified by import. Use a new named archive to preserve the current demo and avoid existing output ownership locks:

```powershell
$taskRoot = (Resolve-Path '.runtime/history-correlation-repairs-v3-2026-10-23').Path
$generationTemp = Join-Path $taskRoot 'generation-temp'
New-Item -ItemType Directory -Force -Path $generationTemp | Out-Null
$env:TEMP = $generationTemp
$env:TMP = $generationTemp
$env:PYTHONUTF8 = '1'
$env:PYTHONIOENCODING = 'utf-8'
& 'C:/Users/82046/anaconda3/envs/router-dump-analyzer-demo/python.exe' -B -X utf8 `
  -m rsl_demo_generator --output 'demo/fixtures/router-state-lab-history-relations-2026-10-23.tgz'
& 'C:/Users/82046/anaconda3/envs/router-dump-analyzer-demo/python.exe' -B -X utf8 `
  -m rsl_demo_generator --check-launchable 'demo/fixtures/router-state-lab-history-relations-2026-10-23.tgz'
```

Check exit codes and archive SHA-256 after successful completion. `--check-launchable` cheaply checks canonical outer metadata and does not decode nested packs. Existing v2 logs contain both a temporary-directory access failure and an overlapping-output generator lock error before the successful run. Preserve those as historical evidence, not new failures. The unrelated untracked `.router-state-lab-demo.generated.tgz.router-dump-analyzer.lock` must remain untouched.

## Demo restart

Existing template: `.runtime/history-correlation-repairs-v2-2026-10-23/restart-demo.ps1`. **Do not run it unchanged**: it checks old PID45140 and the earlier algorithms fixture, then starts the history-clock fixture. Its `server.json` records the later PID12380 and current history-clock archive.

Before restarting, freshly verify the host process listening on8883 against the expected Python executable, `-m router_dump_analyzer`, port8883, and current archive. This child sandbox could not access CIM and `Get-Process` did not expose PID12380; those results do not establish that the host demo has exited. Parent can use the existing host execution path for identity verification. Stop only the verified demo process once the replacement archive is ready.

Adapt the template into the v3 runtime folder with the verified current PID/archive guard, new archive path, v3 server-temp, v3 stdout/stderr/server.json, and retain `Start-Process -WindowStyle Hidden`. Preserve args:

```text
-B -X utf8 -m router_dump_analyzer --plugin demo_router
--input demo/fixtures/<new-fixture>.tgz
--host 127.0.0.1 --port 8883 --frontend-dir frontend
--control-plane-dir .runtime/manual-browser-2026-10-20/control-plane
--plugin-composition-deployment-module rsl_demo_plugin.deployment:build_plugin_deployment
--private-analysis-deployment-module rsl_demo_plugin.offline_analysis:build_offline_analysis_deployment
--trust-control-plane-headers --no-browser
```

Use the original PowerShell argument-array structure when launching; this wrapped display is not a paste-ready shell command.

## Additional affected_services candidate

The source-only finding is valid and is a small generator evidence correction adjacent to HC3-1, though not part of the three browser-confirmed defects.

- `_scale.py:1060` and`:1217` hard-code `affected_services: 3` for first-wave ES withdrawal/restoration.
- `_layout(7500)` returns750 multihome services and375 ES objects. `_es_index` assigns `service_index % es_count`. Therefore every canonical ES has2 services, and ES374 has exactly374 and749 (verified by pure layout evaluation).
- The general per-ES count is `len(range(es_index, layout.multi_home_service_count, layout.es_count))`; an O(1) integer equivalent is `(layout.multi_home_service_count + layout.es_count - 1 - es_index) // layout.es_count`. The event branch is reached only when `multi_home_service_count > 0`, which implies `es_count > 0` under current `_layout`.
- Prefer replacing the two constants with the count derived from existing layout, not introducing a new index/cache. Test withdrawal and restore counts on canonical and uneven small layouts. Count actual assigned services, not `es_count * 3` capacity.
- It alters event properties/search corpus bytes, so fixture regeneration is required (already necessary for HC3-1). Report it separately as a source-verified correction; the audited browser inspector did not display the property.

Documentation drift check: preparation evidence only, no author-visible behavior, API, or maintained documentation changed by this subtask.
