"""Small independent persisted-relationship boundary oracle; run from repo root."""
import json
from rsl_demo_generator import _scale as s

checks = 0
for size in (40, 75, 120):
    layout = s._layout(size)
    rows = [json.loads(line) for line in s._relationship_lines(12500, layout)]
    def active(identity, timestamp):
        return any((r['source'], r['target'], r['relation_type']) == identity
                   and int(r['valid_from_ns']) <= timestamp
                   and (r['valid_to_ns'] is None or timestamp < int(r['valid_to_ns']))
                   for r in rows)
    for index in range(layout.multi_home_service_count):
        t = s._phase_start_ns('multihome_add') + index * s.EVENT_STEP_NS
        event = s._event_for_phase('multihome_add', index, index, t, layout)
        for effect in event['relationship_effects']:
            identity = effect['source'], effect['target'], effect['type']
            for timestamp, expected in ((t-1, False), (t, True), (t+1, True), (t-1, False)):
                assert active(identity, timestamp) == expected, (size, index, identity, timestamp)
                checks += 1
print(f'PASS: {checks} exact attachment-boundary assertions across three small layouts')
