# Independent skill trial

Result: no demonstrated regression in the focused source and executable checks. This is bounded conformance evidence, not browser readiness or exhaustive validation.

Prompt: Use `.agents/skills/router-plugin-validate/SKILL.md` to validate current generated temporal relationships and route-form/correlation-graph changes. Allowed inputs were current source, tests, AGENTS.md, skills and their contract/API-map references. Prior reports, runtime artifacts, parent logs and other agents' outputs were excluded. No excluded contents were read. Outputs are confined to this directory; no product files were edited.

Skill SHA-256: `EDE01D16C79878785504BA4CA2F9E4829E85E600AE5A5015FB8A67CB02606484`.

Scope classification: generated example relationship projection and compatibility runtime data; frontend route capability reconciliation and graph presentation. These changes add no AnalyzerPlugin hooks or typed protocol declarations. Reviewed AGENTS.md, skill, API validation map, relevant contract references, task source diffs and focused tests.

Environment: default `C:/Python312/python.exe` could not import router_dump_analyzer, so the first import and inventory attempts failed with ModuleNotFoundError. Following the map's environment troubleshooting found and verified `C:/Users/82046/anaconda3/envs/router-dump-analyzer-demo/python.exe`, including router_dump_analyzer, rsl_demo_plugin, rsl_demo_generator, fastapi and httpx imports. All successful Python checks used that interpreter. No installation was needed.

Commands and results:

- `python scripts/check_plugin_conformance.py --list`: passed all eight inventory groups. This checks declarations only.
- `python -m unittest tests.test_scale_generator_optimization.ScaleGeneratorOptimizationTests.test_multihome_intervals_match_each_attachment_event tests.test_scale_generator_optimization.ScaleGeneratorOptimizationTests.test_es_event_counts_match_actual_shared_service_membership -v`: 2 passed, 0 failures, 0 skips.
- `python .runtime/history-correlation-repairs-v3-2026-10-23/skill-trial/check_temporal.py`: 312 assertions passed over resource layouts 40, 75 and 120, independently checking every attachment event's relationship effects at one nanosecond before, exact, after and backward. Shared existing endpoints are included.
- `python -m unittest tests.test_route_history_validity -v`: 2 passed, 0 failures, 0 skips. Covers half-open validity, uncertainty and typed carrier lifecycle.
- `node --test --test-name-pattern="HC3-2|focused relationship|rendered .* graph" frontend/tests/route_audit_regressions.test.mjs frontend/tests/correlation_graph_layout.test.mjs`: 4 passed, 20 intentionally excluded by name pattern, 0 failures.

The attachment source now uses per-service birth for membership, ownership, primary active-path, backup next-hop and egress observations. Event affected-service counts derive from actual strided membership. Route tests exercise actual installed change handlers and the submitted request across edit orders. Graph tests exercise generated handlers and SVG measurement scale, plus a width matrix with long labels.

Limits: the temporal oracle checks generated persisted relationship records directly, not durable ingestion or a served archive. No archive was regenerated, no browser was used, and no composed generated assembly API check, frontend full suite, heavy generation, benchmark or service restart was performed. Mocked DOM geometry cannot establish actual pointer hit-testing, horizontal-scroll behavior, focus retention or narrow-browser correctness; these remain browser follow-up obligations. Existing persisted archives need regeneration before browser claims. The no-browser restriction prevents completing the skill's live-document geometry checks and real form-submit validation.

Documentation drift check: trial edits are an executable check and this report only; no public plug-in behavior changed in this trial, so maintained authoring documents need no trial-owned update. Reviewed changes are generated-example fixes and frontend presentation/reconciliation, not new parser APIs; API validation map already names their focused scenarios.
