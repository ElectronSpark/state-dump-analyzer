"""Package allowlisted repair evidence after all producers have finished.

This script has not been run as part of measurement preparation. It creates
only the evidence ZIP and hash manifest in the requested report directory.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import zipfile


TASK = Path(__file__).resolve().parent
REPO = TASK.parents[1]
PREVIOUS = TASK.parent / "history-correlation-repairs-v2-2026-10-23"
DEFAULT_OUTPUT = REPO / "docs/history-correlation-repairs-v3-2026-10-23"
HARNESS_HASH = "05a586a092289fe65a10462bba61e79f988bc8588d121bad727df1eed752a92a"
MAX_FILE_BYTES = 8 * 1024 * 1024
MAX_TOTAL_BYTES = 64 * 1024 * 1024
TOP_SUFFIXES = {".log", ".json", ".md", ".py", ".ps1", ".png", ".jpg", ".jpeg", ".webp"}
TRIAL_SUFFIXES = TOP_SUFFIXES | {".txt"}
EXCLUDED_PARTS = {
    "temp", "server-temp", "measurement-temp", "pycache", "__pycache__",
    "search-cache", "node_modules", ".git", "fixtures",
}


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def allowed_files() -> list[tuple[str, Path]]:
    selected: dict[str, Path] = {}

    def add(name: str, path: Path, *, required: bool = True) -> None:
        if not path.is_file():
            if required:
                raise FileNotFoundError(path)
            return
        if path.is_symlink():
            raise ValueError(f"Refusing symlink evidence: {path}")
        if path.stat().st_size > MAX_FILE_BYTES:
            raise ValueError(f"Evidence exceeds {MAX_FILE_BYTES} byte per-file cap: {path}")
        selected[name] = path

    # Deliberately non-recursive: temporary/runtime/cache trees never enter.
    for path in TASK.iterdir():
        if path.is_file() and (
            path.suffix.lower() in TOP_SUFFIXES
            or (path.name.startswith("browser-") and path.suffix.lower() == ".txt")
        ):
            add("current/" + path.name, path)

    # Explicit benchmark files only. No pycache or search sidecar is included.
    for name in ("result.json", "child.jsonl", "memory.jsonl", "stderr.log"):
        add("current/after-1m-quiet/" + name, TASK / "after-1m-quiet" / name)

    # Trial output is bounded by both suffix and excluded directory names.
    trial = TASK / "skill-trial"
    if trial.is_dir():
        for path in trial.rglob("*"):
            relative = path.relative_to(trial)
            if any(part.lower() in EXCLUDED_PARTS for part in relative.parts):
                continue
            if path.is_file() and path.suffix.lower() in TRIAL_SUFFIXES:
                add("current/skill-trial/" + relative.as_posix(), path)

    add("baseline/result.json", PREVIOUS / "after-1m-quiet/result.json")
    add("harness/measure.py", PREVIOUS / "measure.py")
    add("harness/compare_results.py", PREVIOUS / "compare_results.py")
    if digest((PREVIOUS / "measure.py").read_bytes()) != HARNESS_HASH:
        raise ValueError("The measurement harness differs from the verified baseline hash")
    return sorted(selected.items())


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--dry-run", action="store_true", help="List allowlisted files without creating output")
    args = parser.parse_args()
    selected = allowed_files()
    total = sum(path.stat().st_size for _, path in selected)
    if total > MAX_TOTAL_BYTES:
        raise ValueError(f"Evidence exceeds {MAX_TOTAL_BYTES} byte total cap")
    if args.dry_run:
        print(json.dumps({"files": [name for name, _ in selected], "uncompressed_bytes": total}, indent=2))
        return 0

    destination = args.output.resolve()
    if not destination.is_relative_to(REPO / "docs"):
        raise ValueError("Report destination must be inside this repository's docs directory")
    destination.mkdir(parents=True, exist_ok=True)
    archive = destination / "evidence.zip"
    temporary = destination / "evidence.zip.tmp"
    entries = []
    with zipfile.ZipFile(temporary, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as out:
        for name, path in selected:
            data = path.read_bytes()
            if len(data) > MAX_FILE_BYTES:
                raise ValueError(f"Evidence grew beyond cap during read: {path}")
            out.writestr(name, data)
            entries.append({"path": name, "bytes": len(data), "sha256": digest(data)})

    with zipfile.ZipFile(temporary) as check:
        if check.testzip() is not None:
            raise ValueError("ZIP CRC verification failed")
        if check.namelist() != [entry["path"] for entry in entries]:
            raise ValueError("ZIP entry ordering/list mismatch")
        for entry in entries:
            data = check.read(entry["path"])
            if len(data) != entry["bytes"] or digest(data) != entry["sha256"]:
                raise ValueError(f"ZIP digest verification failed: {entry['path']}")
    os.replace(temporary, archive)
    manifest = {
        "archive": archive.name,
        "bytes": archive.stat().st_size,
        "sha256": digest(archive.read_bytes()),
        "verified": True,
        "measurement_harness_sha256": HARNESS_HASH,
        "selection": "Allowlisted small current logs/JSON/reviews/scripts/screenshots/browser snapshots, bounded skill-trial outputs, four benchmark files, v2 baseline result and unchanged measurement/comparison scripts; runtime/cache/fixture trees excluded.",
        "entries": entries,
    }
    manifest_path = destination / "evidence-manifest.json"
    manifest_temp = destination / "evidence-manifest.json.tmp"
    manifest_temp.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    os.replace(manifest_temp, manifest_path)
    print(json.dumps({"archive": str(archive), "files": len(entries), "bytes": manifest["bytes"], "sha256": manifest["sha256"], "verified": True}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
