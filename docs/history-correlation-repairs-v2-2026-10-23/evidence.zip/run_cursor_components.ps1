$ErrorActionPreference = 'Stop'
$taskRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'))
$taskTemp = Join-Path $PSScriptRoot 'cursor-temp'
New-Item -ItemType Directory -Path $taskTemp -Force | Out-Null
$env:TEMP = $taskTemp
$env:TMP = $taskTemp
$env:PYTHONHASHSEED = '0'
Set-Location -LiteralPath $taskRoot
& 'C:/Users/82046/anaconda3/envs/router-dump-analyzer-demo/python.exe' -B -X utf8 (Join-Path $PSScriptRoot 'profile_cursor_components.py') --fixture (Join-Path $taskRoot 'demo/fixtures/router-state-lab-history-clock-2026-10-23.tgz') --stage all
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
