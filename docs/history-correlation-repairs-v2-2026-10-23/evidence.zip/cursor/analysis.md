# Cursor component investigation

The three audit defects were repaired separately. This investigation diagnoses
the residual cursor cost; it implements no performance optimization and does not
claim a latency improvement.

## Fixed workload and method

- Regenerated fixture `router-state-lab-history-clock-2026-10-23.tgz`, SHA-256
  `fb1ef97c01ef7306d0e4104cedcaba2fd3615bb701c5d9cc3aa6abc92f273470`.
  PE-A: 1,250,005 events, 7,510 resources.
- Python 3.12.13, `PYTHONHASHSEED=0`, workspace TEMP/TMP, quiet process run.
- Eight exact native cursor offsets from audit moves 054/055/059/060/062/063/069/071,
  two rounds reversing empty/active search order, 128 separately timed operations.
- Resources: DTE kind, 500-row limit, no layer filter, empty search or the selected
  DTE0/DTE1 term. Graph: selected DTE root, both directions, depth 3, maximum 500
  nodes. Live dashboard IDs: `forwarding-population`, `neighbor-health` (the
  default-open descriptors requiring a point-in-time query).
- First lazy history/search materialization is timed before warm-state cases.
  Each fresh case clears only the existing search snapshot cache. Exact-repeat
  requests then reuse ordinary production state. No capacity was changed.
- Direct service timings exclude HTTP scheduling, JSON serialization, hashing,
  browser rendering, and automation overhead. The four cProfile occurrences are
  separate from latency measurements. Process CPU has coarse timer resolution;
  a 0 CPU sample for a 2.8 ms call does not mean zero CPU work.

## Results

| Component | Fresh median elapsed | Exact-repeat median elapsed | Fresh median CPU |
| --- | ---: | ---: | ---: |
| Searched resource page | 1.5241 s | 0.00283 s | 1.5000 s |
| Empty-search 500-row page | 0.08448 s | 0.08706 s | 0.07813 s |
| Focused graph | 0.02565 s | 0.02538 s | 0.03125 s |
| Two live dashboards | 1.10394 s | 1.12626 s | 1.09375 s |

The searched resource cache explains the large improvement on nearby repeated
timestamps. Live dashboards still reconstruct 7,125 states on every request.
This is additional work even when resource-search documents hit their cache.
Focused graph cost depends on the selected next hop: small ETG neighborhoods
took about 3–27 ms; IP_ROUTING fanout reached the 500-node cap and took about
244–274 ms. It is a secondary cost here, not the several-second dominant path.

One exact-repeat dashboard occurrence took 3.642 s elapsed / 3.578 s CPU, with
unchanged before/after RSS (2,984,132,608 bytes) and private bytes
(2,979,966,976 bytes): ordinal 90, second round, audit move 059. Its output
matched. The separate attribution sample
does not explain that individual outlier; it is retained rather than discarded.
Do not treat sums of these component medians as measured browser latency.

## Root costs and memory

Separate cProfile samples corroborate the source paths:

- Search reconstructs all 7,510 resources so matching cross-kind counts remain
  correct. Of 5.087 instrumented seconds, `resource_search_text` accounts for
  3.520 s and `_resource_state_view` for 1.522 s (nested times overlap). Declared
  field traversal, disclosure projection, and 1,252,040 interval containment
  checks dominate. Kind filtering before search would change the result.
- Dashboards spend 3.239 of 3.342 instrumented seconds in 7,125 calls to
  `resource_state_at`: state selection, safe projection, and repeated descriptor
  and dataset access. They execute 1,250,200 interval containment checks. Output
  evaluation itself is a small fraction. A bounded displayed table does not
  bound the population reconstructed for dashboard evaluation.
- The sampled high-fanout graph returns 500 nodes/499 edges yet performs 504,120
  relationship-presence checks and 527,072 containment checks. Repeated endpoint
  history traversal remains measurable despite the output bound.

PE-A loaded RSS was **2.17407 GiB**. The first searched cursor took **6.8880 s
elapsed / 6.70313 s CPU** and raised RSS from **2.17408 to 2.76070 GiB**
(+600.70 MiB). The largest recorded query-boundary RSS was **2.77926 GiB**
(private bytes 2.77531 GiB). The scale adapter lazily expands and retains state
and lifecycle histories per resource; searching the complete population touches
these histories, unlike a bounded navigation sample. These are process RSS
snapshots from the broader historical-search/dashboard workload, not a sampled
lifetime peak and not directly comparable to the separate 52-phase navigation
peak. No allocation profiler was run, so the memory increase is not apportioned
precisely among interval histories, search documents, and allocator retention.

## Correctness and next improvement

All **64 exact-repeat pairs**, **64 cross-round occurrence pairs**, and **four
profile-versus-timed outputs** match complete JSON SHA-256 digests. All **33 unique
compressed response files** were decompressed and their complete bytes verified.
The controlled run retained at most one snapshot / 7,510 search documents;
the existing capacity remains two timestamps. Clearing before cases means this
run is not an independent eviction test. No new cache or index was introduced.

The lowest-risk follow-up is to reuse the existing loaded dataset, descriptor
lookup, and private reconstruction helper within the dashboard population loop,
while retaining its full safe publication projection and identical ordered
outputs. This removes thousands of redundant lookups without increasing retained
memory, though the measured lookup share suggests a modest gain. Next, prepare
declared field paths/disclosure rules once per query in the existing projection
logic; preserve dotted keys, ancestor rules, exact search text, and ownership.

For a larger gain, interval selection must stop rescanning complete histories,
and lazy histories should avoid retaining expanded per-event state dictionaries
for every searched resource. That requires preserving overlapping perspectives,
half-open/unbounded intervals, unknown lifecycle evidence, and failed operations;
it is a separate algorithm change, not justified as a quick cache expansion.
Increasing graph bounds or the timestamp cache does not address these causes.

Evidence: `all-results.json`, `summary.json`, four `*-profile.txt` / `.pstats`
files, and `responses/*.json.gz`. The launcher, profiler, verification script,
and complete run log are retained in the parent task directory.
