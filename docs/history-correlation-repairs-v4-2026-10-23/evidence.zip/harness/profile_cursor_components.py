"""Isolate production cursor operations; retain full digests, profile separately.

This is a task-local diagnostic, not a product benchmark or HTTP/browser timer.
Run with the demo Python 3.12 environment while other heavy work is idle.
"""
from __future__ import annotations

import argparse
import cProfile
import ctypes
from ctypes import wintypes
import gzip
import hashlib
import json
import os
from pathlib import Path
import platform
import pstats
import statistics
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
DEFAULT_OUT = Path(__file__).parent / "cursor-components"
ORIGIN_NS = 1759679999996000000
CASES = (
    (54, 360037500000, "dte-000001"),
    (55, 360037600000, "dte-000001"),
    (59, 480000000000, "dte-000000"),
    (60, 480037500000, "dte-000000"),
    (62, 480037600000, "dte-000001"),
    (63, 600675100000, "dte-000001"),
    (69, 600825000000, "dte-000001"),
    (71, 600750000000, "dte-000000"),
)


class ProcessMemory(ctypes.Structure):
    _fields_ = [("cb", wintypes.DWORD), ("PageFaultCount", wintypes.DWORD)] + [
        (name, ctypes.c_size_t) for name in (
            "PeakWorkingSetSize", "WorkingSetSize", "QuotaPeakPagedPoolUsage",
            "QuotaPagedPoolUsage", "QuotaPeakNonPagedPoolUsage", "QuotaNonPagedPoolUsage",
            "PagefileUsage", "PeakPagefileUsage", "PrivateUsage",
        )
    ]


def memory():
    value = ProcessMemory()
    value.cb = ctypes.sizeof(value)
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    psapi = ctypes.WinDLL("psapi", use_last_error=True)
    kernel.GetCurrentProcess.restype = wintypes.HANDLE
    psapi.GetProcessMemoryInfo.argtypes = [wintypes.HANDLE, ctypes.POINTER(ProcessMemory), wintypes.DWORD]
    if not psapi.GetProcessMemoryInfo(kernel.GetCurrentProcess(), ctypes.byref(value), value.cb):
        raise ctypes.WinError(ctypes.get_last_error())
    return {"rss": value.WorkingSetSize, "private": value.PrivateUsage}


def file_digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--fixture", type=Path, default=ROOT / "demo/fixtures/router-state-lab-algorithms-2026-10-02.tgz")
    parser.add_argument("--out", type=Path, default=DEFAULT_OUT)
    parser.add_argument("--stage", choices=("all", "latency", "profile"), default="all")
    parser.add_argument("--rounds", type=int, default=2)
    args = parser.parse_args()
    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=True)
    (out / "responses").mkdir(exist_ok=True)
    sys.path[:0] = [str(ROOT / "src"), str(ROOT / "demo"), str(ROOT / "state-dump-generator/src")]
    os.environ.setdefault("ROUTER_DUMP_SEARCH_CACHE_DIR", str(out / "search-cache"))
    from rsl_demo_plugin.session import runtime
    from router_dump_analyzer.normalized_data import NormalizedDataService
    from router_dump_analyzer.revision_queries import CorrelationQuery, RevisionQueryService

    records = []
    metadata = {
        "method": "Direct production service calls, sequential and isolated; excludes HTTP scheduling, browser work, serialization and digesting. cProfile runs are separate occurrences. RSS snapshots are not process peaks.",
        "fixture": str(args.fixture.resolve()), "fixture_bytes": args.fixture.stat().st_size,
        "fixture_sha256": file_digest(args.fixture), "python": sys.executable,
        "python_version": platform.python_version(), "pythonhashseed": os.environ.get("PYTHONHASHSEED", "random"),
        "search_cache_dir": os.environ["ROUTER_DUMP_SEARCH_CACHE_DIR"],
        "stage": args.stage, "rounds": args.rounds, "native_origin_ns": str(ORIGIN_NS),
        "source_sha256": {name: file_digest(ROOT / name) for name in (
            "src/router_dump_analyzer/normalized_data.py", "src/router_dump_analyzer/revision_queries.py",
            "demo/rsl_demo_plugin/scale_data.py", "frontend/assets/app.js",
        )},
        "controls": {"kinds": ["DTE"], "layers": [], "resource_limit": 500, "resource_offset": 0,
                     "graph_depth": 3, "graph_max_nodes": 500, "graph_direction": "both",
                     "dashboard_selection": "default-open descriptors requiring point-in-time query, matching frontend defaults"},
    }

    def flush():
        (out / f"{args.stage}-results.json").write_text(json.dumps({"metadata": metadata, "records": records}, indent=2), encoding="utf-8")

    def output_digest(value):
        encoded = json.dumps(value, sort_keys=True, ensure_ascii=True, separators=(",", ":")).encode("utf-8")
        digest = hashlib.sha256(encoded).hexdigest()
        target = out / "responses" / f"{digest}.json.gz"
        if not target.exists():
            target.write_bytes(gzip.compress(encoded, mtime=0))
        return digest, len(encoded)

    def measure(name, fn, *, response=True, **facts):
        before = memory()
        start, cpu = time.perf_counter(), time.process_time()
        value = fn()
        seconds, cpu_seconds = time.perf_counter() - start, time.process_time() - cpu
        after = memory()
        row = {"ordinal": len(records), "name": name, "seconds": seconds, "cpu_seconds": cpu_seconds,
               "memory_before": before, "memory_after": after, **facts}
        if response:
            row["sha256"], row["json_bytes"] = output_digest(value)
            if isinstance(value, dict):
                for key in ("matched_count", "returned_count", "counts_by_kind", "population_count", "truncated"):
                    if key in value:
                        row[key] = value[key]
                if "nodes" in value:
                    row.update(nodes=len(value["nodes"]), edges=len(value["edges"]))
        records.append(row)
        flush()
        print(json.dumps(row), flush=True)
        return value, row

    with runtime.open(args.fixture) as session:
        svc = NormalizedDataService(session.data_source, session.data_policy)
        revisions, _ = measure("archive_preparation", lambda: session.revision_store.assembly.revisions, response=False)
        revision = next(item for item in revisions if "/node-a/" in item.revision_id)
        dataset, _ = measure("node_a_load", lambda: svc.load_dataset(revision.revision_id), response=False)
        index = svc.history_runtime(dataset)
        queries = RevisionQueryService(svc, revision_id=revision.revision_id, dataset=dataset, indexed_history=index)
        descriptors = dataset.get("dashboard_descriptors") or dataset.get("schema", {}).get("dashboards", [])
        dashboard_ids = [str(item["dashboard_id"]) for item in descriptors if item.get("default_open") and (
            item.get("tables") or any(str(stat.get("aggregation", "count")) != "precomputed" and not stat.get("scale_metric")
                                      for stat in item.get("statistics", [])))]
        metadata.update(revision_id=revision.revision_id, resources=len(index.resources), events=len(index.events),
                        dashboard_ids=dashboard_ids)
        flush()

        def resources(offset_ns, search):
            with svc.revision_scope(revision.revision_id):
                return svc.resources_at(ORIGIN_NS + offset_ns, kinds={"DTE"}, search=search, limit=500)

        def graph(offset_ns, resource):
            return queries.correlation(CorrelationQuery(time_ns=ORIGIN_NS + offset_ns,
                resource_ids=(f"node-a/data-bridge-layer/DTE/blue/{resource}",), depth=3, max_nodes=500))

        def dashboards(offset_ns):
            with svc.revision_scope(revision.revision_id):
                return svc.dashboard_query(ORIGIN_NS + offset_ns, dashboard_ids=dashboard_ids)

        def cache_state():
            snapshots = index.resource_search._documents
            return {"snapshots": len(snapshots), "timestamps": [str(key) for key in snapshots],
                    "documents": sum(map(len, snapshots.values()))}

        # Explicitly separate first lazy history/search materialization from warm
        # point-in-time reconstruction. This timestamp is not in the timed cases.
        measure("first_lazy_searched_cursor", lambda: resources(600800000000, "dte-000000"), search="dte-000000", offset_ns=600800000000)
        if args.stage in {"all", "latency"}:
            for round_number in range(args.rounds):
                for audit_move, offset_ns, selected in CASES:
                    # Exact snapshot clearing is the sole experimental cache
                    # control; persistent histories remain warm for every arm.
                    index.resource_search._documents.clear()
                    modes = ("empty", "active") if round_number % 2 == 0 else ("active", "empty")
                    operations = [(f"resources_{mode}", lambda mode=mode: resources(offset_ns, selected if mode == "active" else "")) for mode in modes]
                    operations += [("focused_graph", lambda: graph(offset_ns, selected)), ("dashboards", lambda: dashboards(offset_ns))]
                    for component, operation in operations:
                        first_sha = None
                        for occurrence in ("first", "exact_repeat"):
                            _, row = measure(component, operation, round=round_number, audit_move=audit_move,
                                offset_ns=offset_ns, selected=selected, occurrence=occurrence,
                                cache_before=cache_state())
                            row["cache_after"] = cache_state()
                            if first_sha is None:
                                first_sha = row["sha256"]
                            else:
                                row["repeat_matches"] = row["sha256"] == first_sha
                                if not row["repeat_matches"]:
                                    flush()
                                    raise AssertionError(f"Exact-repeat output changed: {component}, audit move {audit_move}")
                            if row["cache_after"]["snapshots"] > 2:
                                raise AssertionError("Existing two-timestamp cache bound exceeded")
                            flush()

        if args.stage in {"all", "profile"}:
            offset_ns = 600750000000
            for name, operation in (
                ("resources_empty", lambda: resources(offset_ns, "")),
                ("resources_active", lambda: resources(offset_ns, "dte-000000")),
                ("focused_graph", lambda: graph(offset_ns, "dte-000000")),
                ("dashboards", lambda: dashboards(offset_ns)),
            ):
                index.resource_search._documents.clear()
                profiler = cProfile.Profile()
                profiler.enable()
                value = operation()
                profiler.disable()
                digest, encoded_bytes = output_digest(value)
                profiler.dump_stats(str(out / f"{name}.pstats"))
                with (out / f"{name}-profile.txt").open("w", encoding="utf-8") as stream:
                    pstats.Stats(profiler, stream=stream).sort_stats("cumulative").print_stats(70)
                records.append({"ordinal": len(records), "name": name, "profile_only": True,
                                "offset_ns": offset_ns, "sha256": digest, "json_bytes": encoded_bytes,
                                "cache_after": cache_state()})
                flush()

        summaries = {}
        for name in ("resources_empty", "resources_active", "focused_graph", "dashboards"):
            summaries[name] = {}
            for occurrence in ("first", "exact_repeat"):
                rows = [row for row in records if row["name"] == name and row.get("occurrence") == occurrence]
                if rows:
                    summaries[name][occurrence] = {"count": len(rows), "wall_median": statistics.median(row["seconds"] for row in rows),
                        "cpu_median": statistics.median(row["cpu_seconds"] for row in rows),
                        "wall_min": min(row["seconds"] for row in rows), "wall_max": max(row["seconds"] for row in rows)}
        metadata.update(summary=summaries, final_search_cache=cache_state())
        flush()
        print(json.dumps({"summary": summaries, "final_search_cache": cache_state()}), flush=True)


if __name__ == "__main__":
    main()
