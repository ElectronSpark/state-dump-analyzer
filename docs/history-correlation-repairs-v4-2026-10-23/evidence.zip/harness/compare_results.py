"""Compare complete ordered occurrences from the unchanged 1M harness."""
from __future__ import annotations

import argparse
from collections import Counter
import json
from pathlib import Path


def ends(result):
    return [row for row in result["records"] if row["kind"] == "end"]


def occurrence_rows(result):
    counts = Counter()
    rows = []
    for row in ends(result):
        counts[row["phase"]] += 1
        rows.append((f"{row['phase']}#{counts[row['phase']]}", row))
    return rows


def summary(result):
    completed = ends(result)
    loaded = next(row for row in completed if row["phase"] == "node_a_cold_load")
    return {
        "loaded_rss_gib": loaded["memory"]["rss_bytes"] / 1024**3,
        "peak_rss_gib": result["overall"]["lifetime_peak_rss_bytes"] / 1024**3,
        "peak_private_commit_gib": result["overall"]["lifetime_peak_commit_bytes"] / 1024**3,
        "phase_cpu_seconds": sum(row["cpu_seconds"] for row in completed),
        "elapsed_seconds": result["elapsed_seconds"],
        "sidecar_bytes": max(row.get("result", {}).get("sidecar_bytes", 0) for row in completed),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--baseline", type=Path, required=True)
    parser.add_argument("--after", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    baseline = json.loads(args.baseline.read_text(encoding="utf-8-sig"))
    after = json.loads(args.after.read_text(encoding="utf-8-sig"))
    before_rows, after_rows = occurrence_rows(baseline), occurrence_rows(after)
    before_map, after_map = dict(before_rows), dict(after_rows)
    before_metrics, after_metrics = summary(baseline), summary(after)
    invariant_kinds = ("search_before", "returned_search_before", "cache_retirement", "shared_search_cache", "validation_cache")
    def events(result, kind):
        return [row for row in result["records"] if row["kind"] == kind]
    def page_hashes(rows):
        return [(key, row["result"]["page_sha256"]) for key, row in rows if "page_sha256" in row.get("result", {})]
    ordered_keys = list(dict.fromkeys([key for key, _ in before_rows + after_rows]))
    result = {
        "method": "Latest quiet historical baseline versus fresh-process/search-cache 52-phase Windows workload. OS caches are not flushed; browser memory is excluded. Preserve every repeated phase occurrence.",
        "baseline_result": str(args.baseline),
        "after_result": str(args.after),
        "returncodes": [baseline["returncode"], after["returncode"]],
        "stop_reasons": [baseline["stop_reason"], after["stop_reason"]],
        "phase_counts": [len(before_rows), len(after_rows)],
        "phase_sequence_equal": [key for key, _ in before_rows] == [key for key, _ in after_rows],
        "phase_results_equal": [(key, row.get("result")) for key, row in before_rows] == [(key, row.get("result")) for key, row in after_rows],
        "different_phase_results": [key for key in ordered_keys if before_map.get(key, {}).get("result") != after_map.get(key, {}).get("result")],
        "page_hash_counts": [len(page_hashes(before_rows)), len(page_hashes(after_rows))],
        "page_hashes_equal": page_hashes(before_rows) == page_hashes(after_rows),
        "invariants_equal": {kind: events(baseline, kind) == events(after, kind) for kind in invariant_kinds},
        "baseline": before_metrics,
        "after": after_metrics,
        "delta": {key: after_metrics[key] - value for key, value in before_metrics.items()},
        "delta_percent": {key: (after_metrics[key] - value) / value * 100 if value else None for key, value in before_metrics.items()},
        "phase_measurements": [{"phase_occurrence": key,
            "baseline_wall_seconds": before_map.get(key, {}).get("seconds"),
            "after_wall_seconds": after_map.get(key, {}).get("seconds"),
            "baseline_cpu_seconds": before_map.get(key, {}).get("cpu_seconds"),
            "after_cpu_seconds": after_map.get(key, {}).get("cpu_seconds"),
        } for key in ordered_keys],
    }
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({key: value for key, value in result.items() if key != "phase_measurements"}, indent=2))


if __name__ == "__main__":
    main()
