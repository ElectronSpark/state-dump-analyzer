"""Task-local Windows measurement; production code and fixture stay unchanged."""
from __future__ import annotations

import argparse
import ctypes
from ctypes import wintypes
import gc
import hashlib
import json
import os
from pathlib import Path
import queue
import subprocess
import sys
import tempfile
import threading
import time
import traceback
import weakref

ROOT = Path(os.environ.get('RSL_MEASURE_SOURCE_ROOT', Path(__file__).resolve().parents[2])).resolve()
KERNEL = ctypes.WinDLL('kernel32', use_last_error=True)
PSAPI = ctypes.WinDLL('psapi', use_last_error=True)

class ProcessMemory(ctypes.Structure):
    _fields_ = [('cb', wintypes.DWORD), ('PageFaultCount', wintypes.DWORD)] + [
        (name, ctypes.c_size_t) for name in ['PeakWorkingSetSize', 'WorkingSetSize',
        'QuotaPeakPagedPoolUsage', 'QuotaPagedPoolUsage', 'QuotaPeakNonPagedPoolUsage',
        'QuotaNonPagedPoolUsage', 'PagefileUsage', 'PeakPagefileUsage', 'PrivateUsage']]

class SystemMemory(ctypes.Structure):
    _fields_ = [('dwLength', wintypes.DWORD), ('dwMemoryLoad', wintypes.DWORD)] + [
        (name, ctypes.c_ulonglong) for name in ['ullTotalPhys', 'ullAvailPhys',
        'ullTotalPageFile', 'ullAvailPageFile', 'ullTotalVirtual', 'ullAvailVirtual',
        'ullAvailExtendedVirtual']]

KERNEL.GetCurrentProcess.restype = wintypes.HANDLE
KERNEL.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
KERNEL.OpenProcess.restype = wintypes.HANDLE
KERNEL.CloseHandle.argtypes = [wintypes.HANDLE]
PSAPI.GetProcessMemoryInfo.argtypes = [wintypes.HANDLE, ctypes.POINTER(ProcessMemory), wintypes.DWORD]

def memory(handle=None):
    value = ProcessMemory(); value.cb = ctypes.sizeof(value)
    if not PSAPI.GetProcessMemoryInfo(handle or KERNEL.GetCurrentProcess(), ctypes.byref(value), value.cb):
        raise ctypes.WinError(ctypes.get_last_error())
    return {'rss_bytes': value.WorkingSetSize, 'private_bytes': value.PrivateUsage,
            'lifetime_peak_rss_bytes': value.PeakWorkingSetSize,
            'lifetime_peak_commit_bytes': value.PeakPagefileUsage,
            'page_fault_count': value.PageFaultCount}

def system_memory():
    value = SystemMemory(); value.dwLength = ctypes.sizeof(value)
    if not KERNEL.GlobalMemoryStatusEx(ctypes.byref(value)):
        raise ctypes.WinError(ctypes.get_last_error())
    return {'total_ram_bytes': value.ullTotalPhys, 'available_ram_bytes': value.ullAvailPhys,
            'available_commit_bytes': value.ullAvailPageFile}

def emit(value):
    print(json.dumps(value, ensure_ascii=True), flush=True)

def phase(name, operation, summarize=lambda result: {}):
    before = memory()
    emit({'kind': 'start', 'phase': name, 'memory': before})
    start = time.perf_counter(); cpu = time.process_time()
    result = operation()
    elapsed = time.perf_counter() - start; cpu_elapsed = time.process_time() - cpu
    emit({'kind': 'end', 'phase': name, 'seconds': elapsed, 'cpu_seconds': cpu_elapsed,
          'memory': memory(), 'result': summarize(result)})
    return result

def child(args):
    sys.path[:0] = [str(ROOT / 'src'), str(ROOT / 'demo'), str(ROOT / 'state-dump-generator/src')]
    emit({'kind': 'environment', 'pid': os.getpid(), 'python': sys.version,
          'archive': str(args.archive), 'archive_bytes': args.archive.stat().st_size,
          'search_cache': os.environ['ROUTER_DUMP_SEARCH_CACHE_DIR'],
          'source_root': str(ROOT),
          'python_hash_seed': os.environ.get('PYTHONHASHSEED', 'random'),
          'source_hashes': {name: hashlib.sha256((ROOT / 'src/router_dump_analyzer' / name).read_bytes()).hexdigest()
                            for name in ('normalized_data.py', 'plugin_identity.py', 'revision_queries.py', 'history_search_core.py',
                                         '_history_search_cache.py', '_history_search_validation.py')
                            if (ROOT / 'src/router_dump_analyzer' / name).exists()},
          'system_memory': system_memory(), 'memory': memory()})
    def imports():
        from rsl_demo_plugin.session import runtime
        from router_dump_analyzer.normalized_data import NormalizedDataService
        from router_dump_analyzer.revision_queries import RevisionQueryService, EventLogQuery
        return runtime, NormalizedDataService, RevisionQueryService, EventLogQuery
    runtime, DataService, QueryService, LogQuery = phase('runtime_import', imports)
    context = runtime.open(args.archive)
    session = phase('runtime_open', context.__enter__)
    service = phase('core_service_setup', lambda: DataService(session.data_source, session.data_policy))
    descriptors = phase('archive_preparation', lambda: session.revision_store.assembly.revisions,
        lambda values: {'revisions': [{'revision_id': r.revision_id, 'node_id': r.node_id,
                                      'events': r.event_count, 'resources': r.resource_count} for r in values],
                        'runtime_cache_size': session.revision_store._materialized().cache_size})
    node_a, node_b = descriptors[:2]

    def dataset_summary(ds):
        return {'events': ds['demo']['event_count'], 'resources': ds['demo']['resource_count'],
                'revision_id': ds['demo']['revision_id'], 'cached_revisions': session.revision_store.loaded_revision_ids()}

    ds = phase('node_a_cold_load', lambda: service.load_dataset(node_a.revision_id), dataset_summary)
    bootstrap = phase('node_a_bootstrap', lambda: service.client_dataset(node_a.revision_id),
                      lambda payload: {'resources_returned': len(payload.get('resources', [])),
                                       'events_returned': len(payload.get('events', []))})
    del bootstrap
    def queries(ds):
        return QueryService(service, revision_id=service.current_revision_id(ds), dataset=ds,
                            indexed_history=service.history_runtime(ds))
    q = phase('node_a_query_setup', lambda: queries(ds))
    emit({'kind': 'search_before', 'status': q.indexed_history.event_search.status_snapshot()})

    def search_summary(page):
        status = q.indexed_history.event_search.status_snapshot()
        sidecar = q.indexed_history.event_search.sidecar_path
        corpus = q.indexed_history.event_search
        return {'total_count': page['total_count'], 'returned_count': page['returned_count'],
                'page_sha256': hashlib.sha256(json.dumps(page, sort_keys=True, ensure_ascii=False, separators=(',', ':')).encode('utf-8')).hexdigest(),
                'search': status, 'sidecar_bytes': sidecar.stat().st_size if sidecar and sidecar.exists() else 0,
                'cached_bytes': getattr(corpus, '_cached_bytes', None),
                'cached_results': {term: {'count': len(matches), 'kind': getattr(matches, 'kind', None),
                                          'bytes': getattr(matches, 'nbytes', None)}
                                   for term, matches in corpus._results.items()}}

    for name, term in [('first_search_failure', 'failure'), ('warm_same_search_failure', 'failure'),
                       ('warm_other_search_success', 'success')]:
        page = phase(name, lambda term=term: q.event_log(LogQuery(source_types=(), search=term, limit=100)), search_summary)
        del page
    # Keep the repeated and refined queries separate for comparable phase peaks.
    for repeat in range(args.repeats):
        page = phase(f'dense_search_{repeat + 1}',
                     lambda: q.event_log(LogQuery(source_types=(), search=args.dense_term, limit=100)), search_summary)
        del page
    for term in ('fail', 'failu', 'failure', 'failure missing-literal-probe'):
        page = phase('refined_search_' + term,
                     lambda term=term: q.event_log(LogQuery(source_types=(), search=term, limit=100)), search_summary)
        del page
    from router_dump_analyzer.revision_queries import event_layer_values, EventDensityQuery
    runtime_a = q.indexed_history
    layers = sorted({layer for event in runtime_a.events[:1000] for layer in event_layer_values(event)})
    if layers:
        for offset in (0, 100, 1000, 0, 100, 1000):
            page = phase(f'layer_page_{layers[0]}_{offset}',
                         lambda offset=offset: q.event_log(LogQuery(source_types=(), search=args.dense_term,
                                                                  layers=(layers[0],), offset=offset, limit=100)), search_summary)
            del page
    else:
        emit({'kind': 'coverage_skip', 'case': 'layer_pagination', 'reason': 'first 1000 events have no declared layer'})
    if len(runtime_a.event_times):
        start_ns, end_ns = int(runtime_a.event_times[0]), int(runtime_a.event_times[-1])
        bins = min(256, end_ns - start_ns + 1)
        for repeat in range(3):
            page = phase(f'zoom_density_{repeat + 1}',
                         lambda: q.event_density(EventDensityQuery(start_ns, end_ns, bins, bins, 0, bins)),
                         lambda value: {'response_keys': sorted(value)})
            del page
    # Repair-specific probes supplement the unchanged 40-phase navigation sequence.
    def log_summary(page):
        return {'total_count': page['total_count'], 'returned_count': page['returned_count'],
                'located_display_index': page.get('located_display_index'),
                'page_sha256': hashlib.sha256(json.dumps(page, sort_keys=True, ensure_ascii=False, separators=(',', ':')).encode('utf-8')).hexdigest()}
    probe_specs = [
        ('normalized_locate', dict(source_types=(), locate=('event', 'node-a/scale-event-00000000'))),
        ('ctf_locate', dict(include_normalized=False, source_types=('ctf',), locate=('source', 'source-ctf-unmatched-000003'))),
        ('merged_locate', dict(source_types=('ctf',), locate=('source', 'source-ctf-unmatched-000003'))),
        ('merged_target_page', dict(source_types=('ctf',), offset=3000)),
        ('merged_deep_page', dict(source_types=('ctf',), offset=1252385)),
        ('merged_deep_locate', dict(source_types=('ctf',), locate=('event', 'node-a/scale-event-01249999'))),
    ]
    for name, kwargs in probe_specs:
        for repeat in (1, 2):
            page = phase(f'{name}_{repeat}', lambda kwargs=kwargs: q.event_log(LogQuery(limit=120, **kwargs)), log_summary)
            del page
    try:
        retired_runtime = weakref.ref(runtime_a)
    except TypeError:
        retired_runtime = None
    def cache_snapshot(label):
        emit({'kind': 'cache_retirement', 'label': label,
              'runtime_a_alive': retired_runtime() is not None if retired_runtime else None,
              'service_caches': {name: len(getattr(service, name, {})) for name in
                                 ('_density_query_indexes', '_timeline_query_indexes', '_event_layer_matches')},
              'loaded_revisions': session.revision_store.loaded_revision_ids()})
        try:
            from router_dump_analyzer._history_search_cache import _shared_results
        except ImportError:
            emit({'kind': 'shared_search_cache', 'label': label, 'available': False})
        else:
            emit({'kind': 'shared_search_cache', 'label': label, 'available': True,
                  'entries': len(_shared_results._entries), 'bytes': _shared_results._bytes,
                  'max_entries': _shared_results._max_entries, 'max_bytes': _shared_results._max_bytes})
        try:
            from router_dump_analyzer._history_search_validation import _validated_compressed
        except ImportError:
            emit({'kind': 'validation_cache', 'label': label, 'available': False})
        else:
            emit({'kind': 'validation_cache', 'label': label, 'available': True,
                  'entries': len(_validated_compressed._entries), 'bytes': _validated_compressed._bytes,
                  'max_entries': _validated_compressed._max_entries, 'max_bytes': _validated_compressed._max_bytes})
    del runtime_a, q
    ds.release(); del ds
    phase('release_a_before_switch', gc.collect, lambda count: {'collected': count})
    ds = phase('switch_to_b_cold_load', lambda: service.load_dataset(node_b.revision_id), dataset_summary)
    ds.release(); del ds
    phase('release_b_before_return', gc.collect, lambda count: {'collected': count})
    cache_snapshot('after_switch_to_b_gc')
    ds = phase('return_to_a_load', lambda: service.load_dataset(node_a.revision_id), dataset_summary)
    q = phase('returned_a_query_setup', lambda: queries(ds))
    emit({'kind': 'returned_search_before', 'status': q.indexed_history.event_search.status_snapshot()})
    page = phase('return_to_a_search_sidecar', lambda: q.event_log(LogQuery(source_types=(), search='failure', limit=100)), search_summary)
    del page
    for name, term in [('return_to_a_search_success', 'success'),
                       ('return_to_a_search_fail', 'fail'),
                       ('return_to_a_search_absent', 'failure missing-literal-probe'),
                       ('return_to_a_search_new_interface', 'interface')]:
        page = phase(name,
                     lambda term=term: q.event_log(LogQuery(source_types=(), search=term, limit=100)),
                     search_summary)
        del page
    del q
    ds.release(); del ds
    phase('runtime_close', lambda: context.__exit__(None, None, None))
    cache_snapshot('after_runtime_close')
    del service, session
    phase('final_gc', gc.collect, lambda count: {'collected': count})
    emit({'kind': 'complete', 'memory': memory(), 'system_memory': system_memory()})

def supervise(args):
    args.output.mkdir(parents=True, exist_ok=False)
    search_cache = Path(tempfile.mkdtemp(prefix='rsl-million-measure-search-')).resolve()
    env = os.environ.copy()
    env['ROUTER_DUMP_SEARCH_CACHE_DIR'] = str(search_cache)
    env['PYTHONPYCACHEPREFIX'] = str(args.output / 'pycache')
    command = [sys.executable, str(Path(__file__).resolve()), '--child', '--archive', str(args.archive), '--dense-term', args.dense_term, '--repeats', str(args.repeats)]
    child_log = (args.output / 'child.jsonl').open('w', encoding='utf-8')
    errors = (args.output / 'stderr.log').open('w', encoding='utf-8')
    proc = subprocess.Popen(command, cwd=ROOT, env=env, stdout=subprocess.PIPE, stderr=errors, text=True, encoding='utf-8')
    handle = KERNEL.OpenProcess(0x0400 | 0x0010, False, proc.pid)
    if not handle:
        proc.terminate(); raise ctypes.WinError(ctypes.get_last_error())
    events = queue.Queue()
    def consume():
        for line in proc.stdout:
            child_log.write(line); child_log.flush()
            try: events.put(json.loads(line))
            except ValueError: events.put({'kind': 'non_json', 'text': line})
    reader = threading.Thread(target=consume, daemon=True); reader.start()
    started = time.monotonic(); active = 'startup'; records = []; peaks = {}; stop_reason = None
    overall = {'rss_bytes': 0, 'private_bytes': 0, 'lifetime_peak_rss_bytes': 0, 'lifetime_peak_commit_bytes': 0}
    with (args.output / 'memory.jsonl').open('w', encoding='utf-8') as samples:
        while proc.poll() is None:
            while not events.empty():
                event = events.get(); records.append(event)
                if event['kind'] == 'start': active = event['phase']
                if event['kind'] in {'start', 'end', 'complete', 'error'}: emit(event)
            try:
                sample = memory(handle); host = system_memory()
            except OSError:
                time.sleep(.1); continue
            bucket = peaks.setdefault(active, {'sampled_peak_rss_bytes': 0, 'sampled_peak_private_bytes': 0})
            bucket['sampled_peak_rss_bytes'] = max(bucket['sampled_peak_rss_bytes'], sample['rss_bytes'])
            bucket['sampled_peak_private_bytes'] = max(bucket['sampled_peak_private_bytes'], sample['private_bytes'])
            for key in overall: overall[key] = max(overall[key], sample[key])
            samples.write(json.dumps({'seconds': time.monotonic()-started, 'phase': active, **sample,
                                      'host_available_ram_bytes': host['available_ram_bytes']})+'\n')
            if host['available_ram_bytes'] < 6 * 1024**3 or sample['private_bytes'] > 32 * 1024**3:
                stop_reason = 'memory_guard'; proc.terminate()
            elif time.monotonic()-started > 1800:
                stop_reason = '30_minute_guard'; proc.terminate()
            time.sleep(.1)
    proc.wait(); reader.join(5)
    while not events.empty(): records.append(events.get())
    KERNEL.CloseHandle(handle); child_log.close(); errors.close()
    for event in records:
        for key in overall: overall[key] = max(overall[key], event.get('memory', {}).get(key, 0))
    result = {'command': command, 'returncode': proc.returncode, 'stop_reason': stop_reason,
              'elapsed_seconds': time.monotonic()-started, 'sample_interval_seconds': .1,
              'search_cache': str(search_cache), 'overall': overall,
              'phase_sampled_peaks': peaks, 'records': records}
    (args.output/'result.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
    emit({'kind': 'supervisor_complete', 'returncode': proc.returncode, 'elapsed_seconds': result['elapsed_seconds'],
          'overall': overall, 'result_file': str(args.output/'result.json')})
    return proc.returncode

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--archive', type=Path, required=True)
    parser.add_argument('--output', type=Path)
    parser.add_argument('--dense-term', default='success')
    parser.add_argument('--repeats', type=int, default=5)
    parser.add_argument('--child', action='store_true')
    args = parser.parse_args(); args.archive = args.archive.resolve()
    try:
        if args.child: child(args)
        else: raise SystemExit(supervise(args))
    except Exception as error:
        emit({'kind': 'error', 'error': repr(error), 'memory': memory()})
        traceback.print_exc(); raise
