"""Task-only bounded direct-helper attribution probe; no application imports."""
from pathlib import Path
import hashlib
import json
import statistics
import subprocess
import time

root = Path(__file__).resolve().parents[2]
destination = Path(__file__).resolve().parent
relative = 'demo/rsl_demo_plugin/scale.py'
old_source = subprocess.check_output(['git', 'show', f'HEAD:{relative}'], cwd=root)
new_source = (root / relative).read_bytes()
versions = {}
for name, source in [('head', old_source), ('current', new_source)]:
    namespace = {'__name__': f'_task_label_probe_{name}'}
    exec(compile(source, f'<{name}-scale.py>', 'exec'), namespace)
    versions[name] = namespace

specs = [
    ('VIRTUAL_INTERFACE', 'node-a/data-bridge-layer/VIRTUAL_INTERFACE/interface:Ethernet1/1.310', 'data-bridge-layer', {'interface_name':'Ethernet1/1.310'}),
    ('VIRTUAL_INTERFACE', 'transit-p-2/data-bridge-layer/VIRTUAL_INTERFACE/Ethernet4/1', 'data-bridge-layer', {}),
    ('VIRTUAL_INTERFACE', 'node-a/data-bridge-layer/VIRTUAL_INTERFACE/ae-00001', 'data-bridge-layer', {}),
    ('DTE', 'node-a/data-bridge-layer/DTE/blue/dte-000001', 'data-bridge-layer', {}),
    ('ETE', 'node-a/hardware-driver-layer/ETE/blue/ete-000001', 'hardware-driver-layer', {}),
    ('ETG', 'node-a/data-bridge-layer/ETG/blue/etg-000001', 'data-bridge-layer', {}),
    ('EVPN_ES', 'node-a/control-plane/EVPN_ES/es-00001', 'control-plane', {}),
    ('IP_ROUTING', 'node-a/control-plane/IP_ROUTING/blue', 'control-plane', {}),
]
rows = []
for kind, identifier, layer, key in specs:
    fields = dict(KIND=kind, RESOURCE_ID=identifier, LAYER=layer, VRF='blue', ADMIN='up', OPER='up')
    values = tuple(fields.get(column, '') for column in versions['head']['RESOURCE_TABLE_COLUMNS'])
    rows.append((values, json.dumps(key), '{"status":"up"}'))
labels = [spec[1] for spec in specs]

def execute(version, target, loops):
    if target == 'label':
        function = versions[version]['scale_resource_label']
        for _ in range(loops):
            for identifier in labels:
                function(identifier)
    else:
        function = versions[version]['scale_resource_record']
        for _ in range(loops):
            for values, key, state in rows:
                function(values, key_json=key, state_json=state)

for version in versions:
    for target in ('label', 'record'):
        execute(version, target, 50)

all_start_cpu = time.process_time()
results = {}
for target, loops in [('label', 10000), ('record', 2500)]:
    start_cpu = time.process_time()
    pairs = []
    while time.process_time() - start_cpu < 0.8:
        order = ['head', 'current'] if len(pairs) % 2 == 0 else ['current', 'head']
        pair = {'ordinal':len(pairs)+1, 'order':order, 'calls_per_version':loops*len(specs)}
        for version in order:
            cpu = time.process_time()
            wall = time.perf_counter()
            execute(version, target, loops)
            pair[version] = {'wall_seconds':time.perf_counter()-wall, 'cpu_seconds':time.process_time()-cpu}
        pairs.append(pair)
    total_calls = sum(pair['calls_per_version'] for pair in pairs)
    metric = {}
    for clock in ('cpu_seconds', 'wall_seconds'):
        old_total = sum(pair['head'][clock] for pair in pairs)
        new_total = sum(pair['current'][clock] for pair in pairs)
        metric[clock] = {
            'head_total':old_total, 'current_total':new_total,
            'head_per_7510':old_total / total_calls * 7510,
            'current_per_7510':new_total / total_calls * 7510,
            'delta_per_7510':(new_total-old_total) / total_calls * 7510,
            'median_pair_delta_per_7510':statistics.median((p['current'][clock]-p['head'][clock])/p['calls_per_version']*7510 for p in pairs),
            'max_observed_pair_delta_per_7510':max((p['current'][clock]-p['head'][clock])/p['calls_per_version']*7510 for p in pairs),
        }
    results[target] = {'total_calls_per_version':total_calls, 'measurements':metric, 'pairs':pairs}

output = {
    'head_sha256':hashlib.sha256(old_source).hexdigest(),
    'current_sha256':hashlib.sha256(new_source).hexdigest(),
    'measurement_cpu_seconds':time.process_time()-all_start_cpu,
    'representative_rows':specs,
    'resource_count_assumption':7510,
    'method':'Warm in-process paired interleaved calls; identical 8-row input mix; current labels intentionally differ. No archive loading, network, browser, history scans, source edits, or route service. Whole record already includes its label call; do not add the two timings.',
    'caveat':'This is an empirical direct-helper estimate, not a rigorous upper bound. Input mix is representative, not archive-weighted. Windows process CPU clock is quantized. Does not measure indirect allocation/GC/serialization or resolve historical whole-workload variation.',
    'results':results,
}
(destination/'label-helper-microbench.json').write_text(json.dumps(output,indent=2)+'\n',encoding='utf-8')
print(json.dumps({**{k:v for k,v in output.items() if k!='results'},'results':{k:{key:value for key,value in v.items() if key!='pairs'} for k,v in results.items()}},indent=2))
