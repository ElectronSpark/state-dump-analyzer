"""Verify all response archives and summarize the completed diagnostic run."""
import gzip
import hashlib
import json
from pathlib import Path

OUT = Path(__file__).parent / "cursor-components"
result = json.loads((OUT / "all-results.json").read_text(encoding="utf-8"))
records = result["records"]
timed = [row for row in records if "round" in row]
repeats = [row for row in timed if row["occurrence"] == "exact_repeat"]
profiles = [row for row in records if row.get("profile_only")]
digest_rows = [row for row in records if "sha256" in row]
digests = {row["sha256"] for row in digest_rows}
verification = []
for digest in sorted(digests):
    data = gzip.decompress((OUT / "responses" / f"{digest}.json.gz").read_bytes())
    actual = hashlib.sha256(data).hexdigest()
    assert actual == digest
    json.loads(data)
    verification.append({"file": f"responses/{digest}.json.gz", "expected_sha256": digest,
        "actual_sha256": actual, "uncompressed_bytes": len(data), "json_valid": True,
        "occurrences": [row["ordinal"] for row in digest_rows if row["sha256"] == digest]})
cross_round = []
for row in timed:
    if row["round"] != 0:
        continue
    counterpart = next(other for other in timed if other["round"] == 1
        and (other["name"], other["audit_move"], other["occurrence"]) == (row["name"], row["audit_move"], row["occurrence"]))
    cross_round.append(row["sha256"] == counterpart["sha256"])
profile_matches = {row["name"]: any(other["name"] == row["name"] and other["offset_ns"] == row["offset_ns"]
        and other["sha256"] == row["sha256"] for other in timed) for row in profiles}
memory = [(row["ordinal"], where, row[where]) for row in records for where in ("memory_before", "memory_after") if where in row]
largest_rss = max(memory, key=lambda item: item[2]["rss"])
loaded = next(row for row in records if row["name"] == "node_a_load")
lazy = next(row for row in records if row["name"] == "first_lazy_searched_cursor")
summary = {
    "timed_component_occurrences": len(timed), "exact_repeat_pairs": len(repeats),
    "exact_repeat_matches": sum(row["repeat_matches"] for row in repeats),
    "cross_round_pairs": len(cross_round), "cross_round_matches": sum(cross_round),
    "profile_output_matches": profile_matches, "verified_full_response_digests": len(digests),
    "cache_max_observed_snapshots": max(row.get("cache_after", {}).get("snapshots", 0) for row in records),
    "cache_max_observed_documents": max(row.get("cache_after", {}).get("documents", 0) for row in records),
    "cache_control": "Cleared before each fresh timestamp case and separate profile; no cache capacity or product code was changed. Existing capacity is two timestamps; this controlled sequence retained at most one.",
    "loaded_rss_gib": loaded["memory_after"]["rss"] / 2**30,
    "first_lazy": {"seconds": lazy["seconds"], "cpu_seconds": lazy["cpu_seconds"],
        "rss_before_gib": lazy["memory_before"]["rss"] / 2**30, "rss_after_gib": lazy["memory_after"]["rss"] / 2**30,
        "rss_increase_mib": (lazy["memory_after"]["rss"] - lazy["memory_before"]["rss"]) / 2**20},
    "largest_rss_snapshot": {"ordinal": largest_rss[0], "phase": largest_rss[1], "gib": largest_rss[2]["rss"] / 2**30,
        "private_gib": largest_rss[2]["private"] / 2**30},
    "memory_limit": "Before/after query snapshots from an all-resource historical search and live-dashboard workload; not a sampled process lifetime peak and not directly comparable to the 52-phase navigation workload.",
    "dashboard_ids": result["metadata"]["dashboard_ids"], "components": result["metadata"]["summary"],
    "focused_graph_cases": [{key: row[key] for key in ("audit_move", "offset_ns", "selected", "nodes", "edges", "truncated", "seconds")}
        for row in timed if row["name"] == "focused_graph" and row["round"] == 0 and row["occurrence"] == "first"],
}
(OUT / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
(OUT / "response-verification.json").write_text(json.dumps(verification, indent=2), encoding="utf-8")
print(json.dumps(summary, indent=2))
