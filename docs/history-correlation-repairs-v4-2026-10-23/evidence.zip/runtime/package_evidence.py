from pathlib import Path
import hashlib
import json
import zipfile

root = Path(__file__).resolve().parents[2]
runtime = Path(__file__).resolve().parent
target = root / 'docs/history-correlation-repairs-v4-2026-10-23'
target.mkdir(parents=True, exist_ok=True)
files = {}
def add(path, name):
    if path.is_file():
        files[name] = path
for path in runtime.iterdir():
    if path.is_file():
        add(path, 'runtime/' + path.name)
for dirname in ('browser', 'cursor-components', 'skill-trial', 'after-1m-quiet'):
    for path in (runtime / dirname).rglob('*'):
        if any(part in {'pycache', '__pycache__', 'cache', 'search-cache'} for part in path.parts):
            continue
        if path.suffix in {'.pyc', '.sqlite', '.db', '.tmp'}:
            continue
        add(path, 'runtime/' + path.relative_to(runtime).as_posix())
for name in ('measure.py', 'compare_results.py', 'profile_cursor_components.py'):
    add(root / '.runtime/history-correlation-repairs-v2-2026-10-23' / name, 'harness/' + name)
add(root / '.runtime/history-correlation-repairs-v3-2026-10-23/after-1m-quiet/result.json', 'baseline/result.json')
for name in ('router-plugin-author', 'router-plugin-validate'):
    add(root / '.agents/skills' / name / 'SKILL.md', 'skills/' + name + '/SKILL.md')
manifest = []
archive = target / 'evidence.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, path in sorted(files.items()):
        data = path.read_bytes()
        z.writestr(name, data)
        manifest.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
with zipfile.ZipFile(archive) as z:
    for entry in manifest:
        data = z.read(entry['path'])
        assert len(data) == entry['bytes']
        assert hashlib.sha256(data).hexdigest() == entry['sha256']
payload = {'archive': archive.name, 'bytes': archive.stat().st_size,
           'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
           'verified_entries': len(manifest), 'entries': manifest}
(target / 'evidence-manifest.json').write_text(json.dumps(payload, indent=2) + '\n', encoding='utf-8')
for src, dest in [('15-width-resize-popup.png', 'resize-popup.png'), ('06-interface-label.png', 'interface-label.png'), ('04-cold-controls.png', 'startup-controls.png')]:
    if (runtime / 'browser' / src).exists():
        (target / dest).write_bytes((runtime / 'browser' / src).read_bytes())
print(json.dumps({k: v for k, v in payload.items() if k != 'entries'}))
