$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath ([IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..')))
$taskTemp = Join-Path $PSScriptRoot 'cursor-temp'
New-Item -ItemType Directory -Force -Path $taskTemp | Out-Null
$env:TEMP = $taskTemp
$env:TMP = $taskTemp
$env:PYTHONHASHSEED = '0'
$env:PYTHONUTF8 = '1'
$env:PYTHONIOENCODING = 'utf-8'
& 'C:/Users/82046/anaconda3/envs/router-dump-analyzer-demo/python.exe' -B -X utf8 '.runtime/history-correlation-repairs-v2-2026-10-23/profile_cursor_components.py' --fixture 'demo/fixtures/router-state-lab-history-correlation-2026-10-23.tgz' --out (Join-Path $PSScriptRoot 'cursor-components') --stage all --rounds 2
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
