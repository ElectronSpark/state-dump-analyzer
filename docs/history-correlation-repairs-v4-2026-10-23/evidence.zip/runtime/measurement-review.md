# Independent review of the v4 1M rerun

Reviewed the raw v3 and v4 `result.json` records independently of the existing comparator. Both runs exited successfully, with no supervisor stop reason. All **52 ordered phase occurrences**, including repeated layer-page phases, have identical result objects. All **35 ordered page hashes** and all five invariant groups (initial/returned search status, cache retirement, shared search cache, validation cache) match. The fixture path and byte count, Python build, and all six recorded core source hashes match. Independent machine-readable verification is in `measurement-review.json`.

| Metric | v3 baseline | v4 rerun |
| --- | ---: | ---: |
| Loaded process RSS | 2.176380 GiB | 2.175423 GiB |
| Lifetime peak RSS | 2.254776 GiB | 2.254967 GiB |
| Lifetime peak private commit | 2.248905 GiB | 2.248951 GiB |
| Sum of phase CPU | 152.968750 s | 187.546875 s |
| Overall elapsed | 157.703 s | 196.750 s |
| Sidecar size | 75,038,720 bytes | 75,038,720 bytes |

Memory and disk footprint are effectively unchanged in this pair. CPU increased **34.578125 s / 22.60%**, and elapsed increased **39.047 s / 24.76%**. Do not report CPU as unchanged or improved.

The three largest contributors account for **83.69%** of the CPU increase:

| Phase | Baseline CPU | Rerun CPU | Difference |
| --- | ---: | ---: | ---: |
| First event search / projection | 38.343750 s | 48.296875 s | +9.953125 s |
| Return to node A load | 25.734375 s | 35.531250 s | +9.796875 s |
| Switch to node B cold load | 26.640625 s | 35.828125 s | +9.187500 s |

Archive preparation adds 1.671875 s; the initial node-A load adds only 0.562500 s. Many smaller later operations also take longer. Timing uses Windows process CPU time, with 15.625 ms quantization visible for short operations; do not infer meaningful sub-millisecond CPU changes from those phases.

Source review does not establish that these fixes caused the slowdown. This harness does not run frontend JavaScript or request the lazy route provider, so the startup/resize changes and route label map are outside its executed workflow. The packed-resource label change does execute during loading, but its additional work is a string partition/name preference per resource (about 7,510 resources per node), not per event. The million-row event loader, search projection, query implementation, and relevant cache implementations were not changed; their recorded core hashes are identical. This makes a direct new million-row loop in the patch unsupported by the evidence. It does not prove zero indirect effect or exclude a regression.

These are two historical measurements, not an interleaved same-session A/B experiment. Each uses a fresh process and search cache; OS caches are not flushed, Python hash seeds are random, and CPU frequency, thermal state, contention, and per-phase profiles are not recorded. Both began with more than 43 GiB physical memory available, so the recorded startup snapshot does not suggest RAM exhaustion, but it cannot exclude transient activity later. Calling the entire difference “noise” would be unsubstantiated. A quiet interleaved baseline/current rerun with a fixed hash seed and phase profiling would be needed to attribute the CPU increase. No additional heavy run was launched during browser validation.

This workload tests event-log search/navigation and process memory. It does not itself validate the repaired interface display names or interactive cursor latency; those need the separate browser checks and cursor-component profile.

A smaller paired attribution experiment is possible, but the slow phases should not be measured independently. Preserve archive preparation → A load → first search/projection → release and GC → B load → release and GC → A reload, with identical fresh sidecars, fixed hash seed, fixture and process setup. Keeping the lifetime/GC sequence matters for later loads. This reduced comparison could investigate label-helper causation, but would not replace the full 52-phase navigation result. A cheap initial discriminator is an old/current helper microbenchmark on identical packed-resource rows plus invocation counts in one load. Only if its observed total work can explain seconds of change should the label path become the leading suspect. Full interleaved old/current harness runs are preferable before claiming that the whole-workload CPU difference is resolved; another current-only sample cannot isolate source from environmental changes.

## Bounded direct-helper experiment

At the parent's request, ran `microbench_labels.py`, which loads the exact HEAD and working-tree `scale.py` source into separate namespaces and alternates old/current order on the same eight representative inputs. They include declared `Ethernet1/1.310`, undeclared `Ethernet4/1`, a synthetic aggregate interface, and DTE/ETE/ETG/EVPN_ES/IP_ROUTING rows. The timed loops consumed **1.65625 s process CPU** total. Full source hashes, inputs, individual paired samples, and caveats are in `label-helper-microbench.json`. No fixture, source, server or browser state was changed.

| Direct operation | Calls per version | Old wall estimate / 7,510 calls | Current wall estimate / 7,510 calls | Difference |
| --- | ---: | ---: | ---: | ---: |
| `scale_resource_label` | 1,280,000 | 2.500 ms | 2.540 ms | +0.039 ms |
| Complete `scale_resource_record` | 160,000 | 19.882 ms | 20.106 ms | +0.224 ms |

The complete-record operation already calls the label helper; do not add both rows. Windows CPU-clock quantization yields a complete-record aggregate estimate of **+2.934 ms per 7,510 calls** and maximum observed paired CPU estimate of **+11.734 ms**. The maximum observed paired wall estimate is **+1.337 ms**. These are empirical extrapolations, not a rigorous worst-case bound, and the representative mix is not weighted to the actual archive. Invocation frequency was inferred from the existing per-resource loader loop, not instrumented by loading the archive again. Indirect effects on allocation, GC and later serialization are outside this probe.

This evidence places the direct helper overhead in the millisecond range for one node's resource inventory, well below the approximately nine-second changes in the large load/search phases. It does not explain or resolve the overall CPU increase, but it argues against the direct label computation as its principal cause.

Documentation drift check: this review creates only task-local evidence and makes no public plug-in API or authoring behavior change. No maintained author documentation update is required for this review.
