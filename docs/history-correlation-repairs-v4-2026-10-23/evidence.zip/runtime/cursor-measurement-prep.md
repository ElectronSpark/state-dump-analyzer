# V4 cursor and 1M measurement preparation

Read-only product investigation at HEAD 4f49279e9192709aa81b5fa305b69051708d4e51. No benchmark, browser/server operation, fixture decode, or product modification performed.

Verified executable: C:/Users/82046/anaconda3/envs/router-dump-analyzer-demo/python.exe, Python 3.12.13. Imports router_dump_analyzer, rsl_demo_plugin, rsl_demo_generator, fastapi, pydantic, uvicorn, httpx succeeded. Default PATH Python lacks fastapi. Optional psutil is absent from demo Python; neither established harness needs it (Windows ctypes memory counters). Use only the verified demo interpreter. Conformance inventory --list passed (8 groups); this is inventory, not behavioral coverage.

## Identity and interpretation

Current v4 fixture: demo/fixtures/router-state-lab-history-correlation-2026-10-23.tgz, 286504605 bytes, SHA256 5f204e5836be8966f148ae14671f9488007970619cff094cc9bda60c71892105, as saved by prior generation and v4 audit (not reread here). PE-A 1250005 events/7510 resources. The best comparable 1M baseline is .runtime/history-correlation-repairs-v3-2026-10-23/after-1m-quiet/result.json: same fixture, 52 ordered phases, 35 page digests, dense-term success/repeats 5. Loaded RSS 2.1763802 GiB, lifetime peak RSS 2.2547760 GiB, peak private commit 2.2489052 GiB, summed phase CPU 152.96875 s, elapsed 157.703 s, sidecar 75038720 bytes. Preserve repeated phase occurrences; do not deduplicate phase names.

Unchanged harness .runtime/history-correlation-repairs-v2-2026-10-23/measure.py SHA256 05a586a092289fe65a10462bba61e79f988bc8588d121bad727df1eed752a92a. Cursor harness profile_cursor_components.py in that directory SHA256 4e6a056596fca77c8a63bed1438cafe8d290bedd0cdc44dc5349f1c099a32d39. Reuse these directly with explicit fixture/output. No need to copy or fork their implementation.

## Existing root costs and minimal opportunities

V4 samples corroborate expensive historical queries but contain no request profiles or matched regression baseline. Preserve that distinction. Prior controlled v2 direct-service results: fresh searched resource median 1.5241 s, identical repeat 0.00283 s; empty search 0.08448 s; two live dashboards 1.10394 s fresh/1.12626 s repeated; focused graph 0.02565 s with high fanout 244-274 ms. First lazy search took 6.888 s and +600.70 MiB RSS. Those used the history-clock fixture, whose identity differs, so do not compare full digests as if unchanged.

Current source still matches that diagnosis. normalized_data.py:3923 builds complete search documents for all resources at each fresh timestamp; final kind filtering follows search to retain cross-kind counts. _resource_state_view:3247 loads lazy lifecycle/state sequences and performs active interval selection. Dashboard loop at 4120 calls resource_state_at for every relevant resource, repeating load_dataset/history_runtime/_descriptors plus projection; the controlled profile reconstructed 7125 resources and checked 1250200 intervals. The 500-row resource bound does not bound search population, and the graph cap does not bound relationship history traversal.

Smallest existing-logic candidate: in dashboard_query, prepare resource descriptors once beside existing dataset/runtime, call _resource_state_view with those same values, then retain identical redact_resource_view publication. This removes thousands of repeated lookups and introduces no cache. Cancellation, fallback/no-index behavior, selected dashboard semantics, row ordering, exact outputs and disclosure need focused equivalence tests. It is likely modest: active interval traversal and projection remain. Apply the same request-local reuse to bounded resource page publication only if measured useful. Do not move kind filtering ahead of search or expand timestamp caches. Projection path preparation and interval indexing require separate ownership, dotted-key, perspective and overlap validation.

## Execution

run-cursor.ps1 launches established direct service measurement (8 exact offsets, two reversed search-order rounds, 128 timed requests plus separate profiles). It records first lazy materialization separately, empty/active search and same-time hits; clears only existing search documents between cases, keeps 2-timestamp capacity. Outputs complete compressed JSON and digests. It excludes HTTP scheduling/serialization/browser latency. This is an old controlled workload on the current fixture, not an exact replay of v4 ES/VIF selections; any claim about v4 requires separate request spans or exact v4 cases.

run-1m.ps1 launches unchanged 52-phase harness and comparator against v3. Fresh output directory required. Run after all generation/tests/browser work are idle, sequentially, with workspace temporary paths. Harness samples child at 100ms, includes lifetime counters and memory/time guards, excludes browser/idle demo, does not flush OS caches. Cursor snapshots are not lifetime peaks. Compare full results and invariant groups, investigate every changed digest. Both launchers intentionally are prepared only; neither was executed.

Documentation drift check complete: task-local evidence/launchers only; no public plug-in behavior, commands, or maintained authoring documents changed.
