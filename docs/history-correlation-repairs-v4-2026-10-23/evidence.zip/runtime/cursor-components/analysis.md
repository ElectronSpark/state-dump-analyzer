# Controlled cursor investigation after v4 repair

The unchanged production cursor paths still spend most warm fresh-timestamp CPU rebuilding population-wide safe search text and dashboard states. This task diagnoses that work; it changes no product code and implements no speculative optimization.

Executed once after parent reported heavy tests stopped and product code frozen. No browser/server requests were issued. Command: `& .runtime/history-correlation-repairs-v4-2026-10-23/run-cursor.ps1`, with stdout/stderr retained in `cursor-run.log`. Process returned0. Verified Python3.12.13, PYTHONHASHSEED0, workspace TEMP/TMP and fresh search cache. Actual fixture SHA256 was rehashed by harness and matches `5f204e5836be8966f148ae14671f9488007970619cff094cc9bda60c71892105`; PE-A1250005 events/7510 resources. Source hashes, exact timestamps, limits and default dashboard IDs are retained in all-results.json metadata.

| Direct service component | Fresh median elapsed | Identical repeat median | Fresh median CPU |
| --- | ---: | ---: | ---: |
| Searched DTE resource page |1.62204s|0.003059s|1.58594s|
| Empty-search 500-row DTE page |0.09727s|0.09350s|0.09375s|
| Focused graph |0.02744s|0.03115s|0.03125s|
| Two default live dashboards |1.21461s|1.22728s|1.15625s|

Eight native offsets, two rounds reversing empty/active search order,128 timed component occurrences. Fresh cases clear only the existing timestamp search-document cache; expanded histories stay warm. The first all-resource searched cursor is measured separately:7.09636s elapsed/6.828125s CPU, RSS2.17490→2.76057GiB (+599.73MiB). Loaded RSS2.174896GiB; largest query-boundary snapshot2.779202GiB/private2.775227GiB. These are snapshots, not sampled/lifetime peaks. No allocation profile apportions the600MiB among histories, documents and allocator retention. The52-phase1M navigation benchmark exercises a different workload and must retain separate metrics.

Four cProfile occurrences were recorded separately from timing:

- Searched resource projection:5.286 instrumented seconds;7510 resource_search_text calls3.617s,7511 _resource_state_view calls1.620s,1252040 contains_time calls. Declared field traversal, disclosure projection and full interval selection dominate. Nested cumulative times overlap. Kind filtering cannot precede search because cross-kind counts are part of output.
- Dashboards:3.485 instrumented seconds,7125 resource_state_at calls3.379s; reconstruction1.581s and redaction1.518s,1250200 contains_time calls. Dataset lookup accounts for0.160s. The existing request-local reuse opportunity is real but removes only a modest portion; it does not eliminate state scanning or safe projection.
- High-fanout graph:1.091 instrumented seconds,504120 relationship_presence and527072 contains_time calls for500 nodes/499 edges. Ordinary cases are3–35ms; cap cases267–328ms fresh, up to348ms repeat. Bounded output does not bound traversal.

One exact-repeat dashboard outlier is retained: ordinal90, round1, old audit move59,3.93646s elapsed/3.59375s CPU, unchanged RSS/private and exact matching output. The prior controlled v2 run had its outlier at the same ordinal/case. This recurrence warrants future allocation/GC attribution, but no GC instrumentation was collected here and no causal claim is established.

Verification:64/64 identical-repeat pairs,64/64 cross-round pairs and4/4 profile outputs agree by complete canonical JSON digest. All33 unique compressed response archives were independently decompressed, rehashed and parsed by copied unchanged summarize_cursor_components.py; summary.json and response-verification.json retain details. Observed at most1 snapshot/7510 documents with unchanged2-timestamp capacity; clearing between cases is not an eviction test.

This directly reproduces the prior cost pattern on the current fixture. Small timing differences from the v2 controlled run do not establish regression or improvement: one run per state, changed fixture identity, no statistical controls. Direct service calls exclude HTTP scheduling/serialization, frontend rendering and automation. This established DTE workload is not an exact replay of v4 ES/VIF actions; topology is not separately timed. Component medians must not be summed into claimed browser refresh latency. The actual dominant measured work is fresh safe search projection plus repeated live dashboard reconstruction, with secondary graph fanout.

Documentation drift check completed: runtime evidence only; no public plug-in behavior or maintained authoring changes.
