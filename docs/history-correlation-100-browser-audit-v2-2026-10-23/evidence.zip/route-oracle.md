# Historical route oracle for the second 100-move browser audit

Read-only source review at commit `141836e`; no server, benchmark, generated fixture, or browser operations performed. All times below are UTC offsets from `1759680000000000000` ns unless marked native. Browser outcomes must be confirmed by the parent before reporting defects.

## Highest-value new boundary: inventory continuation clocks

The inventory generator authors route observations at UTC +601 s, shifted into the source node's native clock (`demo/rsl_demo_generator/assembly.py`, `_inventory_projection_rows`). The repaired core validates both a hop's forwarding decision in that hop's native clock and its referenced route row in the route owner's native clock (`multi_node_route.py`, `_route_evidence_valid_at` and `_reconcile_generated_route_evidence`). Entire uncertainty intervals must be inside half-open validity.

| Owner | Native offset | Uncertainty | Earliest valid UTC inventory row |
| --- | ---: | ---: | ---: |
| PE-A / node-a | -4 ms | 5 ms | +601.005 s |
| PE-B / node-b | +6 ms | 9 ms | +601.009 s |
| PE-C / node-c | +11 ms | 7 ms | +601.007 s |
| PE-D / node-d | -8 ms | 6 ms | +601.006 s |
| PE-E / node-e | +14 ms | 8 ms | +601.008 s |
| P1 / transit-p-1 | +1 ms | 3 ms | +601.003 s |
| P2 / transit-p-2 | -2 ms | 4 ms | +601.004 s |
| CE-West | +19 ms | 12 ms | +601.012 s |
| CE-East | -17 ms | 15 ms | +601.015 s |
| Edge-C | +31 ms | 25 ms | +601.025 s |

**Source lead:** `_inventory_continuation_rows` copies `route["observed_at_ns"]` unchanged into each executing node's forwarding row. Lightweight invocation of these existing generator functions confirms all three A/P1/B continuations for A→B have `1759680600996000000`; all three for B→A have `1759680601006000000`. Those values are source-clock timestamps, yet the repaired core interprets each as an executing-node timestamp. There is no adjustment when constructing normalized inventory decisions.

Discriminating sequence: generic Router-to-router, blue / VPNv4 unicast / MPLS L3VPN, A⇄B, absolute +601.006 → +601.010 → +601.016 → +601.010 → +601.006. At .010 all A/P1/B native observation windows should be available. Current source implies A→B can resolve already at .005, but B→A is blocked until .015 by its terminal A continuation. Check the exact unresolved node and reason. Do not conflate a missing reverse source row before .009 with this suspected continuation-clock bug. Repeat direct and table-seeded paths and direction-only versus bidirectional checks. Epoch +601.010 is `1759680601010000000` ns.

Strict versus best-effort is a retention control here: all fixture nodes have clock mappings. Strict policy does not erase uncertainty or legitimately admit future evidence. Rows must remain absent when the uncertainty window begins before their observation. This code's strict policy rejects unavailable mappings; it is not an exact-clock mode.

## Scenario evidence is later than generic inventory

Coverage scenario rows are observed at +610 s plus case index ×1 ms and each owner's native offset. Unlike inventory continuation generation, ordinary scenario forwarding rows copy their own node's route timestamp.

| Scenario | UTC observation epoch |
| --- | ---: |
| single-active-primary | +610.000 s |
| all-active-ecmp | +610.001 s |
| cross-node-mpls-label-mismatch | +610.002 s |
| cross-node-vxlan-vni-mismatch | +610.003 s |
| cross-layer-inconsistent | +610.004 s |
| incomplete-node-resolution | +610.005 s |
| router-to-router coverage row | +610.006 s |
| transit-start-endpoint-reachability | +610.007 s |
| site-a-site-c-asymmetric | +610.008 s |
| site-b-site-c-one-way | +610.009 s |
| evpn-mh-all-active | +610.010 s |
| evpn-es-withdraw-failover | +610.011 s |

A generic inventory route can therefore resolve at +605 while a seeded single-active-primary scenario remains incomplete; this difference is expected evidence validity, not a defect. Check single-active-primary at +610.004, +610.006, +610.010, then reverse. A/P1/B path has all node evidence available at +610.009. A table row from A may be visible earlier at .005 without proving that the whole path is resolved. The final status and per-hop explanations should remain internally consistent. Compare Trace from a table row with the direct scenario selection, preserving the row's actual scenario/direction rather than silently treating every row as generic inventory.

## Topology uncertainty and state lifecycle controls

Typed P1 Ethernet3/1 ↔ P2 Ethernet4/1 circuit `10.64.255.0/31`, claim `p1-p2-sr`:

- Carrier loss is authored at +90.050 s on P1. With ±3 ms, +90.046999999 must be stably up; +90.047 through +90.052999999 straddles up/down and must be ambiguous/unknown; +90.053 must be stably down. The exact center alone does not establish state.
- Restoration is +240.100 s on P1: +240.096999999 down; +240.097 through +240.102999999 ambiguous; +240.103 up. Repeat boundary sequence backward. P2 stale carrier-down at +96 has `update_snapshot=false`, so must not apply down; its +242.5 up observation should not retroactively change earlier state.
- P1 adjacency is deleted at +91 and recreated +247, independently of interface carrier. The carrier can be up at +241 while the adjacency is still absent. Do not infer adjacency reachability merely from a usable physical circuit.
- Generic and scenario routes are not valid this early in this fixture; an incomplete +100 or +241 route is expected even when a circuit is usable. Inspect actual circuit status and local corresponding interface separately.

PE-D `Ethernet1/1.310`, core-west multi-access `10.64.0.0/24`:

- Delete +180, restore +300; ±6 ms. At +179.990 attached, +180.000 ambiguous, +180.010 absent; at +299.990 absent, +300.000 ambiguous, +300.010 attached.
- Related adjacency delete +181, restore +304. At +301 interface exists but adjacency still absent. Select interface vs adjacency explicitly in local view, then return to Fabric and reapply the same historical instant.

Ottawa PE-C / P2 carrier controls offer a different link:

- PE-C Ethernet1/1.320 down +420.2, P2 Ethernet2/1.320 down +435. Restoration P2 +521, PE-C +528. Stable +430 is asymmetric, +440 both down, +525 asymmetric, +529 both up.
- PE-C route `route:blue:10.255.0.1/32` deleted +439, restored +535: interface restored does not imply route restored at +529.

## Cross-component checks and interpretation

1. Save a valid inventory table seed at +700, change the applied basis to +601.004 or +100, then trace again. The old seed must not lend old validity or old table context to the new instant. Repeat fresh direct form selection after clearing seed.
2. Change only focus direction, All/Focused path mode, or topology layer visibility after a historical trace. These presentation choices must not alter applied time, row validity, membership, or reachability.
3. Drill from a forward or reverse hop into Single node and return to Fabric. Verify native cursor (`UTC + node offset`) and member identity, not just the displayed offset. In relative-to-watermark mode each node has its own vector instant; simultaneous UTC is not implied.
4. Apply a new absolute time while route execution is pending; after settle compare applied basis, route table context, graph, header direction and per-hop evidence. Old results can remain labelled pending but must not become the settled new result.
5. At an uncertainty boundary, compare topology card and local exact native moment without requiring them to be equal: Fabric uncertainty can truthfully be ambiguous when a single exact cursor selects one side. Record bounds as well as centers.
6. Beyond the capture/watermark, open-ended route validity plus a coverage warning is already known behavior, not a newly established bug. Invalid time retaining a labelled last applied result is also expected.

The previous audit already established broad +100/+700 filtering, stable carrier down/restore, failed updates, structural deletion and the pinned-correlation-popup repair. This audit should prioritize nanosecond/millisecond uncertainty boundaries, clock-owner continuity, row seeding across those boundaries, and stale-result prevention.
