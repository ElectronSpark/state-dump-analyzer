# Resource finding source corroboration

2026-10-23. Supporting read-only review of parent browser evidence and current source. No product changes; this agent did not operate the browser.

## Confirmed P2: full graph presents an uncovered selected focus as zero relationships

Suggested title: **Selected-resource relationship index reports false absence when the broad graph omits that resource.**

The parent selected active DTE1874 at native +720 seconds, switched from focused to all correlations, then returned to focused repeatedly. The same selection and timestamp produce one outgoing relation in focused mode and zero in the broad view. The broad response simply does not cover the selected disconnected component.

### Evidence qualification

- `move-042.txt:2420–2466` and `move-045.txt:2420–2466` are settled focused controls. They show Selected moment +720.000 s, selected DTE1874 programmed, outgoing ETG1874 active, and Relationship index1.
- **`move-044.txt:2421–2613` is the settled defect evidence.** It shows Selected moment +720.000 s, Focus selected button, 31 canvas nodes of500 server nodes, 53 canvas edges of522 returned relationships, selected DTE1874, Relationship index0, and “No resources in this direction at the selected time.” for both directions.
- `full-graph-false-zero.png` corroborates the visible selected-focus index.
- Raw moves040/041/043 were captured while Updating to +720.000 s. They must not be cited as settled false-zero repetitions.040 contains a transient absence message before focus request completes;041/043 still retain the previous focused graph. Parent live observations may include later settlement, but the saved044 evidence is the sound reproduction anchor.

### Scope disclosure nuance

The UI **does disclose truncation** in044:

> Server result capped at500 resources; refine or focus to inspect omitted relationships.

It also says the index is pageable across the full response, not the entire dataset. Do not report “no truncation warning” or “all relationships disappeared from the backend.” The actionable contradiction is narrower: under a retained **Selected focus**, the index gives an unconditional temporal absence statement even though the selected resource is absent from this bounded response and the immediately adjacent focused controls prove its active relation. A general cap note does not make “No resources ... at the selected time” accurate.

This is **P2**: misleading resource-correlation interpretation in a normal scope toggle, with an available recovery through Focus selected. It is not evidence of data corruption or broken historical reconstruction. The bounded graph and lower CPU/memory usage are intentional and should remain bounded.

### Root cause and exact source locations

1. `frontend/assets/app.js:7117–7127`: requestGraph sends empty `resource_ids` when graphShowFull is true, and uses depth20/max_nodes500. It deliberately stops sending the selected focus to this request.
2. `src/router_dump_analyzer/revision_queries.py:722–725`: the scale graph path substitutes `runtime.initial_resource_ids[:4]` when no roots were requested. It traverses a representative connected neighborhood, which does not guarantee disconnected DTE1874 is covered even before considering the cap.
3. `revision_queries.py:868–879`: response already declares accepted/inactive/dropped roots and `defaulted_to_representative_roots`. No new public API is needed to recognize this scope.
4. `frontend/assets/app.js:7529–7535`: renderCorrelationList retains selectedResourceId and counts only response edges adjacent to it, without checking whether the selected node is in `graph.nodes` or whether response coverage supports a total.
5. **`app.js:7521–7523`** turns an empty array into the categorical “No resources in this direction at the selected time.” This conflates no returned relationships with known temporal absence.
6. `app.js:7928–7939` emits a general cap note, then invokes renderCorrelationList(scoped); the selected-focus count/absence wording does not receive a coverage distinction. The frontend does not currently consume `defaulted_to_representative_roots` for presentation.

### Minimal repair direction for a later authorized fix

Fix existing scope/count/empty-state logic instead of expanding graph queries or adding another index. The selected-resource index should recognize when its focus is outside the returned graph, explain that the current neighborhood does not include it, and use the existing Focus selected control. For bounded/representative results, counts and empty text should describe returned/visible relationships rather than assert global absence. Preserve the500-node server bound and existing canvas bound. A genuinely queried inactive root can still show lifecycle absence using the response's inactive-root metadata.

If the intended product behavior is that broad mode always retains the selected focus's neighborhood, explicitly seed that scope in existing request construction, but that is a broader semantics decision. Merely inserting a selected node into the canvas without its actual current relationships would still report a false zero.

Regression cases should cover selected disconnected active node, selected root missing because of cap, truly inactive selected root, no selection, and focused→broad→focused at fixed time. Existing strict returned-count assertions need to remain distinguished from full-capture totals.

## Route view moves031/032: retained observation, not confirmed root cause

Both saved snapshots are byte-identical (SHA-256 `4217bc1e13b4dd9d06bfa7400195c2f500e13a585000a2fa8955e638aa169f4f`). In both:

- All paths is pressed; Focused path is not.
- Graph accessible name remains “All candidate route paths. Choose a path from an edge or node.”
- The blue VPN service context is a **tooltip**, without a pinned dialog's Close service context button.

The move032 ledger records a focused-path action with no tool exception, so the intended mode transition is not reflected in saved evidence. This alone does not establish whether a card intercepted the click, the target moved during the action, or another UI mechanism prevented activation.

Source: `topology.js:10170–10171` binds graph mode buttons directly to setRouteGraphMode. `topology.js:5450–5473` sets mode, clears previews, rerenders, and synchronizes the URL synchronously. There is no asynchronous request inside this mode change. This makes a controlled hit-test or keyboard activation repeat valuable: record button/card geometry, activate Focused path with popup open, inspect aria-pressed and route_view, then repeat after Escape. If keyboard succeeds while pointer lands on the popup, that establishes the interaction cause. No additional popup bug is asserted by this review.
