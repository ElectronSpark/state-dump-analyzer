# Inventory continuation timestamps use the wrong native clock

## Conclusion

This is a generator timestamp-domain defect, surfaced by the recent historical-validity repair. It is not a legitimate asymmetry or an intentionally attributed source-clock observation. A continuation is explicitly emitted as a forwarding declaration belonging to its executing node and revision, with no alternate timestamp-domain field. The source route's independent validity is already carried and checked separately in the source owner's clock. Copying the source row's numeric timestamp into the executing row makes the two clock domains disagree.

The observed browser result in `move-004.txt` at `1759680601010000000` ns (UTC +601.010 s) matches the predicted defect: Forward has one resolved path, Return is unresolved, and Return step 5 at PE-A says **Route or forwarding evidence is unavailable at the selected time**. Both preceding P1 links are usable. PE-A and PE-B each have 85 visible route rows under the applied time. There is no pending-result explanation in that selected route snapshot. Parent should preserve the +601.016 passing control and backward repeat to close the browser reproduction.

Suggested severity: P2. It creates false historical reachability and false incompleteness near observation boundaries. The copied-clock error is as large as the difference between source and executing clock offsets (up to 48 ms across this fixture's nodes), though not every such pair is a reachable path. The current A/B reproduction delays the return path by 6 ms relative to the latest correctly mapped owner uncertainty threshold.

## Why source-evidence attribution does not justify the copy

- `docs/api-contract.md:3944–3952` defines generated route validity in each member's **resolved native-time interval**, including uncertainty, and applies that gate to direct decisions and correlations.
- `docs/plugin-contract.md:2755–2773` requires frozen-member validity and says node plug-ins contribute node-local forwarding semantics. Evidence references and local semantic ownership are separate.
- `demo/rsl_demo_generator/assembly.py:3609–3615` deliberately creates inventory route observations as UTC +601 s **plus the route owner's clock offset**. This is not a UTC timestamp convention.
- At `assembly.py:4041–4050`, each continuation has the executing `node.node_id` and `node.revision_id`, but `observed_at_ns` is copied verbatim from the source route. The row has no `clock_domain`, `timestamp_owner_node_id`, or equivalent override. Its `route_id` and evidence resource references intentionally point back to the source row; those do not relabel the continuation's own clock.
- `src/router_dump_analyzer/multi_node_route.py:3598–3606` validates that continuation node, revision, and path occurrence match the executing node.
- `multi_node_route.py:3632–3641` keeps source `route_validity` (including source `node_id`) separately from the continuation's `observed_at_ns` / `valid_from_ns`.
- `multi_node_route.py:1645–1653` validates local decision evidence using the executing node's resolved time and referenced route evidence using the source row owner's resolved time. This distinction is correct and necessary.
- `multi_node_route.py:3983–4016` performs native-clock half-open checks over the entire uncertainty interval. There is no alternate domain interpretation.
- Existing ownership comments at `multi_node_route.py:228–242` intentionally allow remote resource references. They address identity ownership of references, not the continuation row's timestamp semantics. Normal scenario forwarding at `assembly.py:4374–4377` / `4494` copies a timestamp from the **same local node's** route, so that use is consistent; the cross-node inventory loop is the exceptional faulty copy.

## Exact arithmetic

Base UTC is `1759680000000000000`. Relevant clock offsets / uncertainties:

| Node | Local minus UTC | Uncertainty |
| --- | ---: | ---: |
| PE-A | -4 ms | ±5 ms |
| P1 | +1 ms | ±3 ms |
| PE-B | +6 ms | ±9 ms |

Every inventory row's authored absolute observation epoch is UTC +601 s. Correctly represented local observations are A = +600.996, P1 = +601.001, B = +601.006. They become valid for their complete mapped windows at UTC +601.005, +601.003, and +601.009, respectively. Thus both A→P1→B and B→P1→A have all necessary native observations by UTC +601.009.

Current A→B continuations all store A's +600.996 timestamp. At B, that number incorrectly means UTC +600.990; the B continuation is therefore admitted before its genuine UTC +601 observation window. The source A gate is the final blocker, so the entire forward direction becomes eligible at +601.005 instead of +601.009.

Current B→A continuations all store B's +601.006 timestamp. At A, that number incorrectly means UTC +601.010. Covering A's ±5 ms window then requires UTC +601.015. At the browser's +601.010, A's local minimum is +601.001, so the incorrect +601.006 start is rejected; the correct local +600.996 start would be valid. B's route and P1 continuation are already available.

An isolated read-only call to the existing `_route_evidence_valid_at` with actual generator rows reproduced the following. “Converted” changes only the value in a temporary Python dictionary using `observed - source.offset + executing.offset`; it did not modify files or fixtures.

| UTC | Current A→B local gates | Converted A→B | Current B→A local gates | Converted B→A |
| --- | --- | --- | --- | --- |
| +601.005 | all pass | B fails | A/B/P1 fail | B fails |
| +601.006 | all pass | B fails | A/B/P1 fail | B fails |
| +601.009 | all pass | all pass | A fails | all pass |
| +601.010 | all pass | all pass | A fails | all pass |
| +601.014 | all pass | all pass | A fails | all pass |
| +601.015 | all pass | all pass | all pass | all pass |

This helper check is supporting attribution, not a replacement for the parent's browser tests or a full end-to-end repaired implementation test.

## Smallest repair direction for a later implementation task

Fix the existing generator assignment in `_inventory_continuation_rows`, converting the source row's native observation into the executing node's native clock:

`int(route["observed_at_ns"]) - source_node.clock_offset_ns + node.clock_offset_ns`

Keep the source `route_id`, source evidence references, and the core's two owner-specific gates unchanged. Do not relax the uncertainty check or teach core to guess a source clock from a reference. A new timestamp-owner field is unnecessary for the existing node-local format. If arbitrary future forwarding declarations need a separately attributed observation domain, that would be a distinct explicit format change, not a reason to infer it now.

The generated archive already contains these projection rows, so a generator-only source patch will not repair the currently served existing archive. Regenerate the affected sample dump(s) and restart the demo only during an authorized repair task. Do not silently transform old archives on load without a versioned contract decision.

Useful regression coverage: compare each emitted continuation's UTC-normalized observation against its source row; assert both directions at +601.008999999 and +601.009; verify direct and table-seeded traces, strict and best-effort missing-hop policy, and valid→invalid→valid repeats. Include nonzero, unequal source/executing offsets so an all-zero-clock fixture cannot conceal the bug. Distinguish the topology clock policy from route missing-hop policy.

## Scope and stewardship

Only this runtime analysis document was written. Product, skill, fixtures, and maintained author documents remain unchanged. This read-only audit establishes an inconsistency with the existing documented contract; there is no new author-visible behavior to document in this task.
