# VPN service-preview pointer obstruction

2026-10-23. Read-only source and prior-audit review supporting the parent's browser reproduction. No product changes; this agent did not operate the browser.

## Confirmed P2: service tooltip covers route-mode controls in a narrow viewport

The service preview remains over the Focused path button and intercepts its pointer click. The button works through keyboard activation and pointer activation without the tooltip. This is an actionable layout/input defect, not a slow route query.

### Evidence

- `move-031.txt`/`move-032.txt`: early attempt after historical route operations, both byte-identical with All paths pressed and a blue VPN service tooltip open. This initially justified further investigation only.
- `move-095.txt`/`move-096.txt`: reproduced after a single-node round trip and route rerun. Service tooltip remains open; the pointer action leaves All paths pressed and Focused path unpressed. The overlay is a **tooltip**, not a pinned dialog; no Close service context button appears.
- Parent read-only hit test at the Focused path button center `(321.7, 273.225)` returns `ASIDE#mn-route-hover-card`, not the button. The button's top-left was `(229.6, 260.475)` and dimensions were184.2×25.5 CSS pixels; card rectangle was `(12, 206, 430, 329.3)`. `mode-hit-test.json` preserves the rectangle and computed-center hit.
- `route-mode-pointer-after-popup.png` visibly shows the card spanning nearly the full459-pixel-wide viewport over the route controls.
- `move-097.txt:453–454`: Enter on Focused path activates it; All paths is unpressed, Focused path pressed. The preview disappears through the normal mode renderer.
- `move-098.txt` and `move-099.txt`: pointer All paths→Focused path succeeds with no service tooltip. These are the control proving mode handler availability.

Severity is P2: a normal preview blocks navigation in an available narrow app pane. Keyboard/Escape recovery exists; there is no evidence of lost route data or reconstruction errors from this interaction.

## Root cause

The positioner ensures the popup stays inside the viewport but does not ensure the popup stays out of the nearby route-mode control area when there is no horizontal room beside its anchor.

- `frontend/assets/topology.js:8534–8559`, `positionRoutePathPreview`: width is `min(430, viewportWidth-24)`; height can remain330. It tries right of the anchor, then left, then clamps horizontal position to the viewport. At459 pixels wide there is insufficient side space for the430-pixel popup, so clamping overlays the content area.
- `topology.js:8550–8556`: pointer/anchor top is used with an18-pixel upward offset, then vertically clamped by the full card height. There is no below-anchor fallback or narrower available-height constraint to preserve access to the controls above the service strip. The observed card top206 covers the mode-button center at y273.225.
- `frontend/assets/topology.css:1427–1441`: the card is fixed, z-index1000, and remains pointer-hit-testable. This is intentional for reading/scrolling, but exposes the placement error as blocked input.
- `topology.js:8428–8446`: the card is body-mounted; pointer entry into the card clears its hide timer. Moving from the service trigger toward the covered button enters the card, so the preview can remain in the way rather than expire after leaving the trigger.
- `topology.js:5450–5473` and `:10170–10171`: the existing mode action synchronously sets the mode, clears previews, rerenders, and updates the URL. Adding another close to this handler would not fix pointer interception because the button never receives that click. The keyboard/no-tooltip controls confirm this distinction.

## Relationship to earlier findings

This shares the popup implementation and broad interaction family with earlier issues, but is **not a reproduction of any of the three repaired LV findings**:

- LV01 was a pinned popup surviving after its anchor scrolled off-screen. The repair added anchor validity and scroll repositioning. Here an in-view service preview obstructs nearby controls; no off-screen anchor is needed.
- LV02 was passive re-entry rebuilding DOM/resetting scroll and stealing focus. Here the mode button is physically covered; focus/scroll retention is not the trigger.
- LV03 was a delayed resize rerender destroying an already activated service dialog/trigger. Here All→Focused activation never reaches its handler. Keyboard activation works and retains the expected route mode.

`docs/vpn-popup-repairs-2026-10-23/README.md` records validation at1905×933, with short viewport height covered by tests. Its shared positioner tests cover fit inside viewport/header bounds but do not establish nonoverlap of route controls in a narrow pane. The current459-pixel width is a newly exercised layout condition.

Other historical popup issues (HC03's single-node correlation card covering Timeline Actions, FP01's pinned timeline card intercepting the lane picker) are separate popup implementations and anchor/surface lifecycle causes. This should be tracked as one new route service-placement defect, not duplicate entries for031/032 and095/096 or for every covered control.

## Minimal repair direction for a later authorized fix

Repair the existing shared position calculation: when neither horizontal side fits, use a deliberate vertical placement relative to the service trigger and constrain actual card height to available space so the trigger and adjacent route-mode controls stay usable. Preserve the current header boundary, off-screen-anchor dismissal, internal scrolling, and explicit pin/focus behavior. A narrow layout may need a shorter scrollable card rather than the current full-height card clamped upward over the toolbar.

Do not change the graph-mode handler, raise each covered control's z-index, or globally disable card pointer events as a substitute for placement. Global pointer-events:none would break intentional popup scrolling and pinned controls. Any transient-preview pointer policy change should be deliberate and separately preserve the pinned reader interaction.

Regression: visible service trigger at459-pixel viewport width, actual card height near330, route-mode button above strip; verify its pointer hit target is still the button. Exercise pointer and Enter for the service trigger and mode switch, repeat after cross-component return, and retain the earlier partially clipped anchor, internal scrolling, passive re-entry, and delayed resize controls.
