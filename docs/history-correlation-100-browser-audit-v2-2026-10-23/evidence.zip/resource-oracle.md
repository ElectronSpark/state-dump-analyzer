# Single-node correlation audit oracle, second 100-move pass

Read-only source/generator review for the parent browser audit, 2026-10-23. These are expected results and candidate checks, not independently executed browser moves. No product edits or heavy workloads were run.

## Evidence and time convention

Read the validation skill, the previous `docs/history-correlation-100-browser-audit-2026-10-23/README.md`, its saved `.runtime/.../resource-oracle.md`, current `frontend/assets/app.js`, `normalized_data.py`, `revision_queries.py`, and `demo/rsl_demo_generator/_scale.py`.

PE-A native origin is **1759679999996000000 ns**. The assembly shifts generated records by -4 ms from UTC base 1759680000000000000. All offsets below are native offsets from that origin, not wall-clock timestamps. To select exact T through the UI, apply range [T, T + 1 ns], then Actions → Select this moment. Merely applying a range does not move the cursor. Wait for both resource table and graph to finish updating before comparing them.

Generator oracle was evaluated with the configured Python executable, `_layout(7500)`, `_phase_event_counts(1250000)`, and selected `_event_for_phase` calls only. No fixture regeneration or million-event parsing was needed.

## New discriminating identities and boundaries

All resource IDs below are prefixed `node-a/`. DTE IDs are `data-bridge-layer/DTE/blue/dte-NNNNNN`; ETG IDs are `data-bridge-layer/ETG/blue/etg-NNNNNN`; ETE IDs are `data-bridge-layer/ETE/etg-NNNNNN/primary` or `/backup`; fallback is `control-plane/IP_ROUTING/blue`.

| Offset seconds | Resource/result | Exact event UID (prefix `node-a/`) |
|---:|---|---|
| 120.000000000 | DTE0, ETG0, primary0 created; DTE0 → ETG0 | scale-event-00000000 |
| 120.000100000 | DTE1, ETG1, primary1 created; DTE1 → ETG1 | scale-event-00000001 |
| 120.187400000 | DTE1874, ETG1874, primary1874 created; DTE1874 → ETG1874 | scale-event-00001874 |
| 240.000100000 | Backup1/ES1 created; ETG1 owns backup, ES1 active_path → primary1 | scale-event-00312501 |
| 360.000000000 | ES0 withdrawn; DTE0 still → ETG0 until service failover | scale-event-00500000 |
| 360.037500000 | DTE0 → IP_ROUTING; primary0 down; backup0 active | scale-event-00500375 |
| 360.037600000 | DTE1 → **ETG2**, primary1 down; backup1 active | scale-event-00500376 |
| 480.000000000 | ES0 up; DTE0 still → IP_ROUTING until service restore | scale-event-00750000 |
| 480.037500000 | DTE0 → ETG0; primary0 active; backup0 standby | scale-event-00750375 |
| 480.037600000 | DTE1 → ETG1, from prior ETG2 | scale-event-00750376 |
| 600.675100000 | DTE1 failed attempt to ETG2; actual next_hop remains IP_ROUTING | scale-event-01006751 |
| 600.750000000 | DTE0 failed attempt to ETG17; actual next_hop remains IP_ROUTING | scale-event-01007500 |
| 600.825000000 | DTE0 successful retry → ETG17 | scale-event-01008250 |
| 600.825100000 | DTE1 changes ETG2 → IP_ROUTING | scale-event-01008251 |

DTE1874 is single-home and is not part of the first750 multihome services, making it a useful disconnected/full-scope control. Do not expect DTE1 failover to IP_ROUTING: odd service1 explicitly uses ETG2, unlike even DTE0. Relationships are half-open [start,end), with both endpoints required to exist. Ownership and selected_egress are distinct: primary ownership remains while primary is down.

## Suggested additional moves

These 40 proposed moves are a menu for the parent's 100-move plan, not an execution claim.

1. Select DTE1 at capture, then set +120.000099999: absent graph/table.
2. Set +120.000100000: DTE1 → ETG1 appears exactly.
3. Return 1 ns earlier: absence must return without a stale ETG1 edge.
4. At +120.000000000 select DTE0: it exists while DTE1 does not.
5. Return to DTE1 at unchanged cursor: no graph/time contamination from DTE0.
6. Set +360.037500000 and select DTE1: still ETG1.
7. Set +360.037600000: DTE1 → ETG2; inspect both table and edge card.
8. Return +360.037500000: DTE1 → ETG1.
9. Select DTE0 without changing time: DTE0 → IP_ROUTING.
10. Select primary0 via relation/lane and confirm down while ETG0 still owns it.
11. Select backup0 and confirm active; primary ownership must not be mistaken for selected egress.
12. Set +480.000000000 on DTE0: ES restored but DTE still IP_ROUTING.
13. Set +480.037500000: DTE0 returns ETG0.
14. Set +480.037599999 on DTE1: still ETG2.
15. Set +480.037600000: DTE1 returns ETG1.
16. Select failed DTE1 event01006751 through normalized-log search.
17. Reveal it in timeline; compare actual graph IP_ROUTING with attempted ETG2 in inspector.
18. Reopen relationship popup after clearing log search; retained applied target must stay IP_ROUTING.
19. Select failed DTE0 event01007500; graph IP_ROUTING, attempted ETG17.
20. Select successful retry01008250: graph ETG17 and generation11.
21. Jump back to failed event: graph must return IP_ROUTING.
22. Revisit success via timeline/log cross-navigation; selected event and cursor remain exact after virtualization settles.
23. At capture select DTE1874, inspect its ETG1874 relation.
24. Show all correlations; record selected focus, graph presence, and truthful coverage note.
25. Focus selected again; DTE1874 relation must recover without selecting another resource.
26. Repeat full/focus after setting +120.187399999 then exact creation.
27. While DTE0 is selected, resource-search a disjoint DTE1874 term; search should filter the table, not silently replace graph focus/time.
28. Clear search and switch DTE/ETG tabs; separate table-kind choice from selected correlation focus.
29. At IP_ROUTING high-fanout cursor expand incoming relationship group and Show more.
30. Collapse/reopen group; rendered list paging and disclosure state should remain deliberate.
31. Open an edge popup from expanded list and scroll nested relationship list until anchor clips; card closes.
32. Pin an edge popup, switch full/focus; disconnected anchor must not survive render.
33. Pin node, scroll partly behind sticky header; retained partial anchor should reposition, fully clipped should dismiss.
34. Keyboard-focus a graph/list endpoint that scrolls into view; card geometry follows actual post-focus position.
35. Ctrl-click a relationship endpoint into timeline; exact endpoint lane, cursor and active layer visible.
36. Hide target layer, repeat Ctrl-click; reveal restores target layer without stale selected focus.
37. Switch separate/combined correlation lanes; interval ribbons reflect visible window, graph selected instant.
38. Narrow selected range across failover without selecting midpoint; graph must retain prior cursor.
39. Rapidly request precreation → failover → restore, then wait; final graph/table must match restore, prior completions must not overwrite it.
40. Repeat same searched/empty-searched cursor on already loaded node with exact matched sequence; record elapsed UI settlement separately from request/CPU claims.

## Source leads to discriminate, not confirmed defects

**Representative full graph can omit selected focus.** `requestGraph` (`app.js:7117`) sends no selected IDs for full scope, depth20/max500. The scale path in `revision_queries.py:722–725` substitutes `initial_resource_ids[:4]` and walks only that neighborhood; response sets `defaulted_to_representative_roots`. Frontend `renderGraph`/`renderCorrelationList` keeps `state.selectedResourceId` and shows relationship counts relative to it, but never describes representative-root defaulting. With selected DTE1874 outside that neighborhood, an index of0 can imply no correlations despite its focused graph having DTE1874→ETG1874. Distinguish clearly advertised server truncation from unadvertised disconnected representative sampling. This requires actual browser confirmation.

**False lifecycle wording on empty scope.** `renderGraph` at app.js:7793–7808 labels any empty focused graph as selected resource outside lifecycle, even if it is empty because of scope/default roots or a graph read failure. `requestGraph` catches errors into localGraphAt, which lacks full scale data. Do not call this a new bug without observing an actual failing/non-lifecycle path; no deliberate server fault is part of this read-only support.

**Resource search input does not invalidate in-flight result until debounce starts next request.** Input handler app.js:12477 resets offset and schedules requestResources180ms later. requestResources owns the abort/latest generation. An earlier response could briefly populate results under a newly typed term inside that180ms. A short transient is not automatically a defect; check whether final results settle incorrectly or action selects the wrong row under a changed query.

**Unknown existence hover precedent.** graphNodeHoverHtml uses `node.exists ?? true`, so explicitly unknown null existence is rendered true. Existing fixture may not generate an ambiguous node; prior audit already listed this source-only lead. Do not report as newly discovered/confirmed without suitable browser evidence.

## Intended distinctions / performance limits

- Active graph/index reflects selected instant; historical timeline tree spans visible window. Their memberships need not be identical.
- Generic resource tab, bundled view, graph selected focus and timeline layer controls are distinct states. A table query can intentionally hide selected focus.
- Scale full graph caps500; canvas separately caps a smaller number. Index is pageable across full server response, not necessarily entire capture.
- Correlation list endpoint buttons deliberately require Ctrl/Meta-click to jump; ordinary click only inspects. Graph card Escape/empty canvas clears pin; scrolling off-screen dismisses card without necessarily clearing semantic pin.
- Recent cursor optimization removed duplicated projection but still reconstructs/search-projects7510resources at an uncached timestamp for cross-kind counts. The cache holds two timestamp search snapshots. A3+timestamp sequence exercises eviction; a two-time repeat may hit cache. UI timing includes tool/scroll/observation latency and cannot establish isolated CPU regression.
- This support changes only an ignored runtime evidence document; no plug-in API/authoring behavior drift.
