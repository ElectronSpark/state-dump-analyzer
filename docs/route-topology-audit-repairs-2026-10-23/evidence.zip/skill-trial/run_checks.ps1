param(
    [ValidateSet('environment', 'inventory', 'identity', 'composed')]
    [string]$Check = 'identity'
)

$ErrorActionPreference = 'Stop'
$TrialRoot = $PSScriptRoot
$TrialPython = 'C:\Users\82046\anaconda3\envs\router-dump-analyzer-demo\python.exe'
$TrialTemp = Join-Path $TrialRoot 'temp'
$TrialCache = Join-Path $TrialRoot 'pycache'
New-Item -ItemType Directory -Force -Path $TrialTemp, $TrialCache | Out-Null
$env:TEMP = $TrialTemp
$env:TMP = $TrialTemp
$env:PYTHONPYCACHEPREFIX = $TrialCache
$env:PYTHONUTF8 = '1'
$env:PYTHONIOENCODING = 'utf-8'
$OutputEncoding = [System.Text.UTF8Encoding]::new($false)
$TrialPrefix = 'tests.test_plugin_identity_runtime_imports.PluginIdentityRuntimeImportTests.'
$TrialArguments = switch ($Check) {
    'environment' {
        @('-c', 'import sys, router_dump_analyzer, rsl_demo_plugin, fastapi, httpx; print(sys.executable); print(sys.version); print(router_dump_analyzer.__file__); print(rsl_demo_plugin.__file__); print("required imports: OK")')
    }
    'inventory' { @('scripts/check_plugin_conformance.py', '--list') }
    'identity' {
        @(
            '-m', 'unittest', '-v',
            ($TrialPrefix + 'test_source_paths_share_resolution_only_within_each_attestation'),
            ($TrialPrefix + 'test_reused_source_resolution_rechecks_retargeted_path'),
            ($TrialPrefix + 'test_source_resolution_cache_is_bounded_and_exact'),
            ($TrialPrefix + 'test_declared_source_rewrite_during_attestation_fails_closed'),
            ($TrialPrefix + 'test_declared_source_deletion_during_attestation_fails_closed'),
            ($TrialPrefix + 'test_declared_source_same_bytes_replacement_fails_closed'),
            ($TrialPrefix + 'test_declared_compilation_cache_reuses_only_source_artifacts'),
            ($TrialPrefix + 'test_declared_compilation_cache_reads_changed_source_on_warm_hit'),
            ($TrialPrefix + 'test_declared_source_batch_cache_compiles_one_exact_snapshot')
        )
    }
    'composed' {
        @(
            '-m', 'unittest', '-v',
            'tests.test_capability_router.CapabilityRouterTests.test_live_schema_change_and_mid_call_mutation_discard_results',
            'tests.test_private_analysis_execution.PrivateAnalysisExecutionCoordinatorTests.test_registered_callback_state_drift_fails_before_invocation',
            'tests.test_private_analysis_execution.PrivateAnalysisExecutionCoordinatorTests.test_registered_callback_class_drift_fails_before_invocation',
            'tests.test_private_analysis_execution.PrivateAnalysisExecutionCoordinatorTests.test_registered_callback_closure_drift_fails_before_invocation'
        )
    }
}
$TrialLog = Join-Path $TrialRoot ($Check + '.log')
$TrialMetadata = [ordered]@{
    executable = $TrialPython
    arguments = @($TrialArguments)
    cwd = (Get-Location).Path
    TEMP = $env:TEMP
    TMP = $env:TMP
    PYTHONPYCACHEPREFIX = $env:PYTHONPYCACHEPREFIX
}
$TrialMetadata | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $TrialRoot ($Check + '-command.json')) -Encoding utf8
& $TrialPython @TrialArguments 2>&1 | Tee-Object -FilePath $TrialLog
$TrialExit = $LASTEXITCODE
Set-Content -LiteralPath (Join-Path $TrialRoot ($Check + '-exit.txt')) -Value $TrialExit -Encoding utf8
exit $TrialExit
