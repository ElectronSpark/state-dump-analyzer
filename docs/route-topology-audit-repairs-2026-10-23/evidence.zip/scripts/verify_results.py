from pathlib import Path
from collections import Counter
import json, statistics, sys
root = Path(sys.argv[1])
def read(name): return json.loads((root / name).read_text(encoding='utf-8'))
def keyed(data):
    seen = Counter(); result = {}
    for row in data['records']:
        if row['kind'] == 'end':
            seen[row['phase']] += 1
            result[(row['phase'], seen[row['phase']])] = row
    return result
before = read('performance/historical-baseline/result.json')
after = read('performance/after-1m/result.json')
a, b = keyed(before), keyed(after)
assert before['returncode'] == after['returncode'] == 0
assert list(a) == list(b) and len(a) == 52
assert all(a[k]['result'] == b[k]['result'] for k in a)
pages = [k for k in a if 'page_sha256' in a[k]['result']]
assert len(pages) == 35
for kind in ('cache_retirement', 'shared_search_cache', 'validation_cache'):
    assert [r for r in before['records'] if r['kind'] == kind] == [r for r in after['records'] if r['kind'] == kind]
old = {r['name']: r for r in read('performance/direct-before-workspace-temp/result.json')['phases']}
new = {r['name']: r for r in read('performance/direct-after/result.json')['phases']}
repeats = ['trace_repeat_' + str(i) for i in (1, 2, 3)]
assert all(old[n]['result'] == new[n]['result'] for n in ['trace_first', *repeats])
summary = read('performance/summary.json')['direct_routes']
for label, rows in [('before', old), ('after', new)]:
    for field in ('wall_seconds', 'cpu_seconds'):
        assert statistics.median(rows[n][field] for n in repeats) == summary[label + '_median_' + field]
print('PASS: 52 phase results, 35 page hashes, cache lifecycle records, four route responses and repeat medians')
