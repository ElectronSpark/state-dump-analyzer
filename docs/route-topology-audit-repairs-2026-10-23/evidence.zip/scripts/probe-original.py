from __future__ import annotations
import argparse, cProfile, gc, hashlib, importlib.util, json, os, pstats, sys, time
from pathlib import Path

parser=argparse.ArgumentParser()
parser.add_argument('--source',type=Path,required=True)
parser.add_argument('--archive',type=Path,required=True)
parser.add_argument('--output',type=Path,required=True)
parser.add_argument('--profile',action='store_true')
parser.add_argument('--profile-trace',action='store_true')
parser.add_argument('--only-load',action='store_true')
parser.add_argument('--node-initialization',action='store_true')
args=parser.parse_args()
args.output.mkdir(parents=True,exist_ok=False)
os.environ['ROUTER_DUMP_SEARCH_CACHE_DIR']=str(args.output/'empty-search-cache')
sys.path[:0]=[str(args.source/'src'),str(args.source/'demo')]
root=Path(__file__).resolve().parents[3]
spec=importlib.util.spec_from_file_location('memory_harness',root/'.runtime/root-cause-repairs-2026-10-22/measure.py')
mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
memory=mod.memory
result={'source':str(args.source),'archive':str(args.archive),'python':sys.executable,'profile':args.profile,'profile_final_trace_only':args.profile_trace,'phases':[]}

def summary_profile(prof):
 stats=pstats.Stats(prof)
 rows=[]
 for (file,line,name),(primitive,total,own,cumulative,callers) in stats.stats.items():
  rows.append({'file':file,'line':line,'function':name,'primitive_calls':primitive,'total_calls':total,'self_seconds':own,'cumulative_seconds':cumulative})
 return {'total_seconds':stats.total_tt,'total_calls':stats.total_calls,'top_self':sorted(rows,key=lambda r:r['self_seconds'],reverse=True)[:60], 'top_cumulative':sorted(rows,key=lambda r:r['cumulative_seconds'],reverse=True)[:60]}

def phase(name,operation,profile=False,summarize=lambda v:{}):
 print(json.dumps({'phase':name,'kind':'start','memory':memory()}),flush=True)
 prof=cProfile.Profile() if (profile and args.profile) or (args.profile_trace and name=='trace_profile') else None
 start=time.perf_counter(); cpu=time.process_time()
 if prof: prof.enable()
 value=operation()
 if prof: prof.disable()
 row={'name':name,'wall_seconds':time.perf_counter()-start,'cpu_seconds':time.process_time()-cpu,'memory':memory(),'result':summarize(value)}
 if prof:
  prof.dump_stats(str(args.output/(name+'.pstats')))
  row['profile']=summary_profile(prof)
 result['phases'].append(row)
 (args.output/'result.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
 print(json.dumps({k:v for k,v in row.items() if k!='profile'}),flush=True)
 return value

def imports():
 from rsl_demo_plugin.session import runtime
 from router_dump_analyzer.normalized_data import NormalizedDataService
 return runtime,NormalizedDataService
runtime,DataService=phase('runtime_import',imports)
context=runtime.open(args.archive)
session=phase('runtime_open',context.__enter__)
try:
 service=phase('service_setup',lambda:DataService(session.data_source,session.data_policy))
 descriptors=phase('archive_preparation',lambda:session.revision_store.assembly.revisions, summarize=lambda rs:{'revisions':len(rs)})
 ds=phase('node_a_cold_load',lambda:service.load_dataset(descriptors[0].revision_id),True,lambda ds:{'events':ds['demo']['event_count'],'resources':ds['demo']['resource_count']})
 bootstrap=phase('node_a_bootstrap',lambda:service.client_dataset(descriptors[0].revision_id),True,lambda ds:{'events_returned':len(ds.get('events',[])),'resources_returned':len(ds.get('resources',[]))})
 if args.node_initialization:
  from router_dump_analyzer.runtime import CoreRuntimeSession
  from router_dump_analyzer.web.runtime_context import activate_runtime_session
  from router_dump_analyzer.web import runtime_api as api
  revision=descriptors[0].revision_id
  meta=service.analysis_metadata(ds)
  timestamp=int(meta['capture_ns'])
  result['node_analysis_metadata']=meta
  def payload_summary(value):
   encoded=json.dumps(value,sort_keys=True,separators=(',',':')).encode()
   return {'bytes':len(encoded),'sha256':hashlib.sha256(encoded).hexdigest(),'list_counts':{k:len(v) for k,v in value.items() if isinstance(v,list)}}
  with activate_runtime_session(CoreRuntimeSession(session,service)), service.revision_scope(revision):
   for name,body,operation in [
    ('failure_preview',{},lambda b:api.events(revision,outcome='failure',limit=3)),
    ('initial_timeline',{'start_ns':str(meta['timeline_start_ns']),'end_ns':str(meta['timeline_end_ns']),'resource_ids':meta['initial_resource_ids'],'viewport_pixels':1000,'max_glyphs':3000,'max_record_marks':5000,'cursor_time_ns':str(timestamp)},lambda b:api.timeline_query(revision,b)),
    ('initial_graph',{'time_ns':str(timestamp),'resource_ids':[],'depth':3,'max_nodes':500},lambda b:api.graph_query(revision,b)),
    ('initial_resources',{'time_ns':str(timestamp),'limit':150,'offset':0},lambda b:api.resource_tables_query(revision,b)),
    ('initial_dashboards',{'time_ns':str(timestamp)},lambda b:api.dashboards_query(revision,b)),
    ('initial_topology_capabilities',{},lambda b:api.topology_capabilities(revision)),
    ('initial_topology',{'projection_id':'plugin.resource-association','status_perspective_id':'data-bridge-layer','basis':{'kind':'absolute_time','clock_domain':'utc','time_ns':str(timestamp),'clock_policy':'strict'},'clock_policy':'strict','include':['resources','relationships','inferred_connectivity','changes'],'limit':80,'resource_limit':80,'connectivity_limit':80,'change_start_ns':str(timestamp-120_000_000_000),'change_limit':100},lambda b:api.topology_query(revision,b)),
   ]:
    result.setdefault('initialization_requests',{})[name]=body
    phase(name,lambda b=body,op=operation:op(b),True,payload_summary)
  del bootstrap
 ds.release(); del ds; gc.collect()
 if not args.only_load:
  topology=phase('topology_construction',session.topology_provider.get,True)
  request={'basis':{'kind':'relative_to_watermark','offset_ns':'0'},'clock_policy':'best_effort','resource_limit':500,'inter_node_link_limit':1000,'network_segment_limit':500,'segment_attachment_limit':4000}
  snapshot=phase('topology_query',lambda:topology.query(request),True,lambda s:{'nodes':len(s['nodes']),'context_id':s['context_id']})
  routes=phase('route_construction',session.route_provider.get)
  query={'scenario_id':'cross-node-forwarding-loop','direction':'both','topology_context_id':snapshot['context_id'],'max_hops':64,'max_recursion':16}
  result['route_request']=query
  def trace_summary(trace):
   encoded=json.dumps(trace,sort_keys=True,separators=(',',':')).encode()
   return {'sha256':hashlib.sha256(encoded).hexdigest(),'bytes':len(encoded),'directions':{k:{'path_count':len(v['paths']),'results':[p['result'] for p in v['paths']],'node_sequences':[p.get('node_sequence') for p in v['paths']]} for k,v in trace['directional_traces'].items()}}
  for n in range(4):
   phase('trace_first' if n==0 else 'trace_repeat_'+str(n),lambda:routes.trace(dict(query)),n==1,trace_summary)
  if args.profile_trace:
   phase('trace_profile',lambda:routes.trace(dict(query)),True,trace_summary)
finally:
 phase('runtime_close',lambda:context.__exit__(None,None,None))
 phase('final_gc',gc.collect)
