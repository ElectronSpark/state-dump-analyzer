$ErrorActionPreference = 'Stop'
$repoPath = (Get-Location).Path
$auditPath = Join-Path $repoPath '.runtime/audit-repairs-2026-10-23'
$previousDemo = Get-CimInstance Win32_Process -Filter 'ProcessId=29420'
if ($previousDemo) {
    if ($previousDemo.CommandLine -notlike '*-m router_dump_analyzer --plugin demo_router --input demo/fixtures/router-state-lab-algorithms-2026-10-02.tgz --host 127.0.0.1 --port 8883*') {
        throw 'Refusing to stop a process that does not match the inspected demo.'
    }
    Stop-Process -Id $previousDemo.ProcessId
}
$env:PYTHONPATH = @((Join-Path $repoPath 'src'), (Join-Path $repoPath 'demo'), (Join-Path $repoPath 'state-dump-generator/src')) -join ';'
$env:PYTHONUTF8 = '1'
$env:PYTHONHASHSEED = '0'
$env:TEMP = Join-Path $auditPath 'tmp'
$env:TMP = $env:TEMP
$env:ROUTER_DUMP_SEARCH_CACHE_DIR = Join-Path $auditPath 'browser-search-cache'
$demoArguments = @('-B', '-X', 'utf8', '-m', 'router_dump_analyzer', '--plugin', 'demo_router', '--input', 'demo/fixtures/router-state-lab-algorithms-2026-10-02.tgz', '--host', '127.0.0.1', '--port', '8883', '--frontend-dir', 'frontend', '--control-plane-dir', '.runtime/manual-browser-2026-10-20/control-plane', '--plugin-composition-deployment-module', 'rsl_demo_plugin.deployment:build_plugin_deployment', '--private-analysis-deployment-module', 'rsl_demo_plugin.offline_analysis:build_offline_analysis_deployment', '--trust-control-plane-headers', '--no-browser')
$demoProcess = Start-Process -FilePath 'C:/Users/82046/anaconda3/envs/router-dump-analyzer-demo/python.exe' -ArgumentList $demoArguments -WorkingDirectory $repoPath -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $auditPath 'demo.stdout.log') -RedirectStandardError (Join-Path $auditPath 'demo.stderr.log')
[ordered]@{pid=$demoProcess.Id;started_utc=[DateTime]::UtcNow.ToString('o');arguments=$demoArguments;search_cache=$env:ROUTER_DUMP_SEARCH_CACHE_DIR} | ConvertTo-Json -Depth 3 | Set-Content (Join-Path $auditPath 'demo-process.json') -Encoding utf8
$demoProcess.Id

